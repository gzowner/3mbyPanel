from __future__ import annotations

import asyncio
import hashlib
import hmac
import io
import json
import os
import re
import shutil
import tarfile
import tempfile
import uuid
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import docker
import httpx
from docker.errors import DockerException, NotFound
from fastapi import BackgroundTasks, FastAPI, Header, HTTPException, status
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(case_sensitive=False)

    ops_agent_token: str
    project_name: str = "3mbypanel"
    base_dir: str = "/mbypanel"
    media_root: str = "/media"
    media_host_path: str = "/mnt/unionfs"
    backup_root: str = "/mbypanel/backups/managed"
    diagnostics_root: str = "/mbypanel/backups/diagnostics"
    emby_url: str = "http://emby:8096/emby"
    emby_api_key: str = ""
    emby_container: str = "3mbypanel-emby"
    postgres_container: str = "3mbypanel-postgres"
    postgres_db: str = "mbypanel"
    postgres_user: str = "mbypanel"
    timezone_name: str = "America/Chicago"


settings = Settings()
app = FastAPI(title="3mbyPanel Operations Agent", version="0.1.0", docs_url=None, redoc_url=None)
docker_client = docker.from_env()
backup_root = Path(settings.backup_root)
diagnostics_root = Path(settings.diagnostics_root)
jobs_root = backup_root / ".jobs"
for directory in (backup_root, diagnostics_root, jobs_root):
    directory.mkdir(parents=True, exist_ok=True)
    try:
        directory.chmod(0o700)
    except OSError:
        pass

# Jobs are persisted on the host. Mark interrupted work clearly after an agent restart.
for stale_job_file in jobs_root.glob("*.json"):
    try:
        stale = json.loads(stale_job_file.read_text(encoding="utf-8"))
        if stale.get("status") in {"queued", "running"}:
            stale["status"] = "failed"
            stale["finished_at"] = datetime.now(timezone.utc).isoformat()
            stale["current_step"] = "Interrupted"
            stale["error"] = "Operations Agent restarted during the job."
            write_target = stale_job_file.with_suffix(".json.tmp")
            write_target.write_text(json.dumps(stale, indent=2, default=str), encoding="utf-8")
            write_target.replace(stale_job_file)
    except Exception:
        continue

ALLOWED_RESTART_SERVICES = {
    "emby",
    "control-worker",
    "m3u-gateway",
    "media-gateway",
    "redis",
    "control-web",
}


class BackupRequest(BaseModel):
    job_id: uuid.UUID | None = None
    backup_type: str = Field(default="manual", pattern="^(manual|nightly|pre_upgrade)$")
    requested_by: str = "admin"
    include_mirror: bool = False
    retention_daily: int = Field(default=7, ge=1, le=90)
    retention_weekly: int = Field(default=4, ge=0, le=52)


class RestoreRequest(BaseModel):
    requested_by: str = "admin"
    confirmation: str


class DiagnosticsRequest(BaseModel):
    requested_by: str = "admin"


def require_token(x_ops_token: str | None) -> None:
    if not x_ops_token or not hmac.compare_digest(x_ops_token, settings.ops_agent_token):
        raise HTTPException(status_code=401, detail="Invalid operations token.")


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def write_json_atomic(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
    tmp.replace(path)


def job_path(job_id: str) -> Path:
    return jobs_root / f"{job_id}.json"


def load_job(job_id: str) -> dict[str, Any] | None:
    path = job_path(job_id)
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def update_job(job_id: str, **changes: Any) -> dict[str, Any]:
    current = load_job(job_id) or {"id": job_id, "created_at": utc_now().isoformat()}
    current.update(changes)
    write_json_atomic(job_path(job_id), current)
    return current


def container_service(container: Any) -> str:
    labels = container.attrs.get("Config", {}).get("Labels", {}) or {}
    return labels.get("com.docker.compose.service") or container.name.removeprefix("3mbypanel-")


def project_containers(all_containers: bool = True) -> list[Any]:
    try:
        return docker_client.containers.list(
            all=all_containers,
            filters={"label": f"com.docker.compose.project={settings.project_name}"},
        )
    except DockerException as exc:
        raise RuntimeError(f"Docker is unavailable: {exc}") from exc


def find_service(service: str) -> Any:
    for container in project_containers(True):
        if container_service(container) == service:
            return container
    raise NotFound(f"Service {service} not found")


def disk_payload(path: Path, display_path: str) -> dict[str, Any]:
    try:
        usage = shutil.disk_usage(path)
        percent = round((usage.used / usage.total * 100), 1) if usage.total else 0
        return {
            "path": display_path,
            "available": True,
            "total_bytes": usage.total,
            "used_bytes": usage.used,
            "free_bytes": usage.free,
            "used_percent": percent,
        }
    except Exception as exc:
        return {"path": display_path, "available": False, "error": str(exc)}


async def path_responsive(path: Path) -> tuple[bool, str]:
    def inspect() -> tuple[bool, str]:
        if not path.exists():
            return False, "Path does not exist."
        try:
            with os.scandir(path) as entries:
                next(entries, None)
            return True, "Responsive"
        except Exception as exc:
            return False, str(exc)

    try:
        return await asyncio.wait_for(asyncio.to_thread(inspect), timeout=5)
    except asyncio.TimeoutError:
        return False, "Timed out after 5 seconds."


def bytes_tree(path: Path) -> int:
    total = 0
    if not path.exists():
        return total
    for item in path.rglob("*"):
        try:
            if item.is_file():
                total += item.stat().st_size
        except OSError:
            continue
    return total


def read_manifest(directory: Path) -> dict[str, Any] | None:
    path = directory / "manifest.json"
    if not path.is_file():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["directory"] = directory.name
        payload["path"] = str(directory)
        payload["size_bytes"] = bytes_tree(directory)
        return payload
    except Exception:
        return None


def list_backups() -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for directory in backup_root.iterdir() if backup_root.exists() else []:
        if not directory.is_dir() or directory.name.startswith("."):
            continue
        manifest = read_manifest(directory)
        if manifest:
            result.append(manifest)
    result.sort(key=lambda x: x.get("created_at", ""), reverse=True)
    return result


def list_jobs(limit: int = 50) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for path in jobs_root.glob("*.json"):
        try:
            result.append(json.loads(path.read_text(encoding="utf-8")))
        except Exception:
            continue
    result.sort(key=lambda x: x.get("created_at", ""), reverse=True)
    return result[:limit]


def safe_extract_tar(archive: tarfile.TarFile, destination: Path) -> None:
    destination = destination.resolve()
    for member in archive.getmembers():
        target = (destination / member.name).resolve()
        if destination != target and destination not in target.parents:
            raise RuntimeError("Unsafe path in archive.")
    archive.extractall(destination)


def extract_docker_archive(bits: Any, destination: Path) -> Path:
    data = b"".join(bits)
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:*") as archive:
        names = [m.name for m in archive.getmembers() if m.isfile()]
        if not names:
            raise RuntimeError("Docker archive did not contain a file.")
        safe_extract_tar(archive, destination)
        return destination / names[0]


def put_file_in_container(container: Any, source: Path, destination_dir: str, destination_name: str) -> None:
    payload = io.BytesIO()
    with tarfile.open(fileobj=payload, mode="w") as archive:
        info = tarfile.TarInfo(destination_name)
        info.size = source.stat().st_size
        info.mtime = int(source.stat().st_mtime)
        with source.open("rb") as handle:
            archive.addfile(info, handle)
    payload.seek(0)
    if not container.put_archive(destination_dir, payload.read()):
        raise RuntimeError("Unable to copy database archive into PostgreSQL container.")


def _public_emby_info() -> dict[str, Any]:
    try:
        response = httpx.get(
            f"{settings.emby_url.rstrip('/')}/System/Info/Public",
            timeout=10.0,
        )
        if response.status_code == 200:
            return response.json()
    except Exception:
        pass
    return {}


def create_emby_backup(destination: Path) -> dict[str, Any]:
    """Create a consistent Emby backup by briefly stopping the managed container."""
    config_root = Path(settings.base_dir) / "emby" / "config"
    if not config_root.is_dir():
        raise RuntimeError(f"Emby configuration directory was not found: {config_root}")

    public_info = _public_emby_info()
    container = docker_client.containers.get(settings.emby_container)
    container.reload()
    was_running = container.status == "running"
    archive_path = destination / "emby-config.tar.gz"

    try:
        if was_running:
            container.stop(timeout=60)
        with tarfile.open(archive_path, "w:gz") as archive:
            archive.add(config_root, arcname="emby-config", recursive=True)
    finally:
        if was_running:
            container.start()

    return {
        "archive_name": archive_path.name,
        "backup_method": "quiesced-filesystem",
        "server_version": public_info.get("Version"),
        "server_name": public_info.get("ServerName") or public_info.get("Name"),
        "brief_service_stop": was_running,
    }

def create_postgres_backup(destination: Path, job_id: str) -> Path:
    container = docker_client.containers.get(settings.postgres_container)
    remote = f"/tmp/mbypanel-{job_id}.dump"
    result = container.exec_run(
        [
            "pg_dump",
            "-U",
            settings.postgres_user,
            "-d",
            settings.postgres_db,
            "-Fc",
            "--no-owner",
            "--no-privileges",
            "-f",
            remote,
        ]
    )
    if result.exit_code != 0:
        raise RuntimeError(f"PostgreSQL backup failed: {result.output.decode(errors='replace')[:1000]}")
    try:
        bits, _ = container.get_archive(remote)
        extracted = extract_docker_archive(bits, destination)
        final = destination / "mbypanel-postgres.dump"
        extracted.replace(final)
        return final
    finally:
        container.exec_run(["rm", "-f", remote])


def make_tar(source: Path, destination: Path, arcname: str) -> None:
    with tarfile.open(destination, "w:gz") as archive:
        archive.add(source, arcname=arcname, recursive=True)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_checksums(directory: Path) -> None:
    lines = []
    for path in sorted(directory.iterdir()):
        if path.is_file() and path.name not in {"checksums.sha256", "manifest.json"}:
            lines.append(f"{sha256_file(path)}  {path.name}")
    (directory / "checksums.sha256").write_text("\n".join(lines) + "\n", encoding="utf-8")


def verify_checksums(directory: Path) -> None:
    checksum_file = directory / "checksums.sha256"
    if not checksum_file.is_file():
        raise RuntimeError("Backup checksum file is missing.")
    for line in checksum_file.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        expected, filename = line.split("  ", 1)
        path = directory / filename
        if not path.is_file() or sha256_file(path) != expected:
            raise RuntimeError(f"Checksum verification failed for {filename}.")


def apply_retention(retention_daily: int, retention_weekly: int) -> list[str]:
    backups = [x for x in list_backups() if x.get("backup_type") == "nightly" and x.get("status") == "completed"]
    keep: set[str] = set()
    for item in backups[:retention_daily]:
        keep.add(item["directory"])

    weekly_kept = 0
    seen_weeks: set[str] = set()
    for item in backups[retention_daily:]:
        try:
            created = datetime.fromisoformat(str(item["created_at"]).replace("Z", "+00:00"))
        except Exception:
            continue
        year, week, _ = created.isocalendar()
        key = f"{year}-{week:02d}"
        if key not in seen_weeks and weekly_kept < retention_weekly:
            seen_weeks.add(key)
            keep.add(item["directory"])
            weekly_kept += 1

    removed: list[str] = []
    for item in backups:
        if item["directory"] in keep:
            continue
        try:
            shutil.rmtree(backup_root / item["directory"])
            removed.append(item["directory"])
        except OSError:
            continue
    return removed


async def run_backup(job_id: str, request: BackupRequest) -> None:
    started = utc_now()
    update_job(job_id, operation="backup", status="running", started_at=started.isoformat(), error=None)
    stamp = started.strftime("%Y%m%d-%H%M%S")
    directory = backup_root / f"{stamp}-{request.backup_type}-{job_id[:8]}"
    directory.mkdir(parents=True, exist_ok=False)
    directory.chmod(0o700)
    warning: str | None = None
    try:
        update_job(job_id, current_step="Creating Emby application backup")
        emby_info: dict[str, Any] | None = None
        try:
            emby_info = await asyncio.to_thread(create_emby_backup, directory)
        except Exception as exc:
            warning = f"Emby backup failed: {exc}"

        update_job(job_id, current_step="Backing up 3mbyPanel PostgreSQL")
        await asyncio.to_thread(create_postgres_backup, directory, job_id)

        env_source = Path(settings.base_dir) / ".env"
        if env_source.is_file():
            shutil.copy2(env_source, directory / "env.snapshot")

        if request.include_mirror:
            update_job(job_id, current_step="Archiving STRM mirror")
            mirror_root = Path(settings.base_dir) / "strm-library"
            if mirror_root.exists():
                await asyncio.to_thread(make_tar, mirror_root, directory / "strm-library.tar.gz", "strm-library")

        manifest = {
            "id": job_id,
            "status": "completed",
            "backup_type": request.backup_type,
            "requested_by": request.requested_by,
            "created_at": started.isoformat(),
            "finished_at": utc_now().isoformat(),
            "include_mirror": request.include_mirror,
            "emby": emby_info,
            "warning": warning,
            "version": "0.1.0",
        }
        write_checksums(directory)
        write_json_atomic(directory / "manifest.json", manifest)
        for protected in directory.iterdir():
            if protected.is_file():
                protected.chmod(0o600)
        removed = await asyncio.to_thread(apply_retention, request.retention_daily, request.retention_weekly)
        update_job(
            job_id,
            status="completed",
            finished_at=manifest["finished_at"],
            current_step="Completed",
            backup_directory=directory.name,
            backup_path=str(directory),
            size_bytes=bytes_tree(directory),
            warning=warning,
            retention_removed=removed,
        )
    except Exception as exc:
        update_job(
            job_id,
            status="failed",
            finished_at=utc_now().isoformat(),
            current_step="Failed",
            error=str(exc)[:2000],
            backup_directory=directory.name,
        )
        if directory.exists() and not any(directory.iterdir()):
            directory.rmdir()


def restart_container_later(service: str) -> None:
    async def delayed() -> None:
        await asyncio.sleep(1.0)
        container = find_service(service)
        await asyncio.to_thread(container.restart, timeout=30)

    asyncio.create_task(delayed())


def stopped_for_restore() -> list[Any]:
    order = ["control-api", "control-worker", "m3u-gateway", "media-gateway", "redis"]
    stopped: list[Any] = []
    for service in order:
        try:
            container = find_service(service)
            container.reload()
            if container.status == "running":
                container.stop(timeout=30)
                stopped.append(container)
        except Exception:
            continue
    return stopped


def restore_postgres(backup_file: Path, job_id: str) -> None:
    container = docker_client.containers.get(settings.postgres_container)
    remote_name = f"mbypanel-restore-{job_id}.dump"
    put_file_in_container(container, backup_file, "/tmp", remote_name)
    remote = f"/tmp/{remote_name}"
    result = container.exec_run(
        [
            "pg_restore",
            "-U",
            settings.postgres_user,
            "-d",
            settings.postgres_db,
            "--clean",
            "--if-exists",
            "--no-owner",
            "--no-privileges",
            remote,
        ]
    )
    container.exec_run(["rm", "-f", remote])
    if result.exit_code != 0:
        output = result.output.decode(errors="replace")
        raise RuntimeError(f"PostgreSQL restore failed: {output[-2000:]}")


def restore_mirror(archive_path: Path) -> None:
    mirror_root = Path(settings.base_dir) / "strm-library"
    mirror_root.mkdir(parents=True, exist_ok=True)
    for child in mirror_root.iterdir():
        if child.is_dir():
            shutil.rmtree(child)
        else:
            child.unlink()
    with tarfile.open(archive_path, "r:gz") as archive:
        safe_extract_tar(archive, Path(settings.base_dir))


def restore_emby(directory: Path, manifest: dict[str, Any]) -> None:
    info = manifest.get("emby") or {}
    archive_name = info.get("archive_name")
    if not archive_name:
        raise RuntimeError("This backup does not contain an Emby configuration archive.")
    source = directory / str(archive_name)
    if not source.is_file():
        raise RuntimeError("Emby configuration archive is missing from the backup.")

    config_root = Path(settings.base_dir) / "emby" / "config"
    container = docker_client.containers.get(settings.emby_container)
    container.reload()
    was_running = container.status == "running"

    if was_running:
        container.stop(timeout=60)
    try:
        with tempfile.TemporaryDirectory(prefix="3mbypanel-emby-restore-") as temp_dir:
            temp = Path(temp_dir)
            with tarfile.open(source, "r:gz") as archive:
                safe_extract_tar(archive, temp)
            extracted = temp / "emby-config"
            if not extracted.is_dir():
                raise RuntimeError("Emby backup archive has an unexpected layout.")
            config_root.mkdir(parents=True, exist_ok=True)
            for child in list(config_root.iterdir()):
                if child.is_dir() and not child.is_symlink():
                    shutil.rmtree(child)
                else:
                    child.unlink(missing_ok=True)
            for child in extracted.iterdir():
                destination = config_root / child.name
                if child.is_dir() and not child.is_symlink():
                    shutil.copytree(child, destination, symlinks=True)
                else:
                    shutil.copy2(child, destination, follow_symlinks=False)
    finally:
        if was_running:
            container.start()



async def wait_emby(timeout_seconds: int = 240) -> None:
    deadline = asyncio.get_running_loop().time() + timeout_seconds
    while asyncio.get_running_loop().time() < deadline:
        try:
            async with httpx.AsyncClient(timeout=5) as client:
                response = await client.get(f"{settings.emby_url.rstrip('/')}/System/Info/Public")
            if response.status_code == 200:
                return
        except Exception:
            pass
        await asyncio.sleep(5)
    raise RuntimeError("Emby did not become healthy after restore.")


async def run_restore(job_id: str, backup_id: str, requested_by: str) -> None:
    update_job(job_id, operation="restore", backup_id=backup_id, status="running", started_at=utc_now().isoformat())
    directory: Path | None = None
    stopped: list[Any] = []
    try:
        matches = [x for x in list_backups() if x.get("id") == backup_id]
        if not matches:
            raise RuntimeError("Backup was not found.")
        directory = Path(matches[0]["path"])
        manifest = read_manifest(directory)
        if not manifest:
            raise RuntimeError("Backup manifest could not be read.")
        update_job(job_id, current_step="Verifying checksums")
        await asyncio.to_thread(verify_checksums, directory)

        update_job(job_id, current_step="Stopping 3mbyPanel application services")
        stopped = await asyncio.to_thread(stopped_for_restore)

        update_job(job_id, current_step="Restoring 3mbyPanel PostgreSQL")
        await asyncio.to_thread(restore_postgres, directory / "mbypanel-postgres.dump", job_id)

        mirror_archive = directory / "strm-library.tar.gz"
        if mirror_archive.is_file():
            update_job(job_id, current_step="Restoring STRM mirror")
            await asyncio.to_thread(restore_mirror, mirror_archive)

        restore_warning: str | None = None
        if manifest.get("emby"):
            update_job(job_id, current_step="Restoring Emby backup")
            await asyncio.to_thread(restore_emby, directory, manifest)
            await asyncio.sleep(10)
            await wait_emby(timeout_seconds=600)
        else:
            restore_warning = "This restore point did not contain an Emby archive; 3mbyPanel PostgreSQL and optional STRM data were restored."
            update_job(job_id, current_step="Skipping unavailable Emby archive", warning=restore_warning)

        update_job(job_id, current_step="Starting 3mbyPanel application services")
        stopped_by_service = {container_service(c): c for c in stopped}
        for service in ("redis", "control-api", "control-worker", "m3u-gateway", "media-gateway"):
            container = stopped_by_service.get(service)
            if container is None:
                continue
            try:
                await asyncio.to_thread(container.start)
                await asyncio.sleep(1)
            except Exception:
                continue

        update_job(
            job_id,
            status="completed",
            requested_by=requested_by,
            finished_at=utc_now().isoformat(),
            current_step="Completed",
            warning=restore_warning,
        )
    except Exception as exc:
        stopped_by_service = {container_service(c): c for c in stopped}
        for service in ("redis", "control-api", "control-worker", "m3u-gateway", "media-gateway"):
            container = stopped_by_service.get(service)
            if container is None:
                continue
            try:
                await asyncio.to_thread(container.start)
            except Exception:
                continue
        update_job(
            job_id,
            status="failed",
            requested_by=requested_by,
            finished_at=utc_now().isoformat(),
            current_step="Failed",
            error=str(exc)[:3000],
        )


def redact_text(text: str, secrets: list[str]) -> str:
    result = text
    for secret in secrets:
        if secret:
            result = result.replace(secret, "[REDACTED]")
    result = re.sub(r"(?i)(password|passwd|token|api[_-]?key|secret)=([^&\s]+)", r"\1=[REDACTED]", result)
    result = re.sub(r"(?i)(/live|/movie|/series)/[^/\s]+/[^/\s]+/", r"\1/[USER]/[PASS]/", result)
    result = re.sub(r"(?i)(username=)[^&\s]+", r"\1[USER]", result)
    return result


def create_diagnostics(requested_by: str) -> Path:
    stamp = utc_now().strftime("%Y%m%d-%H%M%S")
    output = diagnostics_root / f"mbypanel-diagnostics-{stamp}.zip"
    base = Path(settings.base_dir)
    env_values: dict[str, str] = {}
    env_path = base / ".env"
    if env_path.is_file():
        for line in env_path.read_text(encoding="utf-8", errors="replace").splitlines():
            if "=" in line and not line.lstrip().startswith("#"):
                key, value = line.split("=", 1)
                env_values[key] = value
    secret_values = [value for key, value in env_values.items() if any(word in key.upper() for word in ("PASS", "SECRET", "KEY", "TOKEN"))]

    with tempfile.TemporaryDirectory(prefix="mbypanel-diagnostics-") as temp_dir:
        temp = Path(temp_dir)
        status_payload = asyncio.run(build_status_sync())
        write_json_atomic(temp / "status.json", status_payload)
        write_json_atomic(temp / "jobs.json", {"jobs": list_jobs(100), "backups": list_backups()})

        redacted_env = []
        for key, value in env_values.items():
            if any(word in key.upper() for word in ("PASS", "SECRET", "KEY", "TOKEN")):
                value = "[REDACTED]"
            redacted_env.append(f"{key}={value}")
        (temp / "env.redacted").write_text("\n".join(redacted_env) + "\n", encoding="utf-8")

        logs_dir = temp / "logs"
        logs_dir.mkdir()
        for container in project_containers(True):
            try:
                logs = container.logs(tail=300, timestamps=True).decode("utf-8", errors="replace")
            except Exception as exc:
                logs = f"Unable to read logs: {exc}\n"
            (logs_dir / f"{container_service(container)}.log").write_text(redact_text(logs, secret_values), encoding="utf-8")

        meta = {
            "created_at": utc_now().isoformat(),
            "requested_by": requested_by,
            "version": "0.1.0",
            "note": "Credential values were redacted where recognized. Review before sharing.",
        }
        write_json_atomic(temp / "manifest.json", meta)
        with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for path in temp.rglob("*"):
                if path.is_file():
                    archive.write(path, path.relative_to(temp))
    output.chmod(0o600)
    return output


async def build_status_sync() -> dict[str, Any]:
    containers = []
    healthy = 0
    total = 0
    for container in project_containers(True):
        container.reload()
        state = container.attrs.get("State", {})
        health = (state.get("Health") or {}).get("Status")
        service = container_service(container)
        running = state.get("Status") == "running"
        okay = running and health not in {"unhealthy", "starting"}
        total += 1
        healthy += int(okay)
        containers.append(
            {
                "service": service,
                "name": container.name,
                "status": state.get("Status") or container.status,
                "health": health or ("running" if running else "stopped"),
                "image": container.attrs.get("Config", {}).get("Image"),
                "started_at": state.get("StartedAt"),
                "restart_count": container.attrs.get("RestartCount", 0),
                "restart_allowed": service in ALLOWED_RESTART_SERVICES,
            }
        )
    containers.sort(key=lambda x: x["service"])
    responsive, message = await path_responsive(Path(settings.media_root))
    backups = list_backups()
    return {
        "service": "3mbyPanel Operations Agent",
        "version": "0.1.0",
        "status": "ok" if healthy == total and responsive else "degraded",
        "containers": containers,
        "container_summary": {"healthy": healthy, "total": total},
        "disks": {
            "base": disk_payload(Path(settings.base_dir), settings.base_dir.replace("/mbypanel", "/opt/3mbypanel")),
            "media": disk_payload(Path(settings.media_root), settings.media_host_path),
        },
        "media_mount": {
            "path": settings.media_host_path,
            "responsive": responsive,
            "message": message,
        },
        "backups": {
            "count": len(backups),
            "total_size_bytes": sum(int(x.get("size_bytes") or 0) for x in backups),
            "last": backups[0] if backups else None,
        },
    }


@app.get("/health")
async def health() -> dict[str, str]:
    try:
        docker_client.ping()
        return {"service": "3mbyPanel Operations Agent", "version": "0.1.0", "status": "ok"}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.get("/status")
async def status_endpoint(x_ops_token: str | None = Header(default=None, alias="X-Ops-Token")) -> dict[str, Any]:
    require_token(x_ops_token)
    return await build_status_sync()


@app.post("/services/{service}/restart", status_code=status.HTTP_202_ACCEPTED)
async def restart_service(service: str, x_ops_token: str | None = Header(default=None, alias="X-Ops-Token")) -> dict[str, Any]:
    require_token(x_ops_token)
    if service not in ALLOWED_RESTART_SERVICES:
        raise HTTPException(status_code=400, detail="This service cannot be restarted from the panel.")
    try:
        find_service(service)
    except NotFound as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    restart_container_later(service)
    return {"accepted": True, "service": service}


@app.get("/backups")
async def backups_endpoint(x_ops_token: str | None = Header(default=None, alias="X-Ops-Token")) -> dict[str, Any]:
    require_token(x_ops_token)
    return {"backups": list_backups(), "jobs": list_jobs()}


@app.post("/backups", status_code=status.HTTP_202_ACCEPTED)
async def create_backup_endpoint(
    request: BackupRequest,
    background_tasks: BackgroundTasks,
    x_ops_token: str | None = Header(default=None, alias="X-Ops-Token"),
) -> dict[str, Any]:
    require_token(x_ops_token)
    running = [j for j in list_jobs(100) if j.get("operation") in {"backup", "restore"} and j.get("status") in {"queued", "running"}]
    if running:
        raise HTTPException(status_code=409, detail="A backup or restore is already running.")
    job_id = str(request.job_id or uuid.uuid4())
    update_job(
        job_id,
        operation="backup",
        backup_type=request.backup_type,
        requested_by=request.requested_by,
        include_mirror=request.include_mirror,
        status="queued",
        created_at=utc_now().isoformat(),
        current_step="Queued",
    )
    background_tasks.add_task(run_backup, job_id, request)
    return {"accepted": True, "job_id": job_id}


@app.get("/jobs/{job_id}")
async def job_endpoint(job_id: str, x_ops_token: str | None = Header(default=None, alias="X-Ops-Token")) -> dict[str, Any]:
    require_token(x_ops_token)
    job = load_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found.")
    return job


@app.delete("/backups/{backup_id}")
async def delete_backup_endpoint(backup_id: str, x_ops_token: str | None = Header(default=None, alias="X-Ops-Token")) -> dict[str, Any]:
    require_token(x_ops_token)
    matches = [x for x in list_backups() if x.get("id") == backup_id]
    if not matches:
        raise HTTPException(status_code=404, detail="Backup not found.")
    shutil.rmtree(Path(matches[0]["path"]))
    return {"deleted": True, "backup_id": backup_id}


@app.post("/backups/{backup_id}/restore", status_code=status.HTTP_202_ACCEPTED)
async def restore_backup_endpoint(
    backup_id: str,
    request: RestoreRequest,
    background_tasks: BackgroundTasks,
    x_ops_token: str | None = Header(default=None, alias="X-Ops-Token"),
) -> dict[str, Any]:
    require_token(x_ops_token)
    if request.confirmation != "RESTORE":
        raise HTTPException(status_code=400, detail="Restore confirmation must be RESTORE.")
    running = [j for j in list_jobs(100) if j.get("operation") in {"backup", "restore"} and j.get("status") in {"queued", "running"}]
    if running:
        raise HTTPException(status_code=409, detail="A backup or restore is already running.")
    if not any(x.get("id") == backup_id for x in list_backups()):
        raise HTTPException(status_code=404, detail="Backup not found.")
    job_id = str(uuid.uuid4())
    update_job(
        job_id,
        operation="restore",
        backup_id=backup_id,
        requested_by=request.requested_by,
        status="queued",
        created_at=utc_now().isoformat(),
        current_step="Queued",
    )
    background_tasks.add_task(run_restore, job_id, backup_id, request.requested_by)
    return {"accepted": True, "job_id": job_id}


@app.post("/diagnostics")
async def diagnostics_endpoint(
    request: DiagnosticsRequest,
    x_ops_token: str | None = Header(default=None, alias="X-Ops-Token"),
) -> dict[str, Any]:
    require_token(x_ops_token)
    path = await asyncio.to_thread(create_diagnostics, request.requested_by)
    return {"created": True, "path": str(path), "size_bytes": path.stat().st_size}
