# Third-party services and software

3mbyPanel is an independent management project and is not an official Emby product.

The package uses or integrates with:

- Emby Server through the official Emby Docker image and REST API.
- PostgreSQL.
- Redis.
- Nginx.
- FastAPI, Uvicorn, HTTPX, asyncpg, and the Docker Python SDK.
- TMDB metadata services when configured by the administrator.
- Rclone when configured on the host.

Each component and external service remains subject to its own license and terms. No Emby Premiere license, media, playlist, XMLTV data, or TMDB credential is included.
