# v0.1.0 validation record

Completed before packaging:

- Bash syntax validation for every `.sh` file.
- Python bytecode compilation for control API, M3U gateway, media gateway, and Operations Agent.
- YAML parsing for base and Intel-GPU Compose files.
- Browser JavaScript syntax validation with Node.js.
- HTML ID, JavaScript reference, navigation, and page-section consistency checks.
- Migration numbering check from schema 2 through schema 15.
- SQL-created-table reference check.
- Emby compatibility tests for `/Users/Query`, `X-Emby-Token`, password-body conversion, HTTP 200 write handling, and `POST /Users/{Id}/Delete` conversion.
- Emby URL normalization tests for root, `/emby`, `/web`, `/web/index.html`, and base-path installations.
- Existing-user preview tests for new accounts, protected administrators, local adoption, and remote username linking.
- Mocked non-interactive fresh installation.
- Mocked cumulative upgrade with `.env` secret preservation and rollback snapshot creation.
- Mocked failed upgrade with automatic application-file rollback.
- Release manifest verification.
- ZIP CRC, extraction, executable-mode, and internal-checksum verification.

Not available in the build environment:

- Docker daemon and real Emby container runtime.
- Live testing against an actual Emby Server API.
- Client-specific message and playback-stop testing.
- Real M3U/XMLTV import into Emby.
- Real backup/restore timing with an established Emby database.

Use `TEST-EMBY.md` on a local Ubuntu 24.04 server before public release.
