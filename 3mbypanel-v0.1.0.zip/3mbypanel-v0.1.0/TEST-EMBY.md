# 3mbyPanel v0.1.0 real-server test plan

Use a local or disposable Ubuntu 24.04 server before public deployment.

## 1. Fresh installation

```bash
sha256sum -c 3mbypanel-v0.1.0.zip.sha256
unzip 3mbypanel-v0.1.0.zip
cd 3mbypanel-v0.1.0
sudo bash install.sh
```

Confirm:

```bash
sudo /opt/3mbypanel/scripts/manage.sh health
sudo docker compose --env-file /opt/3mbypanel/.env -f /opt/3mbypanel/compose.yml ps
```

Expected host ports are Emby 8098 and 3mbyPanel 8281 unless changed during installation.

## 2. Emby initialization

1. Open the managed Emby URL.
2. Complete Emby's initial setup.
3. Create an Emby API key.
4. Run:

```bash
sudo /opt/3mbypanel/scripts/set-emby-api-key.sh
sudo /opt/3mbypanel/scripts/manage.sh health
```

Confirm the Dashboard shows Emby online and API key configured.

## 3. User management

Create one test account through 3mbyPanel. Verify:

- The account appears in Emby.
- Its password works.
- Downloads and Live TV follow the selected policy.
- Simultaneous stream limit matches the package.
- Password reset through 3mbyPanel works.
- Suspend and re-enable work.
- Expiration disables the account after a worker cycle.

Do not use the only Emby administrator as a customer test account.

## 4. Existing-user import

1. Create a non-administrator user directly in Emby.
2. Open **Servers → Local Emby → Import users**.
3. Scan and preview.
4. Import while preserving source permissions.
5. Confirm the old Emby password still works.
6. Set a new password through 3mbyPanel and confirm the new password works.

## 5. Additional Emby server

1. Create an API key on a second Emby server.
2. Add it under **Servers** using an address reachable from the containers.
3. Test the connection.
4. Import or link one existing user.
5. Assign one managed customer to both servers.
6. Set a new password and synchronize.
7. Confirm the policy and password reach both servers.
8. Shut down the second server and confirm the panel remains usable and reports it offline.

## 6. Stream Operations

Start playback from both servers. Confirm:

- Server name, user, device, IP, item, playback method, bitrate, and transcode details appear.
- On-screen message works on a supported client.
- Stop playback works on a supported client.
- Package limits combine assigned-server sessions.

Leave automatic excess-session stopping disabled until several client types are tested.

## 7. Live TV and EPG

1. Add a test M3U and XMLTV feed.
2. Refresh the source.
3. Select categories.
4. Scan the EPG mapper.
5. Review and apply mappings.
6. Sync M3U and EPG to Emby.
7. Refresh the guide.
8. Confirm channels and programs appear in Emby.

## 8. Library mirror

1. Set the media inventory root.
2. Scan media.
3. Configure a TMDB credential.
4. Build one small movie and TV sample.
5. Add Emby libraries pointing to:

```text
/strm-library/Movies
/strm-library/TV Shows
```

6. Confirm metadata, images, NFO files, and playback.

## 9. Backup and restore

Create a manual backup during a quiet period. Emby will briefly stop while its configuration archive is created.

Confirm the backup includes:

```text
emby-config.tar.gz
mbypanel-postgres.dump
checksums.sha256
manifest.json
```

Create a disposable test record, restore the backup, and confirm that the record disappears and Emby returns healthy.

## 10. Diagnostics and update safety

```bash
sudo /opt/3mbypanel/scripts/manage.sh diagnostics
sudo /opt/3mbypanel/scripts/manage.sh repair
```

Confirm diagnostics are created locally and inspect them before sharing.

## Failure logs

```bash
cd /opt/3mbypanel
sudo docker compose --env-file .env logs --tail=400 \
  emby control-api control-worker ops-agent postgres m3u-gateway media-gateway control-web
```
