# 3mbyPanel v0.1.0

3mbyPanel is a Docker-based management layer for Emby. This first full test release ports the tested JellyPanel feature set to Emby-native REST API paths and authentication.

No media, channels, guide data, or Emby Premiere subscription is included. Use only media and sources you are authorized to operate.

## Included features

- Managed Emby Server container on a configurable host port.
- Administrator, master-reseller, reseller, package, credit, and audit systems.
- Create, import, link, renew, suspend, enable, update, and delete Emby users.
- Existing-user import with preview, protected administrator accounts, package assignment, reseller ownership, and permission-preservation options.
- Multiple Emby servers with encrypted API-key storage, health checks, per-user assignments, user synchronization, and combined sessions.
- Account expiration and five-minute policy synchronization.
- Simultaneous stream limits and optional excess-session stopping.
- Current sessions with user, server, device, IP, content, playback method, codecs, resolution, bitrate, and transcoding details.
- On-screen messages and playback-stop controls when supported by the client.
- Multiple M3U and XMLTV sources, category filtering, private playlist gateway, guide refresh, and automatic EPG mapping.
- Rclone-aware media inventory without ffprobe.
- Movie and TV STRM/NFO mirror with TMDB metadata, posters, backdrops, incremental updates, and missing-file cleanup.
- Operations Center, service health, storage checks, diagnostics, nightly backup, restore, update history, repair, and rollback support.

## Emby API behavior

3mbyPanel uses an Emby API key and the Emby REST root ending in `/emby`. Additional servers can be entered as either a server root such as `http://10.0.0.25:8096` or an API root such as `http://10.0.0.25:8096/emby`; the panel normalizes the address.

Emby does not expose existing user passwords. Imported accounts keep their original password on the source server. After an administrator sets a new password through 3mbyPanel, that new password can be synchronized to assigned servers.

## Supported test platform

The installer is designed for a clean Ubuntu Server 24.04 LTS host using `amd64` or `arm64`.

Recommended minimum:

- 4 GB RAM.
- 2 CPU cores.
- 10 GB free application storage, excluding media and rclone cache.
- Docker-compatible kernel.
- A media mount such as `/mnt/unionfs`.

This v0.1.0 package passed static and mocked integration validation. The first complete Emby-container runtime validation must be performed on a real Ubuntu server before public production use.

## Default ports

The defaults intentionally avoid a normal Emby installation on 8096 and the JellyPanel test stack on 8181/8097.

```text
3mbyPanel panel:       8281
Control API:           8282, localhost only
M3U gateway:           8283, localhost only
Managed Emby:          8098
Media mount:           /mnt/unionfs
Media inventory root:  /mnt/unionfs/Media
Install directory:     /opt/3mbypanel
```

Internal Docker-only ports remain isolated from the host.

## Fresh installation

Copy the ZIP and checksum to the server:

```bash
sudo apt-get update
sudo apt-get install -y unzip

sha256sum -c 3mbypanel-v0.1.0.zip.sha256
unzip 3mbypanel-v0.1.0.zip
cd 3mbypanel-v0.1.0
sudo bash install.sh
```

Select:

```text
1) Fresh installation
```

The guided installer asks for:

- Media mount and inventory root.
- Rclone remote and configuration directory.
- Timezone.
- Panel administrator credentials.
- Managed Emby and panel ports.
- Optional `/dev/dri` access.

After installation, retrieve the panel login with:

```bash
sudo cat /opt/3mbypanel/panel-admin-credentials.txt
```

Open the managed Emby URL printed by the installer, complete the normal Emby setup, and create an API key under the Emby server dashboard security/API-key area. Save it with:

```bash
sudo /opt/3mbypanel/scripts/set-emby-api-key.sh
```

Then open the 3mbyPanel URL.

## Adding an existing Emby server

The managed Emby instance is registered as the default local server. To manage an existing Emby installation:

1. Create an API key on that Emby server.
2. Open **Servers → Add Server**.
3. Enter a server-reachable internal address, public address, and API key.
4. Test and save the server.
5. Open **Import users**, scan the server, preview the accounts, and import or link selected users.

For another machine, do not enter `127.0.0.1`. Use an address reachable from inside the 3mbyPanel Docker network, such as the server LAN IP, VPN IP, or resolvable DNS name.

## Non-interactive fresh installation

```bash
export MBYPANEL_PANEL_PASSWORD='replace-with-a-strong-password'

sudo -E bash install.sh \
  --mode fresh \
  --non-interactive \
  --media-path /mnt/unionfs \
  --scan-root /mnt/unionfs/Media \
  --rclone-remote union: \
  --rclone-config-dir /root/.config/rclone \
  --timezone America/Chicago \
  --panel-user admin \
  --emby-port 8098 \
  --panel-port 8281 \
  --api-port 8282 \
  --m3u-port 8283
```

## Upgrade, repair, diagnostics, restore, and uninstall

```bash
sudo bash install.sh --mode upgrade
sudo bash install.sh --mode repair
sudo bash install.sh --mode diagnostics
sudo bash install.sh --mode restore
sudo bash install.sh --mode uninstall
```

The update path creates a local rollback snapshot and requests a managed backup when the Operations Agent is available. Application files roll back automatically when deployment validation fails. Additive database migrations remain in place.

Data-preserving uninstall removes the containers and network but keeps Emby configuration, PostgreSQL, Redis, backups, logs, STRM files, and media.

## Management commands

```bash
sudo /opt/3mbypanel/scripts/manage.sh status
sudo /opt/3mbypanel/scripts/manage.sh health
sudo /opt/3mbypanel/scripts/manage.sh logs
sudo /opt/3mbypanel/scripts/manage.sh backup
sudo /opt/3mbypanel/scripts/manage.sh diagnostics
sudo /opt/3mbypanel/scripts/manage.sh servers
sudo /opt/3mbypanel/scripts/manage.sh imports
sudo /opt/3mbypanel/scripts/manage.sh streams
sudo /opt/3mbypanel/scripts/manage.sh credentials
sudo /opt/3mbypanel/scripts/manage.sh panel-password
sudo /opt/3mbypanel/scripts/manage.sh emby-key
```

## Backup behavior

A managed backup contains:

- 3mbyPanel PostgreSQL.
- `.env` snapshot for reference.
- Emby configuration archive.
- Optional STRM mirror archive.
- Checksums and manifest.

To produce a consistent Emby configuration archive, the managed Emby container is briefly stopped while its configuration is compressed, then restarted. A restore also temporarily stops Emby and the dependent 3mbyPanel application services.

External Emby servers registered in the Servers page are not backed up by this panel. Use each external server's own backup method.

## Persistent data

```text
/opt/3mbypanel/.env
/opt/3mbypanel/emby/config
/opt/3mbypanel/postgres/data
/opt/3mbypanel/redis/data
/opt/3mbypanel/backups
/opt/3mbypanel/logs
/opt/3mbypanel/strm-library
```

The media mount itself is never removed or included in application backups.

## Hardware acceleration

When `/dev/dri` exists, the installer can pass it to Emby and add the host `video` and `render` group IDs. Hardware acceleration must still be configured inside Emby and may require Emby Premiere depending on the feature and Emby licensing.

## Security

- Control API and M3U gateway bind to localhost by default.
- Operations Agent and media gateway are Docker-internal.
- Remote Emby API keys are encrypted at rest with the application secret.
- Do not publicly expose the panel or Emby over plain HTTP.
- Use a reverse proxy, HTTPS, firewall restrictions, and strong credentials before public deployment.
- Protect `.env`, backups, credentials, diagnostics, and API keys.
- Review `SECURITY.md` before deployment.

## Release validation

The ZIP includes `release-files.sha256`. Fresh, upgrade, and repair modes verify release files before modifying the server.

Validation includes:

- Python compilation for every service.
- Bash syntax checks for every script.
- Docker Compose YAML parsing.
- Browser JavaScript syntax validation.
- Migration sequence and table-reference checks.
- Emby API compatibility-wrapper tests.
- Existing-user import classification tests.
- Archive CRC, executable mode, extraction, and internal checksum verification.

Docker is unavailable in the build environment, so use `TEST-EMBY.md` for the first real-server test.
