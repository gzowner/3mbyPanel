from __future__ import annotations

from pathlib import Path

import asyncpg

MIGRATIONS_DIR = Path(__file__).resolve().parent.parent / "migrations"


async def apply_migrations(pool: asyncpg.Pool) -> None:
    async with pool.acquire() as connection:
        await connection.execute(
            """
            CREATE TABLE IF NOT EXISTS schema_version (
                version INTEGER PRIMARY KEY,
                applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
            """
        )
        applied_rows = await connection.fetch("SELECT version FROM schema_version")
        applied = {int(row["version"]) for row in applied_rows}

        for path in sorted(MIGRATIONS_DIR.glob("*.sql")):
            try:
                version = int(path.name.split("_", 1)[0])
            except ValueError:
                continue
            if version in applied:
                continue
            sql = path.read_text(encoding="utf-8")
            async with connection.transaction():
                await connection.execute(sql)
                await connection.execute(
                    "INSERT INTO schema_version (version) VALUES ($1) ON CONFLICT DO NOTHING",
                    version,
                )
            applied.add(version)
