from __future__ import annotations

import asyncio
import gzip
import io
import json
import re
import unicodedata
import uuid
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from difflib import SequenceMatcher
from typing import Any

import asyncpg
import httpx
from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field

from .access import require_admin_role
from .m3u import effective_epg_urls, get_pool
from .security import PanelSession, ensure_writes_enabled, require_session, validate_csrf

router = APIRouter(prefix="/epg-mapper", tags=["EPG Mapper"])

QUALITY_TOKENS = {
    "hd", "fhd", "uhd", "4k", "sd", "1080p", "720p", "2160p", "hevc",
    "h264", "h265", "backup", "raw", "east", "west", "feed", "channel",
    "the", "network", "television", "tv",
}
COUNTRY_PREFIX_RE = re.compile(r"^(?:us|usa|uk|ca|can|au|nz|latino|es|mx|de|fr|it|pt)\s*[|:\-]\s*", re.I)
NUMBER_RE = re.compile(r"(?<!\d)(\d{1,5}(?:\.\d+)?)(?!\d)")


class ApplyRequest(BaseModel):
    source_id: uuid.UUID | None = None
    minimum_confidence: int = Field(default=88, ge=50, le=100)
    include_ambiguous: bool = False


class ManualMappingRequest(BaseModel):
    channel_id: uuid.UUID
    xmltv_id: str = Field(min_length=1, max_length=500)
    feed_index: int = Field(default=0, ge=0, le=100)


class ClearMappingRequest(BaseModel):
    channel_id: uuid.UUID


class MapperCancelled(Exception):
    pass


@dataclass(frozen=True)
class CatalogChannel:
    xmltv_id: str
    display_name: str
    normalized_name: str
    channel_number: str
    icon_url: str
    feed_index: int


async def read_session(session: PanelSession = Depends(require_session)) -> PanelSession:
    require_admin_role(session)
    return session


async def write_session(
    request: Request,
    session: PanelSession = Depends(require_session),
) -> PanelSession:
    require_admin_role(session)
    ensure_writes_enabled()
    validate_csrf(session, request.headers.get("X-CSRF-Token"))
    return session


async def audit(
    request: Request,
    action: str,
    *,
    actor: str,
    target_id: str | None = None,
    details: dict[str, Any] | None = None,
) -> None:
    pool = get_pool(request)
    async with pool.acquire() as connection:
        await connection.execute(
            """
            INSERT INTO audit_log (actor_type, actor_id, action, target_type, target_id, details)
            VALUES ('panel', $1, $2, 'epg_mapper', $3, $4::jsonb)
            """,
            actor,
            action,
            target_id,
            json.dumps(details or {}),
        )


def chunks(values: list[Any], size: int = 500):
    for index in range(0, len(values), size):
        yield values[index:index + size]


def normalize_name(value: str) -> str:
    value = unicodedata.normalize("NFKD", value or "")
    value = "".join(ch for ch in value if not unicodedata.combining(ch))
    value = value.casefold().replace("&", " and ")
    value = COUNTRY_PREFIX_RE.sub("", value)
    value = re.sub(r"\([^)]*\)|\[[^]]*\]|\{[^}]*\}", " ", value)
    value = re.sub(r"[^a-z0-9]+", " ", value)
    tokens = [token for token in value.split() if token not in QUALITY_TOKENS]
    return " ".join(tokens).strip()


def extract_channel_number(*values: str) -> str:
    for value in values:
        if not value:
            continue
        match = NUMBER_RE.search(value)
        if match:
            return match.group(1)
    return ""


def local_tag(element: ET.Element) -> str:
    return element.tag.rsplit("}", 1)[-1]


def parse_xmltv_channels(data: bytes, feed_index: int) -> list[CatalogChannel]:
    if data[:2] == b"\x1f\x8b":
        with gzip.GzipFile(fileobj=io.BytesIO(data), mode="rb") as handle:
            data = handle.read(536_870_913)
        if len(data) > 536_870_912:
            raise ValueError("Decompressed XMLTV data exceeds the 512 MB safety limit")
    channels: list[CatalogChannel] = []
    for event, elem in ET.iterparse(io.BytesIO(data), events=("end",)):
        tag_name = local_tag(elem)
        if tag_name == "programme":
            elem.clear()
            continue
        if tag_name != "channel":
            continue
        xmltv_id = (elem.attrib.get("id") or "").strip()
        if not xmltv_id:
            elem.clear()
            continue
        names: list[str] = []
        icon_url = ""
        for child in list(elem):
            tag = local_tag(child)
            if tag == "display-name" and child.text and child.text.strip():
                names.append(child.text.strip())
            elif tag == "icon" and not icon_url:
                icon_url = (child.attrib.get("src") or "").strip()
        number = extract_channel_number(*names)
        named_values = [name for name in names if not re.fullmatch(r"\d+(?:\.\d+)?", name.strip())]
        display_name = named_values[0] if named_values else (names[0] if names else xmltv_id)
        normalized = normalize_name(display_name)
        channels.append(
            CatalogChannel(
                xmltv_id=xmltv_id,
                display_name=display_name,
                normalized_name=normalized,
                channel_number=number,
                icon_url=icon_url,
                feed_index=feed_index,
            )
        )
        elem.clear()
    return channels


async def fetch_feed(request: Request, url: str, user_agent: str) -> bytes:
    headers = {"User-Agent": user_agent} if user_agent else {}
    response = await request.app.state.http.get(
        url,
        headers=headers,
        follow_redirects=True,
        timeout=httpx.Timeout(240.0, connect=30.0),
    )
    response.raise_for_status()
    data = response.content
    if not data:
        raise ValueError("XMLTV response was empty")
    if len(data) > 536_870_912:
        raise ValueError("XMLTV response exceeds the 512 MB safety limit")
    return data


def score_candidate(
    *,
    tvg_id: str,
    names: list[str],
    channel_number: str,
    candidate: CatalogChannel,
) -> tuple[int, str]:
    if tvg_id and tvg_id.casefold() == candidate.xmltv_id.casefold():
        return 100, "exact_tvg_id"

    normalized_names = [normalize_name(value) for value in names if value]
    normalized_names = [value for value in normalized_names if value]
    if candidate.normalized_name and candidate.normalized_name in normalized_names:
        return 97, "exact_name"

    best_ratio = 0.0
    for value in normalized_names:
        best_ratio = max(best_ratio, SequenceMatcher(None, value, candidate.normalized_name).ratio())

    number_match = bool(
        channel_number
        and candidate.channel_number
        and channel_number.casefold() == candidate.channel_number.casefold()
    )
    if number_match and best_ratio >= 0.68:
        return min(95, round(86 + best_ratio * 9)), "number_and_name"
    if best_ratio >= 0.94:
        return min(94, round(78 + best_ratio * 16)), "strong_name"
    if best_ratio >= 0.86:
        return min(89, round(70 + best_ratio * 20)), "fuzzy_name"
    if number_match:
        return 76, "channel_number"
    return 0, ""


async def is_cancelled(pool: asyncpg.Pool, run_id: uuid.UUID) -> bool:
    async with pool.acquire() as connection:
        return bool(
            await connection.fetchval(
                "SELECT cancel_requested FROM epg_mapper_runs WHERE id = $1",
                run_id,
            )
        )


async def update_run(pool: asyncpg.Pool, run_id: uuid.UUID, **values: Any) -> None:
    if not values:
        return
    allowed = {
        "status", "feeds_scanned", "epg_channels", "m3u_channels", "exact_matches",
        "suggested_matches", "ambiguous_matches", "unmatched_channels",
        "duplicate_epg_ids", "current_item", "error", "started_at", "finished_at",
    }
    assignments: list[str] = []
    args: list[Any] = [run_id]
    for key, value in values.items():
        if key not in allowed:
            continue
        args.append(value)
        assignments.append(f"{key} = ${len(args)}")
    if not assignments:
        return
    async with pool.acquire() as connection:
        await connection.execute(
            f"UPDATE epg_mapper_runs SET {', '.join(assignments)} WHERE id = $1",
            *args,
        )


async def process_source(request: Request, run_id: uuid.UUID, source: asyncpg.Record) -> dict[str, int]:
    pool = get_pool(request)
    source_id = source["id"]
    urls = effective_epg_urls(source["epg_urls"], source["detected_epg_urls"])
    if not source["epg_enabled"] or not urls:
        return {"feeds": 0, "epg": 0, "m3u": 0, "exact": 0, "suggested": 0, "ambiguous": 0, "unmatched": 0, "duplicates": 0}

    catalog: list[CatalogChannel] = []
    for feed_index, url in enumerate(urls):
        if await is_cancelled(pool, run_id):
            raise MapperCancelled()
        await update_run(pool, run_id, current_item=f"Downloading {source['name']} feed {feed_index + 1}")
        data = await fetch_feed(request, url, source["epg_user_agent"] or source["user_agent"] or "")
        parsed = await asyncio.to_thread(parse_xmltv_channels, data, feed_index)
        catalog.extend(parsed)

    id_counts = Counter(entry.xmltv_id.casefold() for entry in catalog)
    async with pool.acquire() as connection:
        async with connection.transaction():
            await connection.execute(
                "UPDATE epg_catalog_channels SET active=FALSE, updated_at=NOW() WHERE source_id=$1",
                source_id,
            )
            catalog_rows = [
                (source_id, entry.feed_index, entry.xmltv_id, entry.display_name,
                 entry.normalized_name, entry.channel_number, entry.icon_url,
                 id_counts[entry.xmltv_id.casefold()])
                for entry in catalog
            ]
            catalog_sql = """
                INSERT INTO epg_catalog_channels
                    (source_id, feed_index, xmltv_id, display_name, normalized_name,
                     channel_number, icon_url, duplicate_count, active, last_seen_at)
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,TRUE,NOW())
                ON CONFLICT (source_id, feed_index, xmltv_id) DO UPDATE SET
                    display_name=EXCLUDED.display_name,
                    normalized_name=EXCLUDED.normalized_name,
                    channel_number=EXCLUDED.channel_number,
                    icon_url=EXCLUDED.icon_url,
                    duplicate_count=EXCLUDED.duplicate_count,
                    active=TRUE,
                    last_seen_at=NOW(),
                    updated_at=NOW()
            """
            for batch in chunks(catalog_rows):
                await connection.executemany(catalog_sql, batch)
            channels = await connection.fetch(
                """
                SELECT ch.id, ch.name, ch.tvg_id, ch.tvg_name, ch.channel_number,
                       o.xmltv_id AS override_xmltv_id, o.feed_index AS override_feed_index,
                       o.epg_name AS override_epg_name
                FROM m3u_channels ch
                LEFT JOIN epg_mapping_overrides o ON o.channel_id=ch.id
                WHERE ch.source_id=$1 AND ch.active=TRUE
                ORDER BY ch.name
                """,
                source_id,
            )

    by_id: dict[str, list[CatalogChannel]] = defaultdict(list)
    by_normalized: dict[str, list[CatalogChannel]] = defaultdict(list)
    by_first_token: dict[str, list[CatalogChannel]] = defaultdict(list)
    by_number: dict[str, list[CatalogChannel]] = defaultdict(list)
    candidates = sorted(catalog, key=lambda item: (item.feed_index, item.display_name.casefold(), item.xmltv_id.casefold()))
    for entry in candidates:
        by_id[entry.xmltv_id.casefold()].append(entry)
        if entry.normalized_name:
            by_normalized[entry.normalized_name].append(entry)
            by_first_token[entry.normalized_name.split()[0]].append(entry)
        if entry.channel_number:
            by_number[entry.channel_number.casefold()].append(entry)

    exact = suggested = ambiguous = unmatched = 0
    updates: list[tuple[Any, ...]] = []
    for index, channel in enumerate(channels, start=1):
        if index % 100 == 0:
            if await is_cancelled(pool, run_id):
                raise MapperCancelled()
            await update_run(pool, run_id, current_item=f"Matching {source['name']}: {index}/{len(channels)}")

        if channel["override_xmltv_id"]:
            chosen = next(
                (
                    item for item in candidates
                    if item.feed_index == channel["override_feed_index"]
                    and item.xmltv_id == channel["override_xmltv_id"]
                ),
                None,
            )
            epg_name = chosen.display_name if chosen else channel["override_epg_name"] or channel["override_xmltv_id"]
            updates.append((channel["id"], channel["override_xmltv_id"], epg_name, channel["override_feed_index"], "manual", 100, False))
            exact += 1
            continue

        ranked: list[tuple[int, int, CatalogChannel, str]] = []
        if channel["tvg_id"]:
            for entry in by_id.get(channel["tvg_id"].casefold(), []):
                ranked.append((100, entry.feed_index, entry, "exact_tvg_id"))
        if not ranked:
            names = [channel["name"], channel["tvg_name"]]
            normalized_names = [normalize_name(value) for value in names if value]
            channel_number = channel["channel_number"] or extract_channel_number(channel["name"])
            exact_name_candidates: list[CatalogChannel] = []
            for normalized in normalized_names:
                exact_name_candidates.extend(by_normalized.get(normalized, []))
            if exact_name_candidates:
                for entry in dict.fromkeys(exact_name_candidates):
                    ranked.append((97, entry.feed_index, entry, "exact_name"))
            else:
                candidate_pool: dict[tuple[int, str], CatalogChannel] = {}
                for normalized in normalized_names:
                    if normalized:
                        for entry in by_first_token.get(normalized.split()[0], []):
                            candidate_pool[(entry.feed_index, entry.xmltv_id)] = entry
                if channel_number:
                    for entry in by_number.get(channel_number.casefold(), []):
                        candidate_pool[(entry.feed_index, entry.xmltv_id)] = entry
                for entry in candidate_pool.values():
                    score, method = score_candidate(
                        tvg_id=channel["tvg_id"],
                        names=names,
                        channel_number=channel_number,
                        candidate=entry,
                    )
                    if score:
                        ranked.append((score, entry.feed_index, entry, method))
        ranked.sort(key=lambda item: (-item[0], item[1], item[2].display_name.casefold(), item[2].xmltv_id.casefold()))

        if not ranked:
            updates.append((channel["id"], "", "", None, "", 0, False))
            unmatched += 1
            continue
        best = ranked[0]
        is_ambiguous = len(ranked) > 1 and ranked[1][0] >= best[0] - 2 and ranked[1][2].xmltv_id != best[2].xmltv_id
        updates.append((channel["id"], best[2].xmltv_id, best[2].display_name, best[2].feed_index, best[3], best[0], is_ambiguous))
        if is_ambiguous:
            ambiguous += 1
        elif best[0] >= 96:
            exact += 1
        elif best[0] >= 80:
            suggested += 1
        else:
            unmatched += 1

    async with pool.acquire() as connection:
        async with connection.transaction():
            update_rows: list[tuple[Any, ...]] = []
            for update in updates:
                status = "unmatched"
                if update[1]:
                    status = "ambiguous" if update[6] else ("exact" if update[5] >= 96 else "suggested")
                update_rows.append((update[0], update[1], update[2], update[3], status, update[4], update[5], update[6]))
            update_sql = """
                UPDATE m3u_channels
                SET suggested_tvg_id=$2,
                    suggested_epg_name=$3,
                    suggested_feed_index=$4,
                    mapping_status=$5,
                    mapping_method=$6,
                    mapping_confidence=$7,
                    mapping_ambiguous=$8,
                    mapping_updated_at=NOW(),
                    updated_at=NOW()
                WHERE id=$1
            """
            for batch in chunks(update_rows):
                await connection.executemany(update_sql, batch)

    duplicate_count = sum(1 for count in id_counts.values() if count > 1)
    return {
        "feeds": len(urls),
        "epg": len(catalog),
        "m3u": len(channels),
        "exact": exact,
        "suggested": suggested,
        "ambiguous": ambiguous,
        "unmatched": unmatched,
        "duplicates": duplicate_count,
    }


async def run_mapper(request: Request, run_id: uuid.UUID, source_id: uuid.UUID | None) -> None:
    pool = get_pool(request)
    try:
        await update_run(pool, run_id, status="running", started_at=datetime.now(timezone.utc), current_item="Starting")
        async with pool.acquire() as connection:
            if source_id:
                sources = await connection.fetch(
                    """
                    SELECT id, name, user_agent, epg_user_agent, epg_urls,
                           detected_epg_urls, epg_enabled
                    FROM m3u_sources WHERE id=$1 AND enabled=TRUE
                    """,
                    source_id,
                )
            else:
                sources = await connection.fetch(
                    """
                    SELECT id, name, user_agent, epg_user_agent, epg_urls,
                           detected_epg_urls, epg_enabled
                    FROM m3u_sources WHERE enabled=TRUE ORDER BY name
                    """
                )
        totals = Counter()
        for source in sources:
            result = await process_source(request, run_id, source)
            totals.update(result)
            await update_run(
                pool,
                run_id,
                feeds_scanned=totals["feeds"],
                epg_channels=totals["epg"],
                m3u_channels=totals["m3u"],
                exact_matches=totals["exact"],
                suggested_matches=totals["suggested"],
                ambiguous_matches=totals["ambiguous"],
                unmatched_channels=totals["unmatched"],
                duplicate_epg_ids=totals["duplicates"],
            )
        await update_run(pool, run_id, status="completed", current_item="", finished_at=datetime.now(timezone.utc))
    except MapperCancelled:
        await update_run(pool, run_id, status="cancelled", current_item="", error="Cancelled by administrator", finished_at=datetime.now(timezone.utc))
    except Exception as exc:
        await update_run(pool, run_id, status="failed", current_item="", error=str(exc)[:2000], finished_at=datetime.now(timezone.utc))
    finally:
        try:
            await request.app.state.redis.delete("mbypanel:epg-mapper:lock")
        except Exception:
            pass


@router.get("/status")
async def mapper_status(request: Request, _: PanelSession = Depends(read_session)) -> dict[str, Any]:
    pool = get_pool(request)
    async with pool.acquire() as connection:
        stats = await connection.fetchrow(
            """
            SELECT
              COUNT(*) FILTER (WHERE ch.active=TRUE)::int AS channels,
              COUNT(*) FILTER (WHERE ch.active=TRUE AND ch.mapping_status='exact')::int AS exact,
              COUNT(*) FILTER (WHERE ch.active=TRUE AND ch.mapping_status='suggested')::int AS suggested,
              COUNT(*) FILTER (WHERE ch.active=TRUE AND ch.mapping_status='ambiguous')::int AS ambiguous,
              COUNT(*) FILTER (WHERE ch.active=TRUE AND ch.mapping_status IN ('unmatched','unscanned'))::int AS unmatched,
              COUNT(*) FILTER (WHERE ch.active=TRUE AND BTRIM(ch.mapped_tvg_id)<>'')::int AS applied,
              COUNT(*) FILTER (WHERE ch.active=TRUE AND BTRIM(ch.tvg_id)='')::int AS missing_original_id
            FROM m3u_channels ch
            """
        )
        catalog = await connection.fetchrow(
            """
            SELECT COUNT(*) FILTER (WHERE active=TRUE)::int AS epg_channels,
                   COUNT(*) FILTER (WHERE active=TRUE AND duplicate_count>1)::int AS duplicate_rows
            FROM epg_catalog_channels
            """
        )
        run = await connection.fetchrow(
            "SELECT * FROM epg_mapper_runs ORDER BY created_at DESC LIMIT 1"
        )
    return {"stats": dict(stats), "catalog": dict(catalog), "last_run": dict(run) if run else None}


@router.post("/scan", status_code=202)
async def start_scan(
    request: Request,
    source_id: uuid.UUID | None = None,
    session: PanelSession = Depends(write_session),
) -> dict[str, Any]:
    pool = get_pool(request)
    try:
        locked = await request.app.state.redis.set("mbypanel:epg-mapper:lock", "1", ex=7200, nx=True)
    except Exception:
        locked = True
    if not locked:
        raise HTTPException(status_code=409, detail="An EPG mapping scan is already running.")
    async with pool.acquire() as connection:
        run_id = await connection.fetchval(
            """
            INSERT INTO epg_mapper_runs (source_id, status, created_by)
            VALUES ($1,'queued',$2) RETURNING id
            """,
            source_id,
            session.username,
        )
    task = asyncio.create_task(run_mapper(request, run_id, source_id))
    request.app.state.background_tasks.add(task)
    task.add_done_callback(request.app.state.background_tasks.discard)
    await audit(request, "epg_mapper.scan.start", actor=session.username, target_id=str(run_id), details={"source_id": str(source_id) if source_id else None})
    return {"job_id": str(run_id), "status": "queued"}


@router.get("/scan/{run_id}")
async def scan_job(run_id: uuid.UUID, request: Request, _: PanelSession = Depends(read_session)) -> dict[str, Any]:
    pool = get_pool(request)
    async with pool.acquire() as connection:
        row = await connection.fetchrow("SELECT * FROM epg_mapper_runs WHERE id=$1", run_id)
    if row is None:
        raise HTTPException(status_code=404, detail="EPG mapping job not found.")
    return dict(row)


@router.post("/scan/{run_id}/stop")
async def stop_scan(run_id: uuid.UUID, request: Request, session: PanelSession = Depends(write_session)) -> dict[str, Any]:
    pool = get_pool(request)
    async with pool.acquire() as connection:
        result = await connection.execute(
            "UPDATE epg_mapper_runs SET cancel_requested=TRUE WHERE id=$1 AND status IN ('queued','running')",
            run_id,
        )
    if result.endswith("0"):
        raise HTTPException(status_code=409, detail="The EPG mapping scan is not running.")
    await audit(request, "epg_mapper.scan.stop", actor=session.username, target_id=str(run_id))
    return {"stopping": True}


@router.get("/channels")
async def mapping_channels(
    request: Request,
    source_id: uuid.UUID | None = None,
    status: str = Query(default="all", pattern="^(all|exact|suggested|ambiguous|unmatched|applied)$"),
    search: str = Query(default="", max_length=200),
    limit: int = Query(default=200, ge=1, le=1000),
    offset: int = Query(default=0, ge=0),
    _: PanelSession = Depends(read_session),
) -> dict[str, Any]:
    pool = get_pool(request)
    conditions = ["ch.active=TRUE"]
    args: list[Any] = []
    if source_id:
        args.append(source_id)
        conditions.append(f"ch.source_id=${len(args)}")
    if status == "applied":
        conditions.append("BTRIM(ch.mapped_tvg_id)<>''")
    elif status == "unmatched":
        conditions.append("ch.mapping_status IN ('unmatched','unscanned')")
    elif status != "all":
        args.append(status)
        conditions.append(f"ch.mapping_status=${len(args)}")
    if search.strip():
        args.append(f"%{search.strip()}%")
        conditions.append(f"(ch.name ILIKE ${len(args)} OR ch.tvg_id ILIKE ${len(args)} OR ch.suggested_tvg_id ILIKE ${len(args)} OR ch.suggested_epg_name ILIKE ${len(args)})")
    where = " AND ".join(conditions)
    args.extend([limit, offset])
    async with pool.acquire() as connection:
        rows = await connection.fetch(
            f"""
            SELECT ch.id::text, ch.source_id::text, s.name AS source_name,
                   ch.name, ch.tvg_id, ch.tvg_name, ch.channel_number,
                   ch.mapped_tvg_id, ch.suggested_tvg_id, ch.suggested_epg_name,
                   ch.suggested_feed_index, ch.mapping_status, ch.mapping_method,
                   ch.mapping_confidence, ch.mapping_ambiguous,
                   (o.channel_id IS NOT NULL) AS manual_override
            FROM m3u_channels ch
            JOIN m3u_sources s ON s.id=ch.source_id
            LEFT JOIN epg_mapping_overrides o ON o.channel_id=ch.id
            WHERE {where}
            ORDER BY s.name, ch.name
            LIMIT ${len(args)-1} OFFSET ${len(args)}
            """,
            *args,
        )
        count_args = args[:-2]
        total = await connection.fetchval(
            f"SELECT COUNT(*) FROM m3u_channels ch WHERE {where}",
            *count_args,
        )
    return {"items": [dict(row) for row in rows], "total": int(total), "limit": limit, "offset": offset}


@router.get("/catalog")
async def catalog_search(
    request: Request,
    source_id: uuid.UUID,
    search: str = Query(default="", max_length=200),
    limit: int = Query(default=100, ge=1, le=500),
    _: PanelSession = Depends(read_session),
) -> dict[str, Any]:
    pool = get_pool(request)
    pattern = f"%{search.strip()}%"
    async with pool.acquire() as connection:
        rows = await connection.fetch(
            """
            SELECT feed_index, xmltv_id, display_name, channel_number, icon_url, duplicate_count
            FROM epg_catalog_channels
            WHERE source_id=$1 AND active=TRUE
              AND ($2='' OR display_name ILIKE $3 OR xmltv_id ILIKE $3)
            ORDER BY feed_index, display_name
            LIMIT $4
            """,
            source_id,
            search.strip(),
            pattern,
            limit,
        )
    return {"items": [dict(row) for row in rows]}


@router.post("/apply")
async def apply_mappings(request: Request, data: ApplyRequest, session: PanelSession = Depends(write_session)) -> dict[str, Any]:
    pool = get_pool(request)
    conditions = ["active=TRUE", "BTRIM(suggested_tvg_id)<>''", "mapping_confidence >= $1"]
    args: list[Any] = [data.minimum_confidence]
    if not data.include_ambiguous:
        conditions.append("mapping_ambiguous=FALSE")
    if data.source_id:
        args.append(data.source_id)
        conditions.append(f"source_id=${len(args)}")
    where = " AND ".join(conditions)
    async with pool.acquire() as connection:
        result = await connection.execute(
            f"""
            UPDATE m3u_channels
            SET mapped_tvg_id=suggested_tvg_id,
                mapping_status=CASE WHEN mapping_method='manual' THEN 'exact' ELSE mapping_status END,
                mapping_updated_at=NOW(), updated_at=NOW()
            WHERE {where}
            """,
            *args,
        )
    applied = int(result.split()[-1])
    await audit(request, "epg_mapper.apply", actor=session.username, details={"applied": applied, "minimum_confidence": data.minimum_confidence, "source_id": str(data.source_id) if data.source_id else None})
    return {"applied": applied}


@router.post("/manual")
async def manual_mapping(request: Request, data: ManualMappingRequest, session: PanelSession = Depends(write_session)) -> dict[str, Any]:
    pool = get_pool(request)
    async with pool.acquire() as connection:
        channel = await connection.fetchrow("SELECT source_id FROM m3u_channels WHERE id=$1", data.channel_id)
        if channel is None:
            raise HTTPException(status_code=404, detail="M3U channel not found.")
        epg = await connection.fetchrow(
            """
            SELECT display_name FROM epg_catalog_channels
            WHERE source_id=$1 AND feed_index=$2 AND xmltv_id=$3 AND active=TRUE
            """,
            channel["source_id"], data.feed_index, data.xmltv_id,
        )
        if epg is None:
            raise HTTPException(status_code=404, detail="XMLTV channel is not present in the current EPG catalog.")
        async with connection.transaction():
            await connection.execute(
                """
                INSERT INTO epg_mapping_overrides
                    (channel_id, source_id, xmltv_id, feed_index, epg_name, created_by)
                VALUES ($1,$2,$3,$4,$5,$6)
                ON CONFLICT (channel_id) DO UPDATE SET
                    xmltv_id=EXCLUDED.xmltv_id, feed_index=EXCLUDED.feed_index,
                    epg_name=EXCLUDED.epg_name, created_by=EXCLUDED.created_by,
                    updated_at=NOW()
                """,
                data.channel_id, channel["source_id"], data.xmltv_id, data.feed_index, epg["display_name"], session.username,
            )
            await connection.execute(
                """
                UPDATE m3u_channels SET
                    mapped_tvg_id=$2, suggested_tvg_id=$2, suggested_epg_name=$3,
                    suggested_feed_index=$4, mapping_status='exact', mapping_method='manual',
                    mapping_confidence=100, mapping_ambiguous=FALSE,
                    mapping_updated_at=NOW(), updated_at=NOW()
                WHERE id=$1
                """,
                data.channel_id, data.xmltv_id, epg["display_name"], data.feed_index,
            )
    await audit(request, "epg_mapper.manual", actor=session.username, target_id=str(data.channel_id), details={"xmltv_id": data.xmltv_id, "feed_index": data.feed_index})
    return {"mapped": True, "xmltv_id": data.xmltv_id, "epg_name": epg["display_name"]}


@router.post("/clear")
async def clear_mapping(request: Request, data: ClearMappingRequest, session: PanelSession = Depends(write_session)) -> dict[str, Any]:
    pool = get_pool(request)
    async with pool.acquire() as connection:
        async with connection.transaction():
            await connection.execute("DELETE FROM epg_mapping_overrides WHERE channel_id=$1", data.channel_id)
            result = await connection.execute(
                """
                UPDATE m3u_channels SET mapped_tvg_id='', mapping_updated_at=NOW(), updated_at=NOW()
                WHERE id=$1
                """,
                data.channel_id,
            )
    if result.endswith("0"):
        raise HTTPException(status_code=404, detail="M3U channel not found.")
    await audit(request, "epg_mapper.clear", actor=session.username, target_id=str(data.channel_id))
    return {"cleared": True}
