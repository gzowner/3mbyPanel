from __future__ import annotations

import asyncio
import json
import uuid
from dataclasses import dataclass
from typing import Any, Iterable
from urllib.parse import urlsplit, urlunsplit

import asyncpg
import httpx
from fastapi import HTTPException

from .secret_store import decrypt_secret, encrypt_secret
from .settings import settings


SYNC_POLICY_FIELDS = (
    "IsAdministrator",
    "IsHidden",
    "IsDisabled",
    "EnableMediaPlayback",
    "EnableAudioPlaybackTranscoding",
    "EnableVideoPlaybackTranscoding",
    "EnablePlaybackRemuxing",
    "EnableLiveTvAccess",
    "EnableLiveTvManagement",
    "EnableContentDownloading",
    "EnableRemoteAccess",
    "SimultaneousStreamLimit",
    "EnableContentDeletion",
    "EnableCollectionManagement",
    "EnableSubtitleManagement",
    "EnablePublicSharing",
    "EnableAllChannels",
    "EnabledChannels",
    "EnableAllFolders",
    "EnabledFolders",
)


@dataclass(slots=True)
class EmbyServer:
    id: uuid.UUID
    name: str
    internal_url: str
    public_url: str
    api_key: str
    enabled: bool
    is_default: bool
    is_local: bool
    verify_tls: bool
    connect_timeout_seconds: int
    notes: str = ""
    credential_error: str = ""


def normalize_user_id(value: Any) -> str:
    text = str(value or "").replace("-", "").strip().lower()
    if len(text) != 32:
        return ""
    try:
        return str(uuid.UUID(text))
    except ValueError:
        return ""


def normalize_url(value: str) -> str:
    value = value.strip().rstrip("/")
    if not value:
        raise ValueError("Server URL cannot be blank.")
    if not value.startswith(("http://", "https://")):
        raise ValueError("Server URL must start with http:// or https://.")
    return value


def normalize_api_url(value: str) -> str:
    """Return an Emby REST API root ending in /emby."""
    value = normalize_url(value)
    parts = urlsplit(value)
    path = parts.path.rstrip("/")
    lower_path = path.lower()
    for suffix in ("/web/index.html", "/web/index.htm", "/web"):
        if lower_path.endswith(suffix):
            path = path[: -len(suffix)]
            lower_path = path.lower()
            break
    if not lower_path.endswith("/emby"):
        path = f"{path}/emby" if path else "/emby"
    return urlunsplit((parts.scheme, parts.netloc, path, parts.query, parts.fragment))


def row_to_server(row: Any) -> EmbyServer:
    credential_error = ""
    try:
        key = decrypt_secret(row["api_key_encrypted"])
    except ValueError as exc:
        key = ""
        credential_error = str(exc)
    return EmbyServer(
        id=row["id"],
        name=str(row["name"]),
        internal_url=str(row["internal_url"]).rstrip("/"),
        public_url=str(row["public_url"]).rstrip("/"),
        api_key=key,
        enabled=bool(row["enabled"]),
        is_default=bool(row["is_default"]),
        is_local=bool(row["is_local"]),
        verify_tls=bool(row["verify_tls"]),
        connect_timeout_seconds=int(row["connect_timeout_seconds"] or 20),
        notes=str(row["notes"] or ""),
        credential_error=credential_error,
    )


def safe_server(row: Any) -> dict[str, Any]:
    result = dict(row)
    result["id"] = str(result["id"])
    encrypted = result.pop("api_key_encrypted", "")
    result["api_key_configured"] = bool(encrypted)
    return result


async def ensure_default_server(pool: asyncpg.Pool) -> uuid.UUID:
    """Register the existing env-configured Emby instance as the default server."""
    encrypted = encrypt_secret(settings.emby_api_key)
    async with pool.acquire() as connection:
        async with connection.transaction():
            row = await connection.fetchrow(
                "SELECT * FROM emby_servers WHERE is_default=TRUE LIMIT 1 FOR UPDATE"
            )
            if row is None:
                row = await connection.fetchrow(
                    """
                    INSERT INTO emby_servers
                        (name, internal_url, public_url, api_key_encrypted, enabled,
                         is_default, is_local, verify_tls, notes)
                    VALUES ('Local Emby', $1, $2, $3, TRUE, TRUE, TRUE, TRUE,
                            'Automatically registered by the 3mbyPanel v0.1.0 installer.')
                    RETURNING *
                    """,
                    settings.emby_url.rstrip("/"),
                    settings.emby_public_url.rstrip("/"),
                    encrypted,
                )
            elif row["is_local"]:
                row = await connection.fetchrow(
                    """
                    UPDATE emby_servers
                    SET internal_url=$2,
                        public_url=$3,
                        api_key_encrypted=CASE WHEN $4 <> '' THEN $4 ELSE api_key_encrypted END,
                        enabled=TRUE,
                        updated_at=NOW()
                    WHERE id=$1
                    RETURNING *
                    """,
                    row["id"],
                    settings.emby_url.rstrip("/"),
                    settings.emby_public_url.rstrip("/"),
                    encrypted,
                )
            server_id = row["id"]
            await connection.execute(
                """
                INSERT INTO server_user_assignments
                    (emby_user_id, server_id, remote_user_id, remote_user_name,
                     sync_enabled, last_sync_status, last_sync_message, last_sync_at)
                SELECT m.emby_user_id, $1, m.emby_user_id, '', TRUE,
                       'synced', 'Default server assignment', NOW()
                FROM managed_emby_users m
                WHERE m.managed=TRUE
                ON CONFLICT (emby_user_id, server_id) DO UPDATE SET
                    remote_user_id=EXCLUDED.remote_user_id,
                    sync_enabled=TRUE,
                    updated_at=NOW()
                """,
                server_id,
            )
    return server_id


async def get_server(
    pool: asyncpg.Pool,
    server_id: uuid.UUID | str | None = None,
    *,
    enabled_only: bool = False,
) -> EmbyServer:
    async with pool.acquire() as connection:
        if server_id is None:
            row = await connection.fetchrow(
                "SELECT * FROM emby_servers WHERE is_default=TRUE LIMIT 1"
            )
        else:
            try:
                parsed = server_id if isinstance(server_id, uuid.UUID) else uuid.UUID(str(server_id))
            except ValueError as exc:
                raise HTTPException(status_code=400, detail="Invalid server ID.") from exc
            row = await connection.fetchrow(
                "SELECT * FROM emby_servers WHERE id=$1",
                parsed,
            )
    if row is None:
        raise HTTPException(status_code=404, detail="Emby server not found.")
    if enabled_only and not row["enabled"]:
        raise HTTPException(status_code=409, detail="That Emby server is disabled.")
    return row_to_server(row)


async def get_enabled_servers(pool: asyncpg.Pool) -> list[EmbyServer]:
    async with pool.acquire() as connection:
        rows = await connection.fetch(
            "SELECT * FROM emby_servers WHERE enabled=TRUE ORDER BY is_default DESC, LOWER(name)"
        )
    return [row_to_server(row) for row in rows]


async def server_request_json(
    client: httpx.AsyncClient,
    server: EmbyServer,
    method: str,
    path: str,
    *,
    require_key: bool = True,
    json_data: Any | None = None,
    params: dict[str, Any] | None = None,
    expected_statuses: tuple[int, ...] = (200, 204),
    allow_not_found: bool = False,
) -> Any:
    if not server.enabled:
        raise HTTPException(status_code=409, detail=f"{server.name} is disabled.")
    if require_key and server.credential_error:
        raise HTTPException(status_code=428, detail=f"{server.name}: {server.credential_error}")
    if require_key and not server.api_key:
        raise HTTPException(status_code=428, detail=f"{server.name} has no API key configured.")

    normalized_path = path.lstrip("/")
    method = method.upper()
    unwrap_users = method == "GET" and normalized_path == "Users"
    if unwrap_users:
        normalized_path = "Users/Query"
    if method == "DELETE" and normalized_path.startswith("Users/") and normalized_path.count("/") == 1:
        method = "POST"
        normalized_path = f"{normalized_path}/Delete"
    if method == "POST" and normalized_path.startswith("Users/") and normalized_path.endswith("/Password"):
        user_id = normalized_path.split("/")[1]
        body = dict(json_data or {})
        body.pop("CurrentPw", None)
        body.setdefault("Id", user_id)
        json_data = body

    accepted_statuses = set(expected_statuses)
    if 204 in accepted_statuses:
        accepted_statuses.add(200)

    headers = {"X-Emby-Token": server.api_key} if server.api_key else {}
    url = f"{server.internal_url.rstrip('/')}/{normalized_path}"
    timeout = httpx.Timeout(float(server.connect_timeout_seconds))
    try:
        if server.verify_tls:
            response = await client.request(
                method,
                url,
                headers=headers,
                json=json_data,
                params=params,
                timeout=timeout,
            )
        else:
            async with httpx.AsyncClient(verify=False, timeout=timeout) as insecure:
                response = await insecure.request(
                    method,
                    url,
                    headers=headers,
                    json=json_data,
                    params=params,
                )
    except httpx.RequestError as exc:
        raise HTTPException(status_code=502, detail=f"{server.name} is unreachable: {exc}") from exc

    if allow_not_found and response.status_code == 404:
        return None
    if response.status_code in (401, 403):
        raise HTTPException(status_code=502, detail=f"{server.name} rejected its configured API key.")
    if response.status_code not in accepted_statuses:
        detail = response.text.strip()
        if len(detail) > 500:
            detail = detail[:500] + "…"
        raise HTTPException(
            status_code=502,
            detail=f"{server.name} returned HTTP {response.status_code}: {detail or 'no response body'}",
        )
    if response.status_code == 204 or not response.content:
        return None
    try:
        payload = response.json()
    except ValueError as exc:
        raise HTTPException(status_code=502, detail=f"{server.name} returned invalid JSON.") from exc

    if unwrap_users:
        if isinstance(payload, dict):
            items = payload.get("Items")
            return items if isinstance(items, list) else []
        return payload if isinstance(payload, list) else []
    return payload


async def check_server_health(
    pool: asyncpg.Pool,
    client: httpx.AsyncClient,
    server: EmbyServer,
) -> dict[str, Any]:
    status = "online"
    message = "Connected"
    public_info: dict[str, Any] = {}
    try:
        public_info = await server_request_json(
            client,
            server,
            "GET",
            "System/Info/Public",
            require_key=False,
            expected_statuses=(200,),
        )
        if server.api_key:
            await server_request_json(
                client,
                server,
                "GET",
                "System/Info",
                require_key=True,
                expected_statuses=(200,),
            )
        else:
            status = "auth_error"
            message = "Server is reachable, but no API key is configured."
    except HTTPException as exc:
        text = str(exc.detail)
        status = "auth_error" if "API key" in text or "rejected" in text or "credential" in text.lower() else "offline"
        message = text[:1000]

    async with pool.acquire() as connection:
        await connection.execute(
            """
            UPDATE emby_servers
            SET last_status=$2,
                last_status_message=$3,
                last_server_name=$4,
                last_version=$5,
                last_checked_at=NOW(),
                updated_at=NOW()
            WHERE id=$1
            """,
            server.id,
            status,
            message,
            public_info.get("ServerName") or public_info.get("Name"),
            public_info.get("Version"),
        )
    return {
        "server_id": str(server.id),
        "name": server.name,
        "status": status,
        "message": message,
        "server": public_info,
    }


def merge_policy(remote_policy: dict[str, Any], canonical_policy: dict[str, Any]) -> dict[str, Any]:
    result = dict(remote_policy)
    for key in SYNC_POLICY_FIELDS:
        if key in canonical_policy:
            result[key] = canonical_policy[key]
    result["IsAdministrator"] = False
    result["EnableLiveTvManagement"] = False
    result["EnableContentDeletion"] = False
    return result


async def _record_assignment(
    pool: asyncpg.Pool,
    *,
    canonical_user_id: uuid.UUID,
    server_id: uuid.UUID,
    remote_user_id: uuid.UUID | None,
    remote_user_name: str,
    status: str,
    message: str,
    sync_enabled: bool = True,
) -> None:
    async with pool.acquire() as connection:
        await connection.execute(
            """
            INSERT INTO server_user_assignments
                (emby_user_id, server_id, remote_user_id, remote_user_name,
                 sync_enabled, last_sync_status, last_sync_message, last_sync_at)
            VALUES ($1,$2,$3,$4,$5,$6,$7,NOW())
            ON CONFLICT (emby_user_id, server_id) DO UPDATE SET
                remote_user_id=EXCLUDED.remote_user_id,
                remote_user_name=EXCLUDED.remote_user_name,
                sync_enabled=EXCLUDED.sync_enabled,
                last_sync_status=EXCLUDED.last_sync_status,
                last_sync_message=EXCLUDED.last_sync_message,
                last_sync_at=NOW(),
                updated_at=NOW()
            """,
            canonical_user_id,
            server_id,
            remote_user_id,
            remote_user_name,
            sync_enabled,
            status,
            message[:1000],
        )


async def sync_user_to_server(
    pool: asyncpg.Pool,
    client: httpx.AsyncClient,
    canonical_user_id: uuid.UUID,
    server_id: uuid.UUID,
    *,
    password: str | None = None,
    create_missing: bool = True,
) -> dict[str, Any]:
    default_server = await get_server(pool)
    target = await get_server(pool, server_id, enabled_only=True)
    canonical = await server_request_json(
        client,
        default_server,
        "GET",
        f"Users/{canonical_user_id}",
        expected_statuses=(200,),
    )
    canonical_policy = dict(canonical.get("Policy") or {})
    if canonical_policy.get("IsAdministrator", False):
        raise HTTPException(status_code=403, detail="Emby administrator accounts cannot be assigned.")
    canonical_name = str(canonical.get("Name") or "").strip()
    if not canonical_name:
        raise HTTPException(status_code=502, detail="The default server returned a user without a name.")

    if target.id == default_server.id:
        await _record_assignment(
            pool,
            canonical_user_id=canonical_user_id,
            server_id=target.id,
            remote_user_id=canonical_user_id,
            remote_user_name=canonical_name,
            status="synced",
            message="Default server assignment",
        )
        return {
            "server_id": str(target.id),
            "server_name": target.name,
            "remote_user_id": str(canonical_user_id),
            "remote_user_name": canonical_name,
            "created": False,
            "linked": True,
            "status": "synced",
        }

    async with pool.acquire() as connection:
        assignment = await connection.fetchrow(
            """
            SELECT remote_user_id, remote_user_name, sync_enabled
            FROM server_user_assignments
            WHERE emby_user_id=$1 AND server_id=$2
            """,
            canonical_user_id,
            target.id,
        )

    remote: dict[str, Any] | None = None
    if assignment and assignment["remote_user_id"]:
        remote = await server_request_json(
            client,
            target,
            "GET",
            f"Users/{assignment['remote_user_id']}",
            expected_statuses=(200,),
            allow_not_found=True,
        )

    if remote is None:
        remote_users = await server_request_json(
            client,
            target,
            "GET",
            "Users",
            expected_statuses=(200,),
        )
        matches = [
            item for item in (remote_users or [])
            if str(item.get("Name") or "").strip().casefold() == canonical_name.casefold()
        ]
        if len(matches) > 1:
            await _record_assignment(
                pool,
                canonical_user_id=canonical_user_id,
                server_id=target.id,
                remote_user_id=None,
                remote_user_name=canonical_name,
                status="failed",
                message="More than one remote user has the same username.",
            )
            raise HTTPException(
                status_code=409,
                detail=f"{target.name} has multiple users named {canonical_name!r}; link manually after resolving duplicates.",
            )
        remote = matches[0] if matches else None

    created = False
    if remote is None:
        if not create_missing:
            await _record_assignment(
                pool,
                canonical_user_id=canonical_user_id,
                server_id=target.id,
                remote_user_id=None,
                remote_user_name=canonical_name,
                status="failed",
                message="Matching remote user was not found.",
            )
            raise HTTPException(status_code=404, detail=f"No matching user exists on {target.name}.")
        remote = await server_request_json(
            client,
            target,
            "POST",
            "Users/New",
            json_data={"Name": canonical_name, "Password": password or ""},
            expected_statuses=(200,),
        )
        created = True

    remote_id_text = normalize_user_id(remote.get("Id"))
    if not remote_id_text:
        raise HTTPException(status_code=502, detail=f"{target.name} returned an invalid user ID.")
    remote_id = uuid.UUID(remote_id_text)
    remote_policy = dict(remote.get("Policy") or {})
    if remote_policy.get("IsAdministrator", False):
        raise HTTPException(status_code=403, detail="A matching administrator exists on the target server and is protected.")
    synced_policy = merge_policy(remote_policy, canonical_policy)
    await server_request_json(
        client,
        target,
        "POST",
        f"Users/{remote_id}/Policy",
        json_data=synced_policy,
        expected_statuses=(204,),
    )
    if password:
        await server_request_json(
            client,
            target,
            "POST",
            f"Users/{remote_id}/Password",
            json_data={"CurrentPw": "", "NewPw": password, "ResetPassword": False},
            expected_statuses=(204,),
        )

    message = "User created and synchronized." if created else "Existing user linked and synchronized."
    if created and not password:
        message += " The new remote account currently has a blank password."
    await _record_assignment(
        pool,
        canonical_user_id=canonical_user_id,
        server_id=target.id,
        remote_user_id=remote_id,
        remote_user_name=canonical_name,
        status="warning" if created and not password else "synced",
        message=message,
    )
    return {
        "server_id": str(target.id),
        "server_name": target.name,
        "remote_user_id": str(remote_id),
        "remote_user_name": canonical_name,
        "created": created,
        "linked": not created,
        "status": "warning" if created and not password else "synced",
        "message": message,
    }


async def propagate_policy(
    pool: asyncpg.Pool,
    client: httpx.AsyncClient,
    canonical_user_id: uuid.UUID,
    canonical_policy: dict[str, Any],
) -> dict[str, int]:
    async with pool.acquire() as connection:
        rows = await connection.fetch(
            """
            SELECT a.server_id, a.remote_user_id, s.*
            FROM server_user_assignments a
            JOIN emby_servers s ON s.id=a.server_id
            WHERE a.emby_user_id=$1
              AND a.sync_enabled=TRUE
              AND a.remote_user_id IS NOT NULL
              AND s.enabled=TRUE
              AND s.is_default=FALSE
            """,
            canonical_user_id,
        )
    result = {"synced": 0, "failed": 0}
    for row in rows:
        server = row_to_server(row)
        remote_id = row["remote_user_id"]
        try:
            remote = await server_request_json(
                client,
                server,
                "GET",
                f"Users/{remote_id}",
                expected_statuses=(200,),
            )
            remote_policy = dict(remote.get("Policy") or {})
            if remote_policy.get("IsAdministrator", False):
                raise HTTPException(status_code=403, detail="Remote administrator is protected.")
            await server_request_json(
                client,
                server,
                "POST",
                f"Users/{remote_id}/Policy",
                json_data=merge_policy(remote_policy, canonical_policy),
                expected_statuses=(204,),
            )
            await _record_assignment(
                pool,
                canonical_user_id=canonical_user_id,
                server_id=server.id,
                remote_user_id=remote_id,
                remote_user_name=str(remote.get("Name") or ""),
                status="synced",
                message="Policy synchronized.",
            )
            result["synced"] += 1
        except Exception as exc:
            await _record_assignment(
                pool,
                canonical_user_id=canonical_user_id,
                server_id=server.id,
                remote_user_id=remote_id,
                remote_user_name=str(row.get("remote_user_name") or "") if hasattr(row, "get") else "",
                status="failed",
                message=str(exc),
            )
            result["failed"] += 1
    return result


async def propagate_password(
    pool: asyncpg.Pool,
    client: httpx.AsyncClient,
    canonical_user_id: uuid.UUID,
    password: str,
) -> dict[str, int]:
    async with pool.acquire() as connection:
        rows = await connection.fetch(
            """
            SELECT a.server_id, a.remote_user_id, a.remote_user_name, s.*
            FROM server_user_assignments a
            JOIN emby_servers s ON s.id=a.server_id
            WHERE a.emby_user_id=$1
              AND a.sync_enabled=TRUE
              AND a.remote_user_id IS NOT NULL
              AND s.enabled=TRUE
              AND s.is_default=FALSE
            """,
            canonical_user_id,
        )
    result = {"synced": 0, "failed": 0}
    for row in rows:
        server = row_to_server(row)
        try:
            await server_request_json(
                client,
                server,
                "POST",
                f"Users/{row['remote_user_id']}/Password",
                json_data={"CurrentPw": "", "NewPw": password, "ResetPassword": False},
                expected_statuses=(204,),
            )
            await _record_assignment(
                pool,
                canonical_user_id=canonical_user_id,
                server_id=server.id,
                remote_user_id=row["remote_user_id"],
                remote_user_name=str(row["remote_user_name"] or ""),
                status="synced",
                message="Password synchronized.",
            )
            result["synced"] += 1
        except Exception as exc:
            await _record_assignment(
                pool,
                canonical_user_id=canonical_user_id,
                server_id=server.id,
                remote_user_id=row["remote_user_id"],
                remote_user_name=str(row["remote_user_name"] or ""),
                status="failed",
                message=str(exc),
            )
            result["failed"] += 1
    return result


async def delete_assigned_remote_users(
    pool: asyncpg.Pool,
    client: httpx.AsyncClient,
    canonical_user_id: uuid.UUID,
) -> dict[str, int]:
    async with pool.acquire() as connection:
        rows = await connection.fetch(
            """
            SELECT a.server_id, a.remote_user_id, a.remote_user_name, s.*
            FROM server_user_assignments a
            JOIN emby_servers s ON s.id=a.server_id
            WHERE a.emby_user_id=$1
              AND a.remote_user_id IS NOT NULL
              AND s.is_default=FALSE
            """,
            canonical_user_id,
        )
    result = {"deleted": 0, "failed": 0}
    for row in rows:
        server = row_to_server(row)
        if not server.enabled:
            result["failed"] += 1
            continue
        try:
            await server_request_json(
                client,
                server,
                "DELETE",
                f"Users/{row['remote_user_id']}",
                expected_statuses=(204,),
                allow_not_found=True,
            )
            result["deleted"] += 1
        except Exception:
            result["failed"] += 1
    return result


async def assignment_rows(pool: asyncpg.Pool, canonical_user_id: uuid.UUID) -> list[dict[str, Any]]:
    await ensure_default_server(pool)
    async with pool.acquire() as connection:
        rows = await connection.fetch(
            """
            SELECT s.id::text AS server_id, s.name AS server_name, s.public_url,
                   s.enabled, s.is_default, s.last_status, s.last_checked_at,
                   a.id::text AS assignment_id, a.remote_user_id::text,
                   a.remote_user_name, a.sync_enabled, a.last_sync_status,
                   a.last_sync_message, a.last_sync_at
            FROM emby_servers s
            LEFT JOIN server_user_assignments a
              ON a.server_id=s.id AND a.emby_user_id=$1
            ORDER BY s.is_default DESC, LOWER(s.name)
            """,
            canonical_user_id,
        )
    return [dict(row) for row in rows]


async def assignment_identity_map(pool: asyncpg.Pool) -> dict[tuple[str, str], str]:
    async with pool.acquire() as connection:
        rows = await connection.fetch(
            """
            SELECT a.server_id::text, a.remote_user_id::text, a.emby_user_id::text
            FROM server_user_assignments a
            WHERE a.remote_user_id IS NOT NULL AND a.sync_enabled=TRUE
            """
        )
    return {
        (str(row["server_id"]), normalize_user_id(row["remote_user_id"])):
            normalize_user_id(row["emby_user_id"])
        for row in rows
        if normalize_user_id(row["remote_user_id"]) and normalize_user_id(row["emby_user_id"])
    }


async def all_server_sessions(
    pool: asyncpg.Pool,
    client: httpx.AsyncClient,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    servers = await get_enabled_servers(pool)

    async def collect(server: EmbyServer) -> tuple[list[dict[str, Any]], dict[str, Any] | None]:
        try:
            raw, users = await asyncio.gather(
                server_request_json(
                    client,
                    server,
                    "GET",
                    "Sessions",
                    expected_statuses=(200,),
                ),
                server_request_json(
                    client,
                    server,
                    "GET",
                    "Users",
                    expected_statuses=(200,),
                ),
            )
            user_map = {
                normalize_user_id(item.get("Id")): item
                for item in (users or [])
                if normalize_user_id(item.get("Id"))
            }
            collected: list[dict[str, Any]] = []
            for item in raw or []:
                item = dict(item)
                remote_id = normalize_user_id(item.get("UserId"))
                item["_server_id"] = str(server.id)
                item["_server_name"] = server.name
                item["_server_public_url"] = server.public_url
                item["_remote_user_id"] = remote_id
                item["_server_user"] = user_map.get(remote_id, {})
                collected.append(item)
            async with pool.acquire() as connection:
                await connection.execute(
                    """
                    UPDATE emby_servers
                    SET last_status='online', last_status_message='Sessions synchronized',
                        last_checked_at=NOW(), updated_at=NOW()
                    WHERE id=$1
                    """,
                    server.id,
                )
            return collected, None
        except Exception as exc:
            error = str(exc)[:500]
            status = "auth_error" if "API key" in error or "rejected" in error or "credential" in error.lower() else "offline"
            async with pool.acquire() as connection:
                await connection.execute(
                    """
                    UPDATE emby_servers
                    SET last_status=$2, last_status_message=$3,
                        last_checked_at=NOW(), updated_at=NOW()
                    WHERE id=$1
                    """,
                    server.id,
                    status,
                    error,
                )
            return [], {"server_id": str(server.id), "server_name": server.name, "error": error}

    responses = await asyncio.gather(*(collect(server) for server in servers))
    sessions: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []
    for collected, failure in responses:
        sessions.extend(collected)
        if failure is not None:
            failures.append(failure)
    return sessions, failures


def split_session_key(value: str) -> tuple[uuid.UUID, str]:
    if "~" not in value:
        raise HTTPException(status_code=400, detail="Invalid multi-server session key.")
    server_text, session_id = value.split("~", 1)
    try:
        server_id = uuid.UUID(server_text)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="Invalid server in session key.") from exc
    if not session_id:
        raise HTTPException(status_code=400, detail="Invalid Emby session ID.")
    return server_id, session_id
