from __future__ import annotations

from typing import Any

import httpx
from fastapi import HTTPException

from .settings import settings


def emby_headers() -> dict[str, str]:
    if not settings.emby_api_key:
        return {}
    return {"X-Emby-Token": settings.emby_api_key}


def normalize_emby_path(method: str, path: str) -> tuple[str, bool]:
    """Translate compatibility calls into Emby REST API requests."""
    normalized = path.lstrip("/")
    unwrap_users = method.upper() == "GET" and normalized == "Users"
    if unwrap_users:
        normalized = "Users/Query"
    return normalized, unwrap_users


async def request_json(
    client: httpx.AsyncClient,
    method: str,
    path: str,
    *,
    require_key: bool = False,
    json_data: Any | None = None,
    params: dict[str, Any] | None = None,
    expected_statuses: tuple[int, ...] = (200, 204),
) -> Any:
    if require_key and not settings.emby_api_key:
        raise HTTPException(status_code=428, detail="EMBY_API_KEY is not configured yet.")

    normalized_path, unwrap_users = normalize_emby_path(method, path)
    method = method.upper()
    if method == "DELETE" and normalized_path.startswith("Users/") and normalized_path.count("/") == 1:
        method = "POST"
        normalized_path = f"{normalized_path}/Delete"
    if method == "POST" and normalized_path.startswith("Users/") and normalized_path.endswith("/Password"):
        user_id = normalized_path.split("/")[1]
        body = dict(json_data or {})
        body.pop("CurrentPw", None)
        body.setdefault("Id", user_id)
        json_data = body
    accepted_statuses = set(expected_statuses)
    # Emby frequently returns HTTP 200 with an empty body for successful writes
    # for successful writes that may return 204 on other compatible servers.
    if 204 in accepted_statuses:
        accepted_statuses.add(200)

    url = f"{settings.emby_url.rstrip('/')}/{normalized_path}"
    try:
        response = await client.request(
            method,
            url,
            headers=emby_headers(),
            json=json_data,
            params=params,
        )
    except httpx.RequestError as exc:
        raise HTTPException(status_code=502, detail=f"Emby is unreachable: {exc}") from exc

    if response.status_code in (401, 403):
        raise HTTPException(status_code=502, detail="Emby rejected the configured API key.")
    if response.status_code not in accepted_statuses:
        detail = response.text.strip()
        if len(detail) > 500:
            detail = detail[:500] + "…"
        raise HTTPException(
            status_code=502,
            detail=f"Emby returned HTTP {response.status_code}: {detail or 'no response body'}",
        )
    if response.status_code == 204 or not response.content:
        return None
    try:
        payload = response.json()
    except ValueError as exc:
        raise HTTPException(status_code=502, detail="Emby returned invalid JSON.") from exc

    if unwrap_users:
        if isinstance(payload, dict):
            items = payload.get("Items")
            return items if isinstance(items, list) else []
        return payload if isinstance(payload, list) else []
    return payload
