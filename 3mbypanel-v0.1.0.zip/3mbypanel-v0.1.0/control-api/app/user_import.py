from __future__ import annotations

import json
import secrets
import string
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Literal

import asyncpg
import httpx
from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field, field_validator

from .access import require_admin_role
from .multiserver import (
    EmbyServer,
    get_server,
    normalize_user_id,
    server_request_json,
)
from .security import PanelSession, ensure_writes_enabled, require_session, validate_csrf

router = APIRouter(prefix="/servers", tags=["Emby Existing User Import"])


class ExistingUserImportRequest(BaseModel):
    user_ids: list[uuid.UUID] = Field(min_length=1, max_length=500)
    package_id: uuid.UUID | None = None
    reseller_id: uuid.UUID | None = None
    expires_at: datetime | None = None
    use_package_duration: bool = True
    policy_mode: Literal["preserve", "package"] = "preserve"
    preserve_disabled_status: bool = True
    create_primary_users: bool = True
    temporary_password: str | None = Field(default=None, max_length=256)
    notes: str = Field(default="Imported from an existing Emby server.", max_length=2000)

    @field_validator("expires_at")
    @classmethod
    def normalize_expiration(cls, value: datetime | None) -> datetime | None:
        if value is None:
            return None
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc)

    @field_validator("temporary_password")
    @classmethod
    def normalize_password(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = value.strip()
        return value or None


async def read_admin(session: PanelSession = Depends(require_session)) -> PanelSession:
    require_admin_role(session)
    return session


async def write_admin(
    request: Request,
    session: PanelSession = Depends(require_session),
) -> PanelSession:
    require_admin_role(session)
    ensure_writes_enabled()
    validate_csrf(session, request.headers.get("X-CSRF-Token"))
    return session


def _name_key(value: Any) -> str:
    return str(value or "").strip().casefold()


def _safe_policy(policy: dict[str, Any]) -> dict[str, Any]:
    """Preserve normal access while removing server-administration permissions."""
    result = dict(policy)
    result["IsAdministrator"] = False
    result["EnableLiveTvManagement"] = False
    result["EnableContentDeletion"] = False
    result["EnablePublicSharing"] = False
    return result


def _package_policy(base: dict[str, Any], package: Any) -> dict[str, Any]:
    result = dict(base)
    result.update(
        {
            "IsAdministrator": False,
            "IsHidden": bool(package["hidden"]),
            "EnableMediaPlayback": True,
            "EnableLiveTvAccess": bool(package["live_tv"]),
            "EnableLiveTvManagement": False,
            "EnableContentDownloading": bool(package["downloads"]),
            "EnableRemoteAccess": bool(package["remote_access"]),
            "EnableVideoPlaybackTranscoding": bool(package["video_transcoding"]),
            "EnableAudioPlaybackTranscoding": bool(package["audio_transcoding"]),
            "EnablePlaybackRemuxing": bool(package["remuxing"]),
            "SimultaneousStreamLimit": int(package["max_sessions"] or 0),
            "EnableContentDeletion": False,
            "EnableCollectionManagement": False,
            "EnableSubtitleManagement": False,
            "EnablePublicSharing": False,
        }
    )
    return result


def _temporary_password() -> str:
    alphabet = string.ascii_letters + string.digits + "!@#$%_-"
    while True:
        value = "".join(secrets.choice(alphabet) for _ in range(22))
        if (
            any(char.islower() for char in value)
            and any(char.isupper() for char in value)
            and any(char.isdigit() for char in value)
        ):
            return value


def _public_preview_item(item: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in item.items() if not key.startswith("_")}


async def _fetch_preview(
    pool: asyncpg.Pool,
    client: httpx.AsyncClient,
    source: EmbyServer,
) -> dict[str, Any]:
    default = await get_server(pool)
    source_users = await server_request_json(
        client,
        source,
        "GET",
        "Users",
        expected_statuses=(200,),
    )
    default_users = source_users if source.id == default.id else await server_request_json(
        client,
        default,
        "GET",
        "Users",
        expected_statuses=(200,),
    )

    async with pool.acquire() as connection:
        managed_rows = await connection.fetch(
            """
            SELECT emby_user_id::text, package_id::text, reseller_id::text,
                   expires_at, notes
            FROM managed_emby_users
            WHERE managed=TRUE
            """
        )
        assignment_rows = await connection.fetch(
            """
            SELECT emby_user_id::text, remote_user_id::text
            FROM server_user_assignments
            WHERE server_id=$1 AND remote_user_id IS NOT NULL
            """,
            source.id,
        )

    managed = {
        normalize_user_id(row["emby_user_id"]): dict(row)
        for row in managed_rows
        if normalize_user_id(row["emby_user_id"])
    }
    assigned = {
        normalize_user_id(row["remote_user_id"]): normalize_user_id(row["emby_user_id"])
        for row in assignment_rows
        if normalize_user_id(row["remote_user_id"])
    }
    assigned_by_canonical = {
        normalize_user_id(row["emby_user_id"]): normalize_user_id(row["remote_user_id"])
        for row in assignment_rows
        if normalize_user_id(row["emby_user_id"]) and normalize_user_id(row["remote_user_id"])
    }

    local_by_name: dict[str, list[dict[str, Any]]] = {}
    for user in default_users or []:
        local_by_name.setdefault(_name_key(user.get("Name")), []).append(user)

    items: list[dict[str, Any]] = []
    counts = {
        "new": 0,
        "username_match": 0,
        "username_match_unmanaged": 0,
        "already_managed": 0,
        "administrator": 0,
        "conflict": 0,
        "invalid": 0,
        "importable": 0,
    }

    for user in sorted(source_users or [], key=lambda current: _name_key(current.get("Name"))):
        remote_id = normalize_user_id(user.get("Id"))
        name = str(user.get("Name") or "").strip()
        policy = dict(user.get("Policy") or {})
        is_admin = bool(policy.get("IsAdministrator", False))
        classification = "new"
        canonical_id = ""
        canonical_name = ""
        canonical_managed = False
        message = "Ready to import."

        if not remote_id or not name:
            classification = "invalid"
            message = "Emby returned an invalid user ID or blank username."
        elif is_admin:
            classification = "administrator"
            message = "Administrator accounts are protected and cannot be imported."
        elif source.id == default.id:
            canonical_id = remote_id
            canonical_name = name
            canonical_managed = remote_id in managed
            if canonical_managed:
                classification = "already_managed"
                message = "This local user is already managed by 3mbyPanel."
            else:
                classification = "new"
                message = "Existing local account will be adopted without changing its password."
        elif remote_id in assigned:
            canonical_id = assigned[remote_id]
            canonical_managed = canonical_id in managed
            match = next(
                (
                    current
                    for current in default_users or []
                    if normalize_user_id(current.get("Id")) == canonical_id
                ),
                None,
            )
            canonical_name = str((match or {}).get("Name") or "")
            classification = "already_managed"
            message = "This remote account is already linked to a 3mbyPanel user."
        else:
            matches = local_by_name.get(_name_key(name), [])
            if len(matches) > 1:
                classification = "conflict"
                message = "More than one primary-server user has this username."
            elif len(matches) == 1:
                match = matches[0]
                local_policy = dict(match.get("Policy") or {})
                canonical_id = normalize_user_id(match.get("Id"))
                canonical_name = str(match.get("Name") or "")
                canonical_managed = canonical_id in managed
                existing_remote = assigned_by_canonical.get(canonical_id)
                if local_policy.get("IsAdministrator", False):
                    classification = "conflict"
                    message = "The matching primary-server account is an administrator and is protected."
                elif existing_remote and existing_remote != remote_id:
                    classification = "conflict"
                    message = "The matching primary account is already assigned to a different user on this server."
                elif canonical_managed:
                    classification = "username_match"
                    message = "Will link to the existing managed primary account with the same username."
                else:
                    classification = "username_match_unmanaged"
                    message = "Will adopt the matching primary account and link this remote account."
            else:
                classification = "new"
                message = "A primary-server account must be created before this remote account can be managed."

        importable = classification in {"new", "username_match", "username_match_unmanaged"}
        counts[classification] = counts.get(classification, 0) + 1
        if importable:
            counts["importable"] += 1

        items.append(
            {
                "remote_user_id": remote_id,
                "remote_user_name": name,
                "classification": classification,
                "importable": importable,
                "message": message,
                "canonical_user_id": canonical_id or None,
                "canonical_user_name": canonical_name or None,
                "canonical_managed": canonical_managed,
                "is_administrator": is_admin,
                "is_disabled": bool(policy.get("IsDisabled", False)),
                "is_hidden": bool(policy.get("IsHidden", False)),
                "has_password": bool(user.get("HasPassword", False)),
                "live_tv": bool(policy.get("EnableLiveTvAccess", False)),
                "downloads": bool(policy.get("EnableContentDownloading", False)),
                "remote_access": bool(policy.get("EnableRemoteAccess", False)),
                "max_sessions": int(policy.get("SimultaneousStreamLimit") or 0),
                "last_login_date": user.get("LastLoginDate"),
                "last_activity_date": user.get("LastActivityDate"),
                "_source_user": user,
                "_source_policy": policy,
            }
        )

    return {
        "server": {
            "id": str(source.id),
            "name": source.name,
            "is_default": source.is_default,
            "is_local": source.is_local,
        },
        "default_server": {"id": str(default.id), "name": default.name},
        "count": len(items),
        "counts": counts,
        "items": items,
    }


async def _load_import_options(
    connection: asyncpg.Connection,
    payload: ExistingUserImportRequest,
) -> tuple[Any | None, Any | None]:
    package = None
    reseller = None
    if payload.package_id is not None:
        package = await connection.fetchrow(
            "SELECT * FROM account_packages WHERE id=$1 AND enabled=TRUE",
            payload.package_id,
        )
        if package is None:
            raise HTTPException(status_code=404, detail="The selected package was not found or is disabled.")
    if payload.policy_mode == "package" and package is None:
        raise HTTPException(status_code=422, detail="Select an enabled package when policy mode is set to package.")
    if payload.reseller_id is not None:
        reseller = await connection.fetchrow(
            "SELECT id, username, enabled FROM panel_accounts WHERE id=$1",
            payload.reseller_id,
        )
        if reseller is None:
            raise HTTPException(status_code=404, detail="The selected reseller was not found.")
        if not reseller["enabled"]:
            raise HTTPException(status_code=409, detail="The selected reseller is disabled.")
    return package, reseller


async def _set_policy(
    client: httpx.AsyncClient,
    server: EmbyServer,
    user_id: uuid.UUID,
    policy: dict[str, Any],
) -> None:
    await server_request_json(
        client,
        server,
        "POST",
        f"Users/{user_id}/Policy",
        json_data=policy,
        expected_statuses=(204,),
    )


async def _restore_policy_best_effort(
    client: httpx.AsyncClient,
    server: EmbyServer,
    user_id: uuid.UUID,
    policy: dict[str, Any],
) -> None:
    try:
        await _set_policy(client, server, user_id, policy)
    except Exception:
        pass


@router.get("/{server_id}/import/users/preview")
async def preview_existing_users(
    server_id: uuid.UUID,
    request: Request,
    _: PanelSession = Depends(read_admin),
) -> dict[str, Any]:
    source = await get_server(request.app.state.db, server_id, enabled_only=True)
    preview = await _fetch_preview(request.app.state.db, request.app.state.http, source)
    preview["items"] = [_public_preview_item(item) for item in preview["items"]]
    return preview


@router.get("/imports/history")
async def existing_user_import_history(
    request: Request,
    limit: int = Query(default=25, ge=1, le=200),
    _: PanelSession = Depends(read_admin),
) -> dict[str, Any]:
    async with request.app.state.db.acquire() as connection:
        rows = await connection.fetch(
            """
            SELECT id::text, server_id::text, server_name, status, requested_count,
                   imported_count, linked_count, created_primary_count, skipped_count,
                   failed_count, options, error, created_by, created_at, finished_at
            FROM emby_user_import_runs
            ORDER BY created_at DESC
            LIMIT $1
            """,
            limit,
        )
    return {"count": len(rows), "runs": [dict(row) for row in rows]}


@router.post("/{server_id}/import/users")
async def import_existing_users(
    server_id: uuid.UUID,
    payload: ExistingUserImportRequest,
    request: Request,
    session: PanelSession = Depends(write_admin),
) -> dict[str, Any]:
    source = await get_server(request.app.state.db, server_id, enabled_only=True)
    default = await get_server(request.app.state.db)
    preview = await _fetch_preview(request.app.state.db, request.app.state.http, source)
    preview_items = {
        item["remote_user_id"]: item
        for item in preview["items"]
        if item["remote_user_id"]
    }

    async with request.app.state.db.acquire() as connection:
        package, reseller = await _load_import_options(connection, payload)
        run_id = await connection.fetchval(
            """
            INSERT INTO emby_user_import_runs
                (server_id, server_name, status, requested_count, options, created_by)
            VALUES ($1,$2,'running',$3,$4::jsonb,$5)
            RETURNING id
            """,
            source.id,
            source.name,
            len(payload.user_ids),
            json.dumps(
                {
                    "package_id": str(payload.package_id) if payload.package_id else None,
                    "reseller_id": str(payload.reseller_id) if payload.reseller_id else None,
                    "expires_at": payload.expires_at.isoformat() if payload.expires_at else None,
                    "use_package_duration": payload.use_package_duration,
                    "policy_mode": payload.policy_mode,
                    "preserve_disabled_status": payload.preserve_disabled_status,
                    "create_primary_users": payload.create_primary_users,
                    "temporary_password_supplied": bool(payload.temporary_password),
                }
            ),
            session.username,
        )

    now = datetime.now(timezone.utc)
    results: list[dict[str, Any]] = []
    imported = linked = created_primary = skipped = failed = 0

    for selected_id in payload.user_ids:
        remote_key = normalize_user_id(selected_id)
        item = preview_items.get(remote_key)
        if item is None:
            failed += 1
            results.append(
                {
                    "remote_user_id": str(selected_id),
                    "remote_user_name": "",
                    "status": "failed",
                    "message": "The selected user no longer exists on the source server.",
                }
            )
            continue
        if not item["importable"]:
            skipped += 1
            results.append(
                {
                    "remote_user_id": remote_key,
                    "remote_user_name": item["remote_user_name"],
                    "status": "skipped",
                    "message": item["message"],
                }
            )
            continue

        source_user = item["_source_user"]
        source_policy = dict(item["_source_policy"])
        source_uuid = uuid.UUID(remote_key)
        canonical_uuid: uuid.UUID | None = (
            uuid.UUID(item["canonical_user_id"])
            if item.get("canonical_user_id")
            else None
        )
        primary_created = False
        generated_password: str | None = None
        old_primary_policy: dict[str, Any] | None = None
        old_source_policy = dict(source_policy)

        try:
            if source.id == default.id:
                canonical_uuid = source_uuid
                primary_user = source_user
            elif canonical_uuid is not None:
                primary_user = await server_request_json(
                    request.app.state.http,
                    default,
                    "GET",
                    f"Users/{canonical_uuid}",
                    expected_statuses=(200,),
                )
            else:
                if not payload.create_primary_users:
                    raise HTTPException(
                        status_code=409,
                        detail="No matching primary account exists and primary-user creation is disabled.",
                    )
                password = payload.temporary_password or _temporary_password()
                if payload.temporary_password is None:
                    generated_password = password
                primary_user = await server_request_json(
                    request.app.state.http,
                    default,
                    "POST",
                    "Users/New",
                    json_data={"Name": item["remote_user_name"], "Password": password},
                    expected_statuses=(200,),
                )
                canonical_text = normalize_user_id(primary_user.get("Id"))
                if not canonical_text:
                    raise HTTPException(status_code=502, detail="The primary server returned an invalid new-user ID.")
                canonical_uuid = uuid.UUID(canonical_text)
                primary_created = True

            if canonical_uuid is None:
                raise HTTPException(status_code=500, detail="3mbyPanel could not resolve the primary user ID.")

            primary_policy = dict(primary_user.get("Policy") or {})
            if primary_policy.get("IsAdministrator", False):
                raise HTTPException(status_code=403, detail="The matching primary account is an administrator and is protected.")
            old_primary_policy = dict(primary_policy)

            if payload.policy_mode == "package":
                final_policy = _package_policy(source_policy, package)
            elif source.id == default.id:
                final_policy = dict(source_policy)
            else:
                final_policy = _safe_policy(source_policy)

            if payload.preserve_disabled_status:
                final_policy["IsDisabled"] = bool(source_policy.get("IsDisabled", False))
            else:
                final_policy["IsDisabled"] = False

            explicit_expiration = payload.expires_at
            package_expiration = None
            if (
                explicit_expiration is None
                and package is not None
                and payload.use_package_duration
                and int(package["duration_days"] or 0) > 0
            ):
                package_expiration = now + timedelta(days=int(package["duration_days"]))

            async with request.app.state.db.acquire() as connection:
                existing = await connection.fetchrow(
                    """
                    SELECT package_id, reseller_id, expires_at, notes
                    FROM managed_emby_users
                    WHERE emby_user_id=$1
                    """,
                    canonical_uuid,
                )

            expires_at = explicit_expiration or package_expiration
            if expires_at is None and existing is not None:
                expires_at = existing["expires_at"]
            disabled_by_expiration = bool(expires_at is not None and expires_at <= now)
            if disabled_by_expiration:
                final_policy["IsDisabled"] = True

            await _set_policy(request.app.state.http, default, canonical_uuid, final_policy)
            if source.id != default.id:
                await _set_policy(request.app.state.http, source, source_uuid, final_policy)

            package_id = payload.package_id or (existing["package_id"] if existing else None)
            reseller_id = payload.reseller_id or (existing["reseller_id"] if existing else None)
            notes = payload.notes.strip() or (str(existing["notes"] or "") if existing else "")
            max_sessions = int(final_policy.get("SimultaneousStreamLimit") or 0)

            async with request.app.state.db.acquire() as connection:
                async with connection.transaction():
                    await connection.execute(
                        """
                        INSERT INTO managed_emby_users
                            (emby_user_id, reseller_id, package_id, expires_at,
                             max_sessions, managed, notes, created_by,
                             disabled_by_expiration, last_policy_sync_at)
                        VALUES ($1,$2,$3,$4,$5,TRUE,$6,$7,$8,NOW())
                        ON CONFLICT (emby_user_id) DO UPDATE SET
                            reseller_id=EXCLUDED.reseller_id,
                            package_id=EXCLUDED.package_id,
                            expires_at=EXCLUDED.expires_at,
                            max_sessions=EXCLUDED.max_sessions,
                            managed=TRUE,
                            notes=EXCLUDED.notes,
                            disabled_by_expiration=EXCLUDED.disabled_by_expiration,
                            last_policy_sync_at=NOW(),
                            updated_at=NOW()
                        """,
                        canonical_uuid,
                        reseller_id,
                        package_id,
                        expires_at,
                        max_sessions,
                        notes,
                        session.username,
                        disabled_by_expiration,
                    )
                    await connection.execute(
                        """
                        INSERT INTO server_user_assignments
                            (emby_user_id, server_id, remote_user_id,
                             remote_user_name, sync_enabled, last_sync_status,
                             last_sync_message, last_sync_at)
                        VALUES ($1,$2,$1,$3,TRUE,'synced','Primary server assignment',NOW())
                        ON CONFLICT (emby_user_id, server_id) DO UPDATE SET
                            remote_user_id=EXCLUDED.remote_user_id,
                            remote_user_name=EXCLUDED.remote_user_name,
                            sync_enabled=TRUE,
                            last_sync_status='synced',
                            last_sync_message='Primary server assignment',
                            last_sync_at=NOW(), updated_at=NOW()
                        """,
                        canonical_uuid,
                        default.id,
                        str(primary_user.get("Name") or item["remote_user_name"]),
                    )
                    if source.id != default.id:
                        await connection.execute(
                            """
                            INSERT INTO server_user_assignments
                                (emby_user_id, server_id, remote_user_id,
                                 remote_user_name, sync_enabled, last_sync_status,
                                 last_sync_message, last_sync_at)
                            VALUES ($1,$2,$3,$4,TRUE,'synced',
                                    'Existing user imported and linked.',NOW())
                            ON CONFLICT (emby_user_id, server_id) DO UPDATE SET
                                remote_user_id=EXCLUDED.remote_user_id,
                                remote_user_name=EXCLUDED.remote_user_name,
                                sync_enabled=TRUE,
                                last_sync_status='synced',
                                last_sync_message='Existing user imported and linked.',
                                last_sync_at=NOW(), updated_at=NOW()
                            """,
                            canonical_uuid,
                            source.id,
                            source_uuid,
                            item["remote_user_name"],
                        )

            imported += 1
            if primary_created:
                created_primary += 1
            else:
                linked += 1
            result = {
                "remote_user_id": remote_key,
                "remote_user_name": item["remote_user_name"],
                "canonical_user_id": str(canonical_uuid),
                "status": "imported",
                "created_primary_user": primary_created,
                "message": (
                    "Primary account created and remote account linked."
                    if primary_created
                    else "Existing account adopted and linked."
                ),
            }
            if generated_password:
                result["one_time_password"] = generated_password
                result["message"] += " Copy the generated primary-server password now; it is not stored by 3mbyPanel."
            results.append(result)
        except Exception as exc:
            failed += 1
            if canonical_uuid is not None and old_primary_policy is not None:
                await _restore_policy_best_effort(
                    request.app.state.http,
                    default,
                    canonical_uuid,
                    old_primary_policy,
                )
            if source.id != default.id:
                await _restore_policy_best_effort(
                    request.app.state.http,
                    source,
                    source_uuid,
                    old_source_policy,
                )
            if primary_created and canonical_uuid is not None:
                try:
                    await server_request_json(
                        request.app.state.http,
                        default,
                        "DELETE",
                        f"Users/{canonical_uuid}",
                        expected_statuses=(204,),
                        allow_not_found=True,
                    )
                except Exception:
                    pass
            message = str(exc.detail) if isinstance(exc, HTTPException) else str(exc)
            results.append(
                {
                    "remote_user_id": remote_key,
                    "remote_user_name": item["remote_user_name"],
                    "status": "failed",
                    "message": message[:1000],
                }
            )

    run_status = "completed" if failed == 0 else "completed_with_errors"
    stored_results = [
        {key: value for key, value in result.items() if key != "one_time_password"}
        for result in results
    ]
    async with request.app.state.db.acquire() as connection:
        await connection.execute(
            """
            UPDATE emby_user_import_runs
            SET status=$2,
                imported_count=$3,
                linked_count=$4,
                created_primary_count=$5,
                skipped_count=$6,
                failed_count=$7,
                results=$8::jsonb,
                finished_at=NOW()
            WHERE id=$1
            """,
            run_id,
            run_status,
            imported,
            linked,
            created_primary,
            skipped,
            failed,
            json.dumps(stored_results),
        )
        await connection.execute(
            """
            INSERT INTO audit_log
                (actor_type, actor_id, action, target_type, target_id, details)
            VALUES ('panel',$1,'emby.user_import','emby_server',$2,$3::jsonb)
            """,
            session.username,
            str(source.id),
            json.dumps(
                {
                    "run_id": str(run_id),
                    "server_name": source.name,
                    "requested": len(payload.user_ids),
                    "imported": imported,
                    "linked": linked,
                    "created_primary": created_primary,
                    "skipped": skipped,
                    "failed": failed,
                }
            ),
        )

    return {
        "run_id": str(run_id),
        "server_id": str(source.id),
        "server_name": source.name,
        "status": run_status,
        "requested": len(payload.user_ids),
        "imported": imported,
        "linked": linked,
        "created_primary": created_primary,
        "skipped": skipped,
        "failed": failed,
        "results": results,
    }
