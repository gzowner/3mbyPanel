from __future__ import annotations

import hashlib
import json
import re
import uuid
from collections import Counter
from html import unescape
from typing import Any
from urllib.parse import urlparse

import asyncpg
import httpx
from fastapi import APIRouter, Depends, Header, HTTPException, Request
from pydantic import BaseModel, Field, field_validator

from .access import require_admin_role
from .emby import request_json
from .security import (
    PanelSession,
    ensure_writes_enabled,
    require_session,
    validate_csrf,
)

router = APIRouter(prefix="/m3u", tags=["M3U"])
ATTR_RE = re.compile(r'([A-Za-z0-9_-]+)="([^"]*)"')
EPG_HEADER_RE = re.compile(
    r"(?:^|\s)(?:x-tvg-url|url-tvg|tvg-url|xmltv-url)\s*=\s*(?:\"([^\"]*)\"|'([^']*)'|([^\s]+))",
    re.IGNORECASE,
)
MAX_EPG_FEEDS_PER_SOURCE = 12


class SourceRequest(BaseModel):
    name: str = Field(min_length=1, max_length=150)
    source_url: str = Field(min_length=4, max_length=4096)
    user_agent: str = Field(default="", max_length=512)
    enabled: bool = True
    refresh_minutes: int = Field(default=60, ge=5, le=10080)
    max_connections: int = Field(default=0, ge=0, le=10000)
    epg_urls: list[str] = Field(default_factory=list, max_length=MAX_EPG_FEEDS_PER_SOURCE)
    epg_user_agent: str = Field(default="", max_length=512)
    epg_enabled: bool = True

    @field_validator("name")
    @classmethod
    def clean_name(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Source name cannot be blank")
        return value

    @field_validator("source_url")
    @classmethod
    def validate_source_url(cls, value: str) -> str:
        return validate_http_url(value, "M3U source")

    @field_validator("epg_urls")
    @classmethod
    def validate_epg_urls(cls, values: list[str]) -> list[str]:
        return normalize_url_list(values, label="XMLTV guide")


class CategorySelectionRequest(BaseModel):
    source_id: uuid.UUID
    enabled_ids: list[uuid.UUID] = Field(default_factory=list)


async def write_session(
    session: PanelSession = Depends(require_session),
    csrf_token: str | None = Header(default=None, alias="X-CSRF-Token"),
) -> PanelSession:
    require_admin_role(session)
    ensure_writes_enabled()
    validate_csrf(session, csrf_token)
    return session


async def read_session(session: PanelSession = Depends(require_session)) -> PanelSession:
    require_admin_role(session)
    return session


def get_pool(request: Request) -> asyncpg.Pool:
    pool = request.app.state.db
    if pool is None:
        raise HTTPException(status_code=503, detail="Database is unavailable.")
    return pool


async def audit(
    request: Request,
    action: str,
    *,
    actor: str,
    target_id: str | None = None,
    details: dict[str, Any] | None = None,
) -> None:
    pool = get_pool(request)
    async with pool.acquire() as connection:
        await connection.execute(
            """
            INSERT INTO audit_log (actor_type, actor_id, action, target_type, target_id, details)
            VALUES ('panel', $1, $2, 'm3u', $3, $4::jsonb)
            """,
            actor,
            action,
            target_id,
            json.dumps(details or {}),
        )


def validate_http_url(value: str, label: str) -> str:
    value = unescape(value).strip()
    parsed = urlparse(value)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError(f"{label} must be an http:// or https:// URL")
    return value


def normalize_url_list(values: list[str] | tuple[str, ...], *, label: str) -> list[str]:
    cleaned: list[str] = []
    seen: set[str] = set()
    for raw in values:
        value = unescape(str(raw)).strip()
        if not value:
            continue
        value = validate_http_url(value, label)
        if value in seen:
            continue
        seen.add(value)
        cleaned.append(value)
        if len(cleaned) > MAX_EPG_FEEDS_PER_SOURCE:
            raise ValueError(f"A maximum of {MAX_EPG_FEEDS_PER_SOURCE} XMLTV feeds is allowed per source")
    return cleaned


def json_object(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
        except json.JSONDecodeError:
            return {}
        return parsed if isinstance(parsed, dict) else {}
    return {}


def json_url_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except json.JSONDecodeError:
            value = [value]
    if not isinstance(value, (list, tuple)):
        return []
    try:
        return normalize_url_list([str(item) for item in value], label="XMLTV guide")
    except ValueError:
        return []


def effective_epg_urls(manual: Any, detected: Any) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for value in [*json_url_list(manual), *json_url_list(detected)]:
        if value in seen:
            continue
        seen.add(value)
        result.append(value)
    return result[:MAX_EPG_FEEDS_PER_SOURCE]


def detect_epg_urls(header_line: str) -> list[str]:
    candidates: list[str] = []
    for match in EPG_HEADER_RE.finditer(header_line):
        raw = next((group for group in match.groups() if group is not None), "")
        raw = unescape(raw).strip()
        if not raw:
            continue
        # Common M3U generators separate multiple guide URLs with commas or semicolons.
        parts = re.split(r"\s*[;,]\s*(?=https?://)", raw, flags=re.IGNORECASE)
        candidates.extend(parts)
    try:
        return normalize_url_list(candidates, label="Detected XMLTV guide")
    except ValueError:
        return []


def epg_proxy_url(source_id: uuid.UUID | str, feed_index: int, upstream_url: str) -> str:
    path = urlparse(upstream_url).path.lower()
    suffix = ".xml.gz" if path.endswith((".gz", ".gzip")) else ".xml"
    return f"http://m3u-gateway:8183/epg/{source_id}/{feed_index}{suffix}"


def parse_m3u(text: str) -> tuple[list[dict[str, str]], list[str]]:
    entries: list[dict[str, str]] = []
    pending: str | None = None
    duplicate_counter: Counter[str] = Counter()
    detected_epg: list[str] = []

    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if line.upper().startswith("#EXTM3U"):
            detected_epg.extend(detect_epg_urls(line))
            continue
        if line.upper().startswith("#EXTINF:"):
            pending = line
            continue
        if line.startswith("#") or pending is None:
            continue
        parsed = urlparse(line)
        if parsed.scheme not in {"http", "https", "rtsp", "rtp", "udp"}:
            pending = None
            continue

        attributes = {key.lower(): value.strip() for key, value in ATTR_RE.findall(pending)}
        name = pending.split(",", 1)[1].strip() if "," in pending else ""
        name = name or attributes.get("tvg-name") or attributes.get("tvg-id") or "Unnamed channel"
        group = attributes.get("group-title") or "Uncategorized"
        tvg_id = attributes.get("tvg-id", "")
        tvg_name = attributes.get("tvg-name", "")
        tvg_logo = attributes.get("tvg-logo") or attributes.get("logo", "")
        channel_number = attributes.get("tvg-chno", "")

        identity = f"id:{tvg_id}" if tvg_id else f"name:{group.casefold()}|{name.casefold()}"
        duplicate_counter[identity] += 1
        stable_seed = f"{identity}|{duplicate_counter[identity]}"
        stable_key = hashlib.sha256(stable_seed.encode("utf-8")).hexdigest()

        entries.append(
            {
                "stable_key": stable_key,
                "name": name,
                "group": group,
                "stream_url": line,
                "tvg_id": tvg_id,
                "tvg_name": tvg_name,
                "tvg_logo": tvg_logo,
                "channel_number": channel_number,
            }
        )
        pending = None

    detected_epg = effective_epg_urls([], detected_epg)
    return entries, detected_epg


async def refresh_source(request: Request, source_id: uuid.UUID) -> dict[str, Any]:
    pool = get_pool(request)
    async with pool.acquire() as connection:
        source = await connection.fetchrow(
            """
            SELECT id, name, source_url, user_agent, epg_urls
            FROM m3u_sources
            WHERE id = $1
            """,
            source_id,
        )
    if source is None:
        raise HTTPException(status_code=404, detail="M3U source not found.")

    headers: dict[str, str] = {}
    if source["user_agent"]:
        headers["User-Agent"] = source["user_agent"]

    try:
        response = await request.app.state.http.get(
            source["source_url"],
            headers=headers,
            follow_redirects=True,
            timeout=httpx.Timeout(90.0, connect=20.0),
        )
        response.raise_for_status()
        entries, detected_epg = parse_m3u(response.text)
        if not entries:
            raise ValueError("The source returned no valid M3U channels.")

        async with pool.acquire() as connection:
            async with connection.transaction():
                await connection.execute(
                    "UPDATE m3u_channels SET active = FALSE, updated_at = NOW() WHERE source_id = $1",
                    source_id,
                )

                category_ids: dict[str, uuid.UUID] = {}
                for group in dict.fromkeys(entry["group"] for entry in entries):
                    category_id = await connection.fetchval(
                        """
                        INSERT INTO m3u_categories (source_id, original_name, display_name)
                        VALUES ($1, $2, $2)
                        ON CONFLICT (source_id, original_name) DO UPDATE SET
                            updated_at = NOW()
                        RETURNING id
                        """,
                        source_id,
                        group,
                    )
                    category_ids[group] = category_id

                for entry in entries:
                    await connection.execute(
                        """
                        INSERT INTO m3u_channels
                            (source_id, category_id, stable_key, name, stream_url,
                             tvg_id, tvg_name, tvg_logo, channel_number, active, last_seen_at)
                        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, TRUE, NOW())
                        ON CONFLICT (source_id, stable_key) DO UPDATE SET
                            category_id = EXCLUDED.category_id,
                            name = EXCLUDED.name,
                            stream_url = EXCLUDED.stream_url,
                            tvg_id = EXCLUDED.tvg_id,
                            tvg_name = EXCLUDED.tvg_name,
                            tvg_logo = EXCLUDED.tvg_logo,
                            channel_number = EXCLUDED.channel_number,
                            active = TRUE,
                            last_seen_at = NOW(),
                            updated_at = NOW()
                        """,
                        source_id,
                        category_ids[entry["group"]],
                        entry["stable_key"],
                        entry["name"],
                        entry["stream_url"],
                        entry["tvg_id"],
                        entry["tvg_name"],
                        entry["tvg_logo"],
                        entry["channel_number"],
                    )

                await connection.execute(
                    """
                    UPDATE m3u_categories c
                    SET channel_count = counts.channel_count,
                        updated_at = NOW()
                    FROM (
                        SELECT category_id, COUNT(*)::int AS channel_count
                        FROM m3u_channels
                        WHERE source_id = $1 AND active = TRUE
                        GROUP BY category_id
                    ) counts
                    WHERE c.id = counts.category_id
                    """,
                    source_id,
                )
                await connection.execute(
                    """
                    UPDATE m3u_categories
                    SET channel_count = 0, updated_at = NOW()
                    WHERE source_id = $1
                      AND id NOT IN (
                          SELECT DISTINCT category_id FROM m3u_channels
                          WHERE source_id = $1 AND active = TRUE
                      )
                    """,
                    source_id,
                )
                category_count = await connection.fetchval(
                    "SELECT COUNT(*) FROM m3u_categories WHERE source_id = $1 AND channel_count > 0",
                    source_id,
                )
                await connection.execute(
                    """
                    UPDATE m3u_sources
                    SET last_refreshed_at = NOW(), last_error = NULL,
                        channel_count = $2, category_count = $3,
                        detected_epg_urls = $4::jsonb,
                        updated_at = NOW()
                    WHERE id = $1
                    """,
                    source_id,
                    len(entries),
                    category_count,
                    json.dumps(detected_epg),
                )

        epg_feeds = effective_epg_urls(source["epg_urls"], detected_epg)
        missing_tvg_ids = sum(1 for entry in entries if not entry["tvg_id"])
        return {
            "channels": len(entries),
            "categories": int(category_count),
            "epg_feeds": len(epg_feeds),
            "detected_epg_feeds": len(detected_epg),
            "missing_tvg_ids": missing_tvg_ids,
        }
    except Exception as exc:
        async with pool.acquire() as connection:
            await connection.execute(
                "UPDATE m3u_sources SET last_error = $2, updated_at = NOW() WHERE id = $1",
                source_id,
                str(exc)[:2000],
            )
        raise HTTPException(status_code=400, detail=f"M3U refresh failed: {exc}") from exc


async def start_guide_refresh(request: Request) -> bool:
    try:
        tasks = await request_json(
            request.app.state.http,
            "GET",
            "ScheduledTasks",
            require_key=True,
            expected_statuses=(200,),
        )
        task = next(
            (
                item
                for item in (tasks or [])
                if item.get("Key") == "RefreshGuide" or item.get("Name") == "Refresh Guide"
            ),
            None,
        )
        if not task or not task.get("Id"):
            return False
        if str(task.get("State", "")).lower() == "running":
            return True
        await request_json(
            request.app.state.http,
            "POST",
            f"ScheduledTasks/Running/{task['Id']}",
            require_key=True,
            expected_statuses=(204,),
        )
        return True
    except HTTPException:
        return False


@router.get("/status")
async def status(request: Request, _: PanelSession = Depends(read_session)) -> dict[str, Any]:
    pool = get_pool(request)
    async with pool.acquire() as connection:
        row = await connection.fetchrow(
            """
            SELECT
                (SELECT COUNT(*) FROM m3u_sources WHERE enabled = TRUE) AS sources,
                (SELECT COUNT(*) FROM m3u_categories WHERE enabled = TRUE AND channel_count > 0) AS enabled_categories,
                (SELECT COUNT(*) FROM m3u_categories WHERE channel_count > 0) AS total_categories,
                (SELECT COUNT(*) FROM m3u_channels ch
                    JOIN m3u_sources s ON s.id = ch.source_id
                    JOIN m3u_categories c ON c.id = ch.category_id
                    WHERE s.enabled = TRUE AND c.enabled = TRUE
                      AND ch.enabled = TRUE AND ch.active = TRUE) AS published_channels,
                (SELECT COUNT(*) FROM m3u_channels ch
                    JOIN m3u_sources s ON s.id = ch.source_id
                    JOIN m3u_categories c ON c.id = ch.category_id
                    WHERE s.enabled = TRUE AND c.enabled = TRUE
                      AND ch.enabled = TRUE AND ch.active = TRUE
                      AND BTRIM(COALESCE(NULLIF(ch.mapped_tvg_id, ''), ch.tvg_id)) = '') AS published_without_tvg_id
            """
        )
        tuner = await connection.fetchval(
            "SELECT value->>'id' FROM app_settings WHERE key = 'emby_m3u_tuner'"
        )
        provider_map = await connection.fetchval(
            "SELECT value FROM app_settings WHERE key = 'emby_xmltv_providers'"
        )
        source_rows = await connection.fetch(
            """
            SELECT epg_urls, detected_epg_urls
            FROM m3u_sources
            WHERE enabled = TRUE AND epg_enabled = TRUE
            """
        )
    epg_feeds = sum(
        len(effective_epg_urls(source["epg_urls"], source["detected_epg_urls"]))
        for source in source_rows
    )
    provider_count = len(json_object(provider_map))
    return {
        **dict(row),
        "epg_feeds": epg_feeds,
        "emby_connected": bool(tuner),
        "emby_epg_connected": provider_count > 0,
        "emby_epg_providers": provider_count,
        "internal_playlist_url": "http://m3u-gateway:8183/playlist/master.m3u",
    }


@router.get("/sources")
async def sources(request: Request, _: PanelSession = Depends(read_session)) -> dict[str, Any]:
    pool = get_pool(request)
    async with pool.acquire() as connection:
        rows = await connection.fetch(
            """
            SELECT s.id::text, s.name, s.source_url, s.user_agent, s.enabled,
                   s.refresh_minutes, s.max_connections, s.stream_mode,
                   s.last_refreshed_at, s.last_error, s.channel_count,
                   s.category_count, s.epg_urls, s.detected_epg_urls,
                   s.epg_user_agent, s.epg_enabled, s.last_epg_checked_at,
                   s.last_epg_error, s.created_at, s.updated_at,
                   (SELECT COUNT(*)::int FROM m3u_channels ch
                    WHERE ch.source_id = s.id AND ch.active = TRUE
                      AND BTRIM(COALESCE(NULLIF(ch.mapped_tvg_id, ''), ch.tvg_id)) = '') AS missing_tvg_ids
            FROM m3u_sources s
            ORDER BY s.name
            """
        )
    result: list[dict[str, Any]] = []
    for row in rows:
        item = dict(row)
        manual = json_url_list(item.get("epg_urls"))
        detected = json_url_list(item.get("detected_epg_urls"))
        effective = effective_epg_urls(manual, detected)
        item["epg_urls"] = manual
        item["detected_epg_urls"] = detected
        item["effective_epg_urls"] = effective
        item["epg_count"] = len(effective) if item.get("epg_enabled") else 0
        result.append(item)
    return {"sources": result, "count": len(result)}


@router.post("/sources", status_code=201)
async def create_source(
    request: Request,
    data: SourceRequest,
    session: PanelSession = Depends(write_session),
) -> dict[str, Any]:
    pool = get_pool(request)
    async with pool.acquire() as connection:
        row = await connection.fetchrow(
            """
            INSERT INTO m3u_sources
                (name, source_url, user_agent, enabled, refresh_minutes,
                 max_connections, epg_urls, epg_user_agent, epg_enabled)
            VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb, $8, $9)
            RETURNING id::text, name
            """,
            data.name,
            data.source_url,
            data.user_agent,
            data.enabled,
            data.refresh_minutes,
            data.max_connections,
            json.dumps(data.epg_urls),
            data.epg_user_agent,
            data.epg_enabled,
        )
    source_id = uuid.UUID(row["id"])
    result = await refresh_source(request, source_id)
    await audit(
        request,
        "m3u.source.create",
        actor=session.username,
        target_id=str(source_id),
        details={"name": data.name, **result},
    )
    return {"id": str(source_id), "name": data.name, **result}


@router.put("/sources/{source_id}")
async def update_source(
    source_id: uuid.UUID,
    request: Request,
    data: SourceRequest,
    session: PanelSession = Depends(write_session),
) -> dict[str, Any]:
    pool = get_pool(request)
    async with pool.acquire() as connection:
        result = await connection.execute(
            """
            UPDATE m3u_sources
            SET name = $2,
                source_url = $3,
                user_agent = $4,
                enabled = $5,
                refresh_minutes = $6,
                max_connections = $7,
                epg_urls = $8::jsonb,
                epg_user_agent = $9,
                epg_enabled = $10,
                updated_at = NOW()
            WHERE id = $1
            """,
            source_id,
            data.name,
            data.source_url,
            data.user_agent,
            data.enabled,
            data.refresh_minutes,
            data.max_connections,
            json.dumps(data.epg_urls),
            data.epg_user_agent,
            data.epg_enabled,
        )
    if result.endswith("0"):
        raise HTTPException(status_code=404, detail="M3U source not found.")
    refresh_result = await refresh_source(request, source_id)
    await audit(
        request,
        "m3u.source.update",
        actor=session.username,
        target_id=str(source_id),
        details={"name": data.name, **refresh_result},
    )
    return {"id": str(source_id), "name": data.name, **refresh_result}


@router.post("/sources/{source_id}/refresh")
async def refresh_source_endpoint(
    source_id: uuid.UUID,
    request: Request,
    session: PanelSession = Depends(write_session),
) -> dict[str, Any]:
    result = await refresh_source(request, source_id)
    await audit(
        request,
        "m3u.source.refresh",
        actor=session.username,
        target_id=str(source_id),
        details=result,
    )
    return {"ok": True, **result}


@router.post("/sources/{source_id}/epg/test")
async def test_epg(
    source_id: uuid.UUID,
    request: Request,
    session: PanelSession = Depends(write_session),
) -> dict[str, Any]:
    pool = get_pool(request)
    async with pool.acquire() as connection:
        source = await connection.fetchrow(
            """
            SELECT source_url, user_agent, epg_urls, detected_epg_urls,
                   epg_user_agent, epg_enabled
            FROM m3u_sources
            WHERE id = $1
            """,
            source_id,
        )
    if source is None:
        raise HTTPException(status_code=404, detail="M3U source not found.")
    if not source["epg_enabled"]:
        raise HTTPException(status_code=400, detail="EPG is disabled for this source.")

    urls = effective_epg_urls(source["epg_urls"], source["detected_epg_urls"])
    if not urls:
        raise HTTPException(
            status_code=400,
            detail="No XMLTV URL is configured or detected for this source.",
        )

    headers: dict[str, str] = {}
    user_agent = source["epg_user_agent"] or source["user_agent"]
    if user_agent:
        headers["User-Agent"] = user_agent

    results: list[dict[str, Any]] = []
    error_messages: list[str] = []
    for index, url in enumerate(urls):
        try:
            async with request.app.state.http.stream(
                "GET",
                url,
                headers=headers,
                follow_redirects=True,
                timeout=httpx.Timeout(90.0, connect=20.0),
            ) as response:
                response.raise_for_status()
                size = 0
                sample = bytearray()
                async for chunk in response.aiter_bytes():
                    size += len(chunk)
                    if len(sample) < 262144:
                        sample.extend(chunk[: 262144 - len(sample)])
                    if size >= 262144:
                        break
                if size == 0:
                    raise ValueError("XMLTV response was empty")
                path = urlparse(str(response.url)).path.lower()
                is_gzip = path.endswith((".gz", ".gzip")) or bytes(sample[:2]) == b"\x1f\x8b"
                if not is_gzip:
                    text = bytes(sample).decode("utf-8", errors="ignore").lower()
                    if "<tv" not in text and "<?xml" not in text:
                        raise ValueError("The response does not look like XMLTV data")
                results.append(
                    {
                        "index": index,
                        "status": "ok",
                        "http_status": response.status_code,
                        "content_type": response.headers.get("content-type", ""),
                    }
                )
        except Exception as exc:
            message = f"Feed {index + 1}: {exc}"
            error_messages.append(message)
            results.append({"index": index, "status": "error", "error": str(exc)[:500]})

    last_error = "; ".join(error_messages)[:2000] if error_messages else None
    async with pool.acquire() as connection:
        await connection.execute(
            """
            UPDATE m3u_sources
            SET last_epg_checked_at = NOW(), last_epg_error = $2, updated_at = NOW()
            WHERE id = $1
            """,
            source_id,
            last_error,
        )
    await audit(
        request,
        "m3u.epg.test",
        actor=session.username,
        target_id=str(source_id),
        details={"feeds": len(urls), "passed": len(urls) - len(error_messages)},
    )
    if error_messages:
        raise HTTPException(
            status_code=400,
            detail=f"EPG test failed for {len(error_messages)} of {len(urls)} feeds: {last_error}",
        )
    return {"ok": True, "feeds": len(urls), "results": results}


@router.delete("/sources/{source_id}")
async def delete_source(
    source_id: uuid.UUID,
    request: Request,
    session: PanelSession = Depends(write_session),
) -> dict[str, bool]:
    pool = get_pool(request)
    async with pool.acquire() as connection:
        result = await connection.execute("DELETE FROM m3u_sources WHERE id = $1", source_id)
    if result.endswith("0"):
        raise HTTPException(status_code=404, detail="M3U source not found.")
    await audit(request, "m3u.source.delete", actor=session.username, target_id=str(source_id))
    return {"deleted": True}


@router.get("/categories")
async def categories(
    source_id: uuid.UUID,
    request: Request,
    _: PanelSession = Depends(read_session),
) -> dict[str, Any]:
    pool = get_pool(request)
    async with pool.acquire() as connection:
        source = await connection.fetchrow("SELECT id, name FROM m3u_sources WHERE id = $1", source_id)
        if source is None:
            raise HTTPException(status_code=404, detail="M3U source not found.")
        rows = await connection.fetch(
            """
            SELECT id::text, original_name, display_name, enabled, channel_count, sort_order
            FROM m3u_categories
            WHERE source_id = $1 AND channel_count > 0
            ORDER BY sort_order, display_name
            """,
            source_id,
        )
    return {
        "source": {"id": str(source["id"]), "name": source["name"]},
        "categories": [dict(row) for row in rows],
    }


@router.put("/categories/selection")
async def save_category_selection(
    request: Request,
    data: CategorySelectionRequest,
    session: PanelSession = Depends(write_session),
) -> dict[str, int]:
    pool = get_pool(request)
    async with pool.acquire() as connection:
        async with connection.transaction():
            total = await connection.fetchval(
                "SELECT COUNT(*) FROM m3u_categories WHERE source_id = $1 AND channel_count > 0",
                data.source_id,
            )
            await connection.execute(
                "UPDATE m3u_categories SET enabled = FALSE, updated_at = NOW() WHERE source_id = $1",
                data.source_id,
            )
            if data.enabled_ids:
                await connection.execute(
                    """
                    UPDATE m3u_categories
                    SET enabled = TRUE, updated_at = NOW()
                    WHERE source_id = $1 AND id = ANY($2::uuid[])
                    """,
                    data.source_id,
                    data.enabled_ids,
                )
            enabled = await connection.fetchval(
                "SELECT COUNT(*) FROM m3u_categories WHERE source_id = $1 AND enabled = TRUE AND channel_count > 0",
                data.source_id,
            )
    await audit(
        request,
        "m3u.categories.update",
        actor=session.username,
        target_id=str(data.source_id),
        details={"enabled": int(enabled), "total": int(total)},
    )
    return {"enabled": int(enabled), "total": int(total)}


@router.post("/emby/connect")
async def connect_emby(
    request: Request,
    session: PanelSession = Depends(write_session),
) -> dict[str, Any]:
    pool = get_pool(request)
    async with pool.acquire() as connection:
        existing_id = await connection.fetchval(
            "SELECT value->>'id' FROM app_settings WHERE key = 'emby_m3u_tuner'"
        )
        existing_provider_map = await connection.fetchval(
            "SELECT value FROM app_settings WHERE key = 'emby_xmltv_providers'"
        )
        source_rows = await connection.fetch(
            """
            SELECT id::text, epg_urls, detected_epg_urls
            FROM m3u_sources
            WHERE enabled = TRUE AND epg_enabled = TRUE
            ORDER BY name, id
            """
        )

    payload: dict[str, Any] = {
        "Type": "m3u",
        "Url": "http://m3u-gateway:8183/playlist/master.m3u",
        "FriendlyName": "3mbyPanel Filtered M3U",
        "TunerCount": 0,
        "AllowStreamSharing": True,
        "AllowHWTranscoding": True,
        "IgnoreDts": True,
        "ReadAtNativeFramerate": False,
    }
    if existing_id:
        payload["Id"] = existing_id

    try:
        tuner = await request_json(
            request.app.state.http,
            "POST",
            "LiveTv/TunerHosts",
            require_key=True,
            json_data=payload,
            expected_statuses=(200,),
        )
    except HTTPException:
        payload.pop("Id", None)
        tuner = await request_json(
            request.app.state.http,
            "POST",
            "LiveTv/TunerHosts",
            require_key=True,
            json_data=payload,
            expected_statuses=(200,),
        )

    tuner_id = tuner.get("Id")
    if not tuner_id:
        raise HTTPException(status_code=502, detail="Emby did not return a tuner ID.")

    old_map = json_object(existing_provider_map)
    new_map: dict[str, dict[str, str]] = {}
    desired_keys: set[str] = set()

    for source in source_rows:
        urls = effective_epg_urls(source["epg_urls"], source["detected_epg_urls"])
        for index, upstream_url in enumerate(urls):
            key = f"{source['id']}:{index}"
            desired_keys.add(key)
            proxy_url = epg_proxy_url(source["id"], index, upstream_url)
            existing_provider = old_map.get(key) if isinstance(old_map.get(key), dict) else {}
            if (
                existing_provider.get("id")
                and existing_provider.get("path") == proxy_url
                and existing_provider.get("tuner_id") == tuner_id
            ):
                new_map[key] = {
                    "id": existing_provider["id"],
                    "path": proxy_url,
                    "tuner_id": tuner_id,
                }
                continue

            provider_payload: dict[str, Any] = {
                "Type": "xmltv",
                "Path": proxy_url,
                "EnableAllTuners": False,
                "EnabledTuners": [tuner_id],
                "NewsCategories": ["news", "journalism", "documentary", "current affairs"],
                "SportsCategories": ["sports", "basketball", "baseball", "football"],
                "KidsCategories": ["kids", "family", "children", "childrens", "disney"],
                "MovieCategories": ["movie"],
                "PreferredLanguage": "en",
                "ChannelMappings": [],
            }
            if existing_provider.get("id"):
                provider_payload["Id"] = existing_provider["id"]
            try:
                provider = await request_json(
                    request.app.state.http,
                    "POST",
                    "LiveTv/ListingProviders",
                    require_key=True,
                    json_data=provider_payload,
                    params={"validateListings": "false", "validateLogin": "false"},
                    expected_statuses=(200,),
                )
            except HTTPException:
                stale_id = provider_payload.pop("Id", None)
                if stale_id:
                    try:
                        await request_json(
                            request.app.state.http,
                            "DELETE",
                            "LiveTv/ListingProviders",
                            require_key=True,
                            params={"id": stale_id},
                            expected_statuses=(204,),
                        )
                    except HTTPException:
                        pass
                provider = await request_json(
                    request.app.state.http,
                    "POST",
                    "LiveTv/ListingProviders",
                    require_key=True,
                    json_data=provider_payload,
                    params={"validateListings": "false", "validateLogin": "false"},
                    expected_statuses=(200,),
                )
            provider_id = provider.get("Id")
            if not provider_id:
                raise HTTPException(status_code=502, detail="Emby did not return an XMLTV provider ID.")
            new_map[key] = {"id": provider_id, "path": proxy_url, "tuner_id": tuner_id}

    # Remove only providers previously created by 3mbyPanel that are no longer configured.
    for key, old_provider in old_map.items():
        if key in desired_keys or not isinstance(old_provider, dict) or not old_provider.get("id"):
            continue
        try:
            await request_json(
                request.app.state.http,
                "DELETE",
                "LiveTv/ListingProviders",
                require_key=True,
                params={"id": old_provider["id"]},
                expected_statuses=(204,),
            )
        except HTTPException:
            # A stale or manually removed provider should not block the current sync.
            pass

    async with pool.acquire() as connection:
        async with connection.transaction():
            await connection.execute(
                """
                INSERT INTO app_settings (key, value, updated_at)
                VALUES ('emby_m3u_tuner', $1::jsonb, NOW())
                ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()
                """,
                json.dumps({"id": tuner_id}),
            )
            await connection.execute(
                """
                INSERT INTO app_settings (key, value, updated_at)
                VALUES ('emby_xmltv_providers', $1::jsonb, NOW())
                ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()
                """,
                json.dumps(new_map),
            )

    guide_refresh_started = await start_guide_refresh(request) if new_map else False
    await audit(
        request,
        "m3u.emby.connect",
        actor=session.username,
        target_id=tuner_id,
        details={
            "playlist": payload["Url"],
            "epg_providers": len(new_map),
            "guide_refresh_started": guide_refresh_started,
        },
    )
    return {
        "connected": True,
        "tuner_id": tuner_id,
        "name": tuner.get("FriendlyName"),
        "epg_providers": len(new_map),
        "guide_refresh_started": guide_refresh_started,
    }


@router.post("/emby/refresh-guide")
async def refresh_guide(
    request: Request,
    session: PanelSession = Depends(write_session),
) -> dict[str, Any]:
    started = await start_guide_refresh(request)
    if not started:
        raise HTTPException(
            status_code=502,
            detail="Emby did not expose or start the Refresh Guide task.",
        )
    await audit(
        request,
        "m3u.emby.refresh-guide",
        actor=session.username,
        details={"started": True},
    )
    return {"started": True}
