from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
import uuid
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path, PurePosixPath
from typing import Any

import asyncpg
import httpx
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field, field_validator

from .access import require_admin_role
from .security import PanelSession, ensure_writes_enabled, require_session, validate_csrf
from .settings import settings

router = APIRouter(prefix="/mirror", tags=["library-mirror"])

EPISODE_RE = re.compile(r"(?i)(?:\bS(?P<s>\d{1,2})E(?P<e>\d{1,3})\b|\b(?P<s2>\d{1,2})x(?P<e2>\d{1,3})\b)")
SEASON_DIR_RE = re.compile(r"(?i)^season[ ._-]*(\d{1,2})$")
LEADING_EPISODE_RE = re.compile(r"(?i)^(?:episode[ ._-]*)?(\d{1,3})(?:\D|$)")
TMDB_RE = re.compile(r"(?i)(?:tmdb(?:id)?)[\s._:=\-]*(\d+)")
IMDB_RE = re.compile(r"(?i)\b(tt\d{5,12})\b")
YEAR_RE = re.compile(r"(?<!\d)((?:19|20)\d{2})(?!\d)")
TAG_RE = re.compile(r"[\[\{\(](?:tmdb(?:id)?|imdb)[^\]\}\)]*[\]\}\)]", re.I)
TECH_RE = re.compile(
    r"(?i)\b(?:2160p|1080p|720p|480p|4k|uhd|hdr10\+?|dolby[ ._-]?vision|dv|"
    r"bluray|blu[ ._-]?ray|web[ ._-]?dl|webrip|hdtv|remux|x26[45]|h26[45]|hevc|av1|"
    r"aac|dts(?:-hd)?|truehd|atmos|ddp?\d(?:\.\d)?|proper|repack|extended|unrated)\b.*$"
)
GENERIC_DIRS = {
    "media", "movie", "movies", "film", "films", "tv", "tv show", "tv shows",
    "shows", "series", "television", "season", "specials",
}
TV_MARKERS = {"tv", "tv show", "tv shows", "shows", "series", "television"}


class MirrorSettingsRequest(BaseModel):
    source_host_path: str = Field(min_length=1, max_length=1000)
    tmdb_token: str = Field(default="", max_length=4096)
    language: str = Field(default="en-US", min_length=2, max_length=20)
    region: str = Field(default="US", min_length=2, max_length=10)
    cache_days: int = Field(default=30, ge=1, le=3650)
    download_images: bool = True
    remove_missing: bool = True

    @field_validator("source_host_path", "language", "region")
    @classmethod
    def strip_values(cls, value: str) -> str:
        return value.strip()


class StartMirrorRequest(BaseModel):
    force_metadata: bool = False


class MirrorCancelled(Exception):
    pass


@dataclass(frozen=True)
class ParsedMedia:
    kind: str
    source_path: str
    title: str
    year: int | None
    tmdb_id: int | None
    imdb_id: str | None
    series_title: str = ""
    series_year: int | None = None
    series_tmdb_id: int | None = None
    season: int | None = None
    episode: int | None = None


async def write_session(
    request: Request,
    session: PanelSession = Depends(require_session),
) -> PanelSession:
    require_admin_role(session)
    ensure_writes_enabled()
    validate_csrf(session, request.headers.get("X-CSRF-Token"))
    return session


async def read_session(session: PanelSession = Depends(require_session)) -> PanelSession:
    require_admin_role(session)
    return session


def get_pool(request: Request) -> asyncpg.Pool:
    pool = request.app.state.db
    if pool is None:
        raise HTTPException(status_code=503, detail="Database is unavailable.")
    return pool


def normalize_source_path(value: str) -> tuple[str, str]:
    base = os.path.normpath(settings.media_host_path)
    candidate = os.path.normpath(value.strip())
    if not os.path.isabs(candidate):
        candidate = os.path.normpath(os.path.join(base, candidate))
    try:
        common = os.path.commonpath([base, candidate])
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="Invalid source path.") from exc
    if common != base:
        raise HTTPException(status_code=400, detail=f"Source path must remain inside {base}.")
    relative = os.path.relpath(candidate, base)
    return candidate, "" if relative == "." else relative.replace(os.sep, "/").strip("/")


def clean_component(value: str, fallback: str = "Unknown") -> str:
    value = value.replace("/", "-").replace("\\", "-").replace(":", " - ")
    value = re.sub(r"[\x00-\x1f<>\"|?*]", "", value)
    value = re.sub(r"\s+", " ", value).strip(" .")
    return value[:180] or fallback


def strip_title(value: str) -> tuple[str, int | None]:
    value = PurePosixPath(value).stem
    tmdb_clean = TAG_RE.sub(" ", value)
    tmdb_clean = re.sub(r"(?i)[\[\{]\s*(?:tmdb(?:id)?|imdb)[^\]\}]*[\]\}]", " ", tmdb_clean)
    tmdb_clean = TECH_RE.sub("", tmdb_clean)
    years = YEAR_RE.findall(tmdb_clean)
    year = int(years[-1]) if years else None
    if year:
        tmdb_clean = re.sub(rf"[\(\[\{{]?\s*{year}\s*[\)\]\}}]?", " ", tmdb_clean)
    tmdb_clean = EPISODE_RE.sub(" ", tmdb_clean)
    tmdb_clean = re.sub(r"[._]+", " ", tmdb_clean)
    tmdb_clean = re.sub(r"\s+-\s+.*$", "", tmdb_clean)
    tmdb_clean = re.sub(r"\s+", " ", tmdb_clean).strip(" -._")
    return tmdb_clean or PurePosixPath(value).stem, year


def extract_id(pattern: re.Pattern[str], value: str) -> str | None:
    match = pattern.search(value)
    return match.group(1) if match else None


def is_tv_path(parts: tuple[str, ...]) -> bool:
    for part in parts:
        normalized = re.sub(r"[._-]+", " ", part.lower()).strip()
        if normalized in TV_MARKERS or normalized.startswith("tv shows"):
            return True
    return False


def best_series_segment(parts: tuple[str, ...], season_index: int | None) -> str:
    if season_index is not None and season_index > 0:
        return parts[season_index - 1]
    for index, part in enumerate(parts[:-1]):
        normalized = re.sub(r"[._-]+", " ", part.lower()).strip()
        if normalized in TV_MARKERS and index + 1 < len(parts) - 1:
            return parts[index + 1]
    return parts[-2] if len(parts) >= 2 else PurePosixPath(parts[-1]).stem


def parse_media(path: str) -> ParsedMedia:
    pure = PurePosixPath(path)
    parts = pure.parts
    full = "/".join(parts)
    filename = pure.name
    episode_match = EPISODE_RE.search(filename)
    season = episode = None
    season_index = None
    for idx, part in enumerate(parts[:-1]):
        match = SEASON_DIR_RE.match(part)
        if match:
            season = int(match.group(1))
            season_index = idx
    if episode_match:
        season = int(episode_match.group("s") or episode_match.group("s2"))
        episode = int(episode_match.group("e") or episode_match.group("e2"))
    elif season is not None:
        match = LEADING_EPISODE_RE.match(PurePosixPath(filename).stem)
        if match:
            episode = int(match.group(1))

    if episode is not None or (season is not None and is_tv_path(parts)):
        series_raw = best_series_segment(parts, season_index)
        series_title, series_year = strip_title(series_raw)
        episode_title, _ = strip_title(filename)
        episode_title = EPISODE_RE.sub("", episode_title).strip(" -") or f"Episode {episode or 0}"
        series_tmdb = extract_id(TMDB_RE, series_raw)
        imdb_id = extract_id(IMDB_RE, series_raw)
        return ParsedMedia(
            kind="episode",
            source_path=path,
            title=episode_title,
            year=None,
            tmdb_id=None,
            imdb_id=imdb_id,
            series_title=series_title,
            series_year=series_year,
            series_tmdb_id=int(series_tmdb) if series_tmdb else None,
            season=season or 0,
            episode=episode or 0,
        )

    parent = pure.parent.name
    candidate = parent if re.sub(r"[._-]+", " ", parent.lower()).strip() not in GENERIC_DIRS else filename
    title, year = strip_title(candidate)
    tmdb_id = extract_id(TMDB_RE, candidate) or extract_id(TMDB_RE, full)
    imdb_id = extract_id(IMDB_RE, candidate) or extract_id(IMDB_RE, full)
    return ParsedMedia(
        kind="movie",
        source_path=path,
        title=title,
        year=year,
        tmdb_id=int(tmdb_id) if tmdb_id else None,
        imdb_id=imdb_id,
    )


def add_text(parent: ET.Element, tag: str, value: Any) -> None:
    if value is None or value == "":
        return
    ET.SubElement(parent, tag).text = str(value)


def xml_bytes(root: ET.Element) -> bytes:
    ET.indent(root, space="  ")
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def movie_nfo(data: dict[str, Any]) -> bytes:
    root = ET.Element("movie")
    add_text(root, "title", data.get("title"))
    add_text(root, "originaltitle", data.get("original_title"))
    add_text(root, "sorttitle", data.get("title"))
    release = data.get("release_date") or ""
    add_text(root, "year", release[:4] if release else None)
    add_text(root, "premiered", release)
    add_text(root, "plot", data.get("overview"))
    add_text(root, "outline", data.get("overview"))
    add_text(root, "tagline", data.get("tagline"))
    add_text(root, "runtime", data.get("runtime"))
    add_text(root, "rating", data.get("vote_average"))
    add_text(root, "mpaa", certification_from(data.get("release_dates"), "movie"))
    uid = ET.SubElement(root, "uniqueid", {"type": "tmdb", "default": "true"})
    uid.text = str(data.get("id"))
    imdb = data.get("imdb_id") or (data.get("external_ids") or {}).get("imdb_id")
    if imdb:
        ET.SubElement(root, "uniqueid", {"type": "imdb"}).text = str(imdb)
    for genre in data.get("genres") or []:
        add_text(root, "genre", genre.get("name"))
    for company in (data.get("production_companies") or [])[:3]:
        add_text(root, "studio", company.get("name"))
    credits = data.get("credits") or {}
    for person in (credits.get("cast") or [])[:20]:
        actor = ET.SubElement(root, "actor")
        add_text(actor, "name", person.get("name"))
        add_text(actor, "role", person.get("character"))
        add_text(actor, "order", person.get("order"))
    return xml_bytes(root)


def tvshow_nfo(data: dict[str, Any]) -> bytes:
    root = ET.Element("tvshow")
    add_text(root, "title", data.get("name"))
    add_text(root, "originaltitle", data.get("original_name"))
    first_air = data.get("first_air_date") or ""
    add_text(root, "year", first_air[:4] if first_air else None)
    add_text(root, "premiered", first_air)
    add_text(root, "plot", data.get("overview"))
    add_text(root, "rating", data.get("vote_average"))
    add_text(root, "mpaa", certification_from(data.get("content_ratings"), "tv"))
    uid = ET.SubElement(root, "uniqueid", {"type": "tmdb", "default": "true"})
    uid.text = str(data.get("id"))
    imdb = (data.get("external_ids") or {}).get("imdb_id")
    if imdb:
        ET.SubElement(root, "uniqueid", {"type": "imdb"}).text = str(imdb)
    for genre in data.get("genres") or []:
        add_text(root, "genre", genre.get("name"))
    for network in (data.get("networks") or [])[:3]:
        add_text(root, "studio", network.get("name"))
    credits = data.get("credits") or {}
    for person in (credits.get("cast") or [])[:20]:
        actor = ET.SubElement(root, "actor")
        add_text(actor, "name", person.get("name"))
        add_text(actor, "role", person.get("character"))
        add_text(actor, "order", person.get("order"))
    return xml_bytes(root)


def episode_nfo(series_id: int, episode_data: dict[str, Any], season: int, episode: int) -> bytes:
    root = ET.Element("episodedetails")
    add_text(root, "title", episode_data.get("name") or f"Episode {episode}")
    add_text(root, "season", season)
    add_text(root, "episode", episode)
    add_text(root, "aired", episode_data.get("air_date"))
    add_text(root, "plot", episode_data.get("overview"))
    add_text(root, "rating", episode_data.get("vote_average"))
    if episode_data.get("id"):
        ET.SubElement(root, "uniqueid", {"type": "tmdb", "default": "true"}).text = str(episode_data["id"])
    ET.SubElement(root, "uniqueid", {"type": "tmdbshow"}).text = str(series_id)
    for person in (episode_data.get("guest_stars") or [])[:15]:
        actor = ET.SubElement(root, "actor")
        add_text(actor, "name", person.get("name"))
        add_text(actor, "role", person.get("character"))
    return xml_bytes(root)


def certification_from(container: Any, kind: str) -> str | None:
    if not isinstance(container, dict):
        return None
    if kind == "movie":
        rows = container.get("results") or []
        for country in rows:
            if country.get("iso_3166_1") == "US":
                for release in country.get("release_dates") or []:
                    if release.get("certification"):
                        return release["certification"]
    else:
        for row in container.get("results") or []:
            if row.get("iso_3166_1") == "US" and row.get("rating"):
                return row["rating"]
    return None


async def atomic_write(path: Path, payload: bytes | str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    if isinstance(payload, str):
        temporary.write_text(payload, encoding="utf-8")
    else:
        temporary.write_bytes(payload)
    temporary.replace(path)


async def download_image(client: httpx.AsyncClient, image_path: str | None, target: Path, size: str) -> None:
    if not image_path or target.exists():
        return
    response = await client.get(f"https://image.tmdb.org/t/p/{size}{image_path}", timeout=45)
    response.raise_for_status()
    await atomic_write(target, response.content)


async def tmdb_request(
    pool: asyncpg.Pool,
    client: httpx.AsyncClient,
    token: str,
    cache_key: str,
    path: str,
    params: dict[str, Any],
    cache_days: int,
) -> dict[str, Any]:
    async with pool.acquire() as connection:
        row = await connection.fetchrow(
            "SELECT payload FROM tmdb_metadata_cache WHERE cache_key=$1 AND fetched_at > NOW() - make_interval(days => $2::int)",
            cache_key,
            cache_days,
        )
    if row:
        cached = row["payload"]
        return json.loads(cached) if isinstance(cached, str) else dict(cached)
    headers = {"accept": "application/json"}
    request_params = dict(params)
    if token.startswith("eyJ") or len(token) > 80:
        headers["Authorization"] = f"Bearer {token}"
    else:
        request_params["api_key"] = token
    response = await client.get(f"https://api.themoviedb.org/3/{path.lstrip('/')}", params=request_params, headers=headers, timeout=45)
    if response.status_code in {401, 403}:
        raise RuntimeError("TMDB rejected the API credential.")
    response.raise_for_status()
    payload = response.json()
    async with pool.acquire() as connection:
        await connection.execute(
            """
            INSERT INTO tmdb_metadata_cache (cache_key, payload, fetched_at)
            VALUES ($1, $2::jsonb, NOW())
            ON CONFLICT (cache_key) DO UPDATE SET payload=EXCLUDED.payload, fetched_at=NOW()
            """,
            cache_key,
            json.dumps(payload),
        )
    return payload


async def resolve_movie(pool: asyncpg.Pool, client: httpx.AsyncClient, token: str, parsed: ParsedMedia, language: str, region: str, cache_days: int) -> dict[str, Any] | None:
    tmdb_id = parsed.tmdb_id
    if not tmdb_id and parsed.imdb_id:
        found = await tmdb_request(pool, client, token, f"find:{parsed.imdb_id}:{language}", f"find/{parsed.imdb_id}", {"external_source": "imdb_id", "language": language}, cache_days)
        results = found.get("movie_results") or []
        tmdb_id = int(results[0]["id"]) if results else None
    if not tmdb_id:
        params: dict[str, Any] = {"query": parsed.title, "language": language, "include_adult": "false", "region": region}
        if parsed.year:
            params["year"] = parsed.year
        found = await tmdb_request(pool, client, token, f"search:movie:{parsed.title}:{parsed.year}:{language}:{region}", "search/movie", params, cache_days)
        results = found.get("results") or []
        tmdb_id = int(results[0]["id"]) if results else None
    if not tmdb_id:
        return None
    return await tmdb_request(
        pool, client, token, f"movie:{tmdb_id}:{language}", f"movie/{tmdb_id}",
        {"language": language, "append_to_response": "credits,external_ids,release_dates,images"}, cache_days,
    )


async def resolve_series(pool: asyncpg.Pool, client: httpx.AsyncClient, token: str, parsed: ParsedMedia, language: str, cache_days: int) -> dict[str, Any] | None:
    tmdb_id = parsed.series_tmdb_id
    if not tmdb_id and parsed.imdb_id:
        found = await tmdb_request(pool, client, token, f"find:{parsed.imdb_id}:{language}", f"find/{parsed.imdb_id}", {"external_source": "imdb_id", "language": language}, cache_days)
        results = found.get("tv_results") or []
        tmdb_id = int(results[0]["id"]) if results else None
    if not tmdb_id:
        params: dict[str, Any] = {"query": parsed.series_title, "language": language, "include_adult": "false"}
        if parsed.series_year:
            params["first_air_date_year"] = parsed.series_year
        found = await tmdb_request(pool, client, token, f"search:tv:{parsed.series_title}:{parsed.series_year}:{language}", "search/tv", params, cache_days)
        results = found.get("results") or []
        tmdb_id = int(results[0]["id"]) if results else None
    if not tmdb_id:
        return None
    return await tmdb_request(
        pool, client, token, f"tv:{tmdb_id}:{language}", f"tv/{tmdb_id}",
        {"language": language, "append_to_response": "credits,external_ids,content_ratings,images"}, cache_days,
    )


async def resolve_season(pool: asyncpg.Pool, client: httpx.AsyncClient, token: str, series_id: int, season: int, language: str, cache_days: int) -> dict[str, Any]:
    return await tmdb_request(
        pool, client, token, f"season:{series_id}:{season}:{language}", f"tv/{series_id}/season/{season}",
        {"language": language}, cache_days,
    )


async def upsert_mapping(pool: asyncpg.Pool, row: asyncpg.Record, parsed: ParsedMedia) -> tuple[asyncpg.Record, bool]:
    new_size = int(row["size_bytes"] or 0)
    new_modified = row["modified_at"]
    async with pool.acquire() as connection:
        existing = await connection.fetchrow(
            "SELECT source_size_bytes,source_modified_at,active FROM library_mirror_items WHERE inventory_path=$1",
            parsed.source_path,
        )
        source_changed = (
            existing is None
            or int(existing["source_size_bytes"] or 0) != new_size
            or existing["source_modified_at"] != new_modified
            or not bool(existing["active"])
        )
        mapping = await connection.fetchrow(
            """
            INSERT INTO library_mirror_items
                (inventory_path, media_kind, title, series_title, production_year,
                 series_tmdb_id, season_number, episode_number, source_size_bytes,
                 source_modified_at, active, updated_at)
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,TRUE,NOW())
            ON CONFLICT (inventory_path) DO UPDATE SET
                media_kind=EXCLUDED.media_kind,
                title=EXCLUDED.title,
                series_title=EXCLUDED.series_title,
                production_year=EXCLUDED.production_year,
                season_number=EXCLUDED.season_number,
                episode_number=EXCLUDED.episode_number,
                source_size_bytes=EXCLUDED.source_size_bytes,
                source_modified_at=EXCLUDED.source_modified_at,
                active=TRUE,
                updated_at=NOW()
            RETURNING *
            """,
            parsed.source_path, parsed.kind, parsed.title, parsed.series_title,
            parsed.year or parsed.series_year, parsed.series_tmdb_id, parsed.season,
            parsed.episode, new_size, new_modified,
        )
    return mapping, source_changed


def output_root() -> Path:
    return Path(settings.mirror_output_root)


async def remove_item_files(relative: str) -> bool:
    if not relative:
        return False
    target = (output_root() / relative).resolve()
    root = output_root().resolve()
    if root not in target.parents:
        return False
    removed = False
    for path in [target, target.with_suffix(".nfo")]:
        if path.is_file():
            path.unlink(missing_ok=True)
            removed = True
    return removed


def prune_empty_dirs(root: Path) -> None:
    if not root.exists():
        return
    for directory, _, _ in os.walk(root, topdown=False):
        path = Path(directory)
        if path == root:
            continue
        try:
            next(path.iterdir())
        except StopIteration:
            path.rmdir()
        except FileNotFoundError:
            pass


async def build_movie(
    pool: asyncpg.Pool,
    client: httpx.AsyncClient,
    config: asyncpg.Record,
    mapping: asyncpg.Record,
    parsed: ParsedMedia,
    force: bool,
) -> tuple[str, str | None]:
    root = output_root() / str(config["movies_folder"])
    current_rel = str(mapping["mirror_relative_path"] or "")
    if not force and mapping["metadata_status"] == "matched" and current_rel and (output_root() / current_rel).is_file():
        return "skipped", current_rel
    metadata = await resolve_movie(pool, client, str(config["tmdb_token"]), parsed, str(config["language"]), str(config["region"]), int(config["cache_days"]))
    stable_id = str(mapping["stable_id"])
    source_ext = PurePosixPath(parsed.source_path).suffix.lower() or ".mkv"
    if metadata:
        title = clean_component(str(metadata.get("title") or parsed.title))
        release = str(metadata.get("release_date") or "")
        year = int(release[:4]) if release[:4].isdigit() else parsed.year
        folder_name = f"{title} ({year}) [tmdbid-{metadata['id']}]" if year else f"{title} [tmdbid-{metadata['id']}]"
        folder = root / folder_name
        base_name = folder_name
        strm = folder / f"{base_name}.strm"
        relative = str(strm.relative_to(output_root())).replace(os.sep, "/")
        await atomic_write(strm, f"{str(config['gateway_base_url']).rstrip('/')}/media/{stable_id}/stream{source_ext}\n")
        await atomic_write(strm.with_suffix(".nfo"), movie_nfo(metadata))
        if bool(config["download_images"]):
            await download_image(client, metadata.get("poster_path"), folder / "poster.jpg", "w500")
            await download_image(client, metadata.get("backdrop_path"), folder / "backdrop.jpg", "w1280")
        async with pool.acquire() as connection:
            await connection.execute(
                """UPDATE library_mirror_items SET tmdb_id=$2,title=$3,production_year=$4,
                mirror_relative_path=$5,metadata_status='matched',last_error=NULL,last_built_at=NOW(),updated_at=NOW()
                WHERE id=$1""",
                mapping["id"], int(metadata["id"]), title, year, relative,
            )
        if current_rel and current_rel != relative:
            await remove_item_files(current_rel)
        return "movie", relative
    folder = root / clean_component(parsed.title)
    strm = folder / f"{clean_component(parsed.title)}.strm"
    relative = str(strm.relative_to(output_root())).replace(os.sep, "/")
    await atomic_write(strm, f"{str(config['gateway_base_url']).rstrip('/')}/media/{stable_id}/stream{source_ext}\n")
    async with pool.acquire() as connection:
        await connection.execute(
            "UPDATE library_mirror_items SET mirror_relative_path=$2,metadata_status='unmatched',last_error='TMDB match not found',last_built_at=NOW(),updated_at=NOW() WHERE id=$1",
            mapping["id"], relative,
        )
    return "unmatched", relative


async def build_episode(
    pool: asyncpg.Pool,
    client: httpx.AsyncClient,
    config: asyncpg.Record,
    mapping: asyncpg.Record,
    parsed: ParsedMedia,
    force: bool,
    series_cache: dict[str, dict[str, Any] | None],
    season_cache: dict[tuple[int, int], dict[str, Any]],
) -> tuple[str, str | None]:
    current_rel = str(mapping["mirror_relative_path"] or "")
    if not force and mapping["metadata_status"] == "matched" and current_rel and (output_root() / current_rel).is_file():
        return "skipped", current_rel
    cache_key = f"{parsed.series_tmdb_id or 0}:{parsed.series_title}:{parsed.series_year or 0}"
    if cache_key not in series_cache:
        series_cache[cache_key] = await resolve_series(pool, client, str(config["tmdb_token"]), parsed, str(config["language"]), int(config["cache_days"]))
    series = series_cache[cache_key]
    stable_id = str(mapping["stable_id"])
    source_ext = PurePosixPath(parsed.source_path).suffix.lower() or ".mkv"
    if series:
        series_id = int(series["id"])
        series_title = clean_component(str(series.get("name") or parsed.series_title))
        first_air = str(series.get("first_air_date") or "")
        year = int(first_air[:4]) if first_air[:4].isdigit() else parsed.series_year
        show_folder_name = f"{series_title} ({year}) [tmdbid-{series_id}]" if year else f"{series_title} [tmdbid-{series_id}]"
        show_folder = output_root() / str(config["tv_folder"]) / show_folder_name
        await atomic_write(show_folder / "tvshow.nfo", tvshow_nfo(series))
        if bool(config["download_images"]):
            await download_image(client, series.get("poster_path"), show_folder / "poster.jpg", "w500")
            await download_image(client, series.get("backdrop_path"), show_folder / "backdrop.jpg", "w1280")
        season_num = int(parsed.season or 0)
        episode_num = int(parsed.episode or 0)
        season_key = (series_id, season_num)
        if season_key not in season_cache:
            season_cache[season_key] = await resolve_season(pool, client, str(config["tmdb_token"]), series_id, season_num, str(config["language"]), int(config["cache_days"]))
        season_data = season_cache[season_key]
        episode_data = next((item for item in season_data.get("episodes") or [] if int(item.get("episode_number") or -1) == episode_num), {})
        episode_title = clean_component(str(episode_data.get("name") or parsed.title or f"Episode {episode_num}"))
        season_folder = show_folder / ("Specials" if season_num == 0 else f"Season {season_num:02d}")
        file_base = f"{series_title} - S{season_num:02d}E{episode_num:02d} - {episode_title}"
        strm = season_folder / f"{file_base}.strm"
        relative = str(strm.relative_to(output_root())).replace(os.sep, "/")
        await atomic_write(strm, f"{str(config['gateway_base_url']).rstrip('/')}/media/{stable_id}/stream{source_ext}\n")
        await atomic_write(strm.with_suffix(".nfo"), episode_nfo(series_id, episode_data, season_num, episode_num))
        async with pool.acquire() as connection:
            await connection.execute(
                """UPDATE library_mirror_items SET series_tmdb_id=$2,title=$3,series_title=$4,
                production_year=$5,mirror_relative_path=$6,metadata_status='matched',last_error=NULL,
                last_built_at=NOW(),updated_at=NOW() WHERE id=$1""",
                mapping["id"], series_id, episode_title, series_title, year, relative,
            )
        if current_rel and current_rel != relative:
            await remove_item_files(current_rel)
        return "episode", relative
    show_folder = output_root() / str(config["tv_folder"]) / clean_component(parsed.series_title)
    season_num = int(parsed.season or 0)
    episode_num = int(parsed.episode or 0)
    season_folder = show_folder / ("Specials" if season_num == 0 else f"Season {season_num:02d}")
    strm = season_folder / f"{clean_component(parsed.series_title)} - S{season_num:02d}E{episode_num:02d}.strm"
    relative = str(strm.relative_to(output_root())).replace(os.sep, "/")
    await atomic_write(strm, f"{str(config['gateway_base_url']).rstrip('/')}/media/{stable_id}/stream{source_ext}\n")
    async with pool.acquire() as connection:
        await connection.execute(
            "UPDATE library_mirror_items SET mirror_relative_path=$2,metadata_status='unmatched',last_error='TMDB series match not found',last_built_at=NOW(),updated_at=NOW() WHERE id=$1",
            mapping["id"], relative,
        )
    return "unmatched", relative


async def cancellation_requested(pool: asyncpg.Pool, job_id: uuid.UUID) -> bool:
    async with pool.acquire() as connection:
        return bool(await connection.fetchval("SELECT cancel_requested FROM library_mirror_jobs WHERE id=$1", job_id))


async def run_mirror_job(app: Any, job_id: uuid.UUID, force: bool) -> None:
    pool: asyncpg.Pool = app.state.db
    client: httpx.AsyncClient = app.state.http
    try:
        async with pool.acquire() as connection:
            config = await connection.fetchrow("SELECT * FROM library_mirror_settings WHERE id=1")
            source_host, source_relative = normalize_source_path(str(config["source_host_path"]))
            pattern = f"{source_relative.rstrip('/')}/%" if source_relative else "%"
            rows = await connection.fetch(
                """SELECT path,size_bytes,modified_at FROM media_inventory
                WHERE active=TRUE AND media_type='video' AND extension <> '.strm'
                  AND ($1='' OR path=$1 OR path LIKE $2)
                ORDER BY path""",
                source_relative, pattern,
            )
            await connection.execute(
                "UPDATE library_mirror_jobs SET status='running',started_at=NOW(),total_items=$2,current_path=$3 WHERE id=$1",
                job_id, len(rows), source_host,
            )
        if not str(config["tmdb_token"] or "").strip():
            raise RuntimeError("TMDB API token/key is not configured.")
        output_root().mkdir(parents=True, exist_ok=True)
        series_cache: dict[str, dict[str, Any] | None] = {}
        season_cache: dict[tuple[int, int], dict[str, Any]] = {}
        counters = {"processed": 0, "movies": 0, "episodes": 0, "skipped": 0, "failed": 0}
        seen_paths: set[str] = set()
        for row in rows:
            if await cancellation_requested(pool, job_id):
                raise MirrorCancelled()
            path = str(row["path"])
            seen_paths.add(path)
            parsed = parse_media(path)
            async with pool.acquire() as connection:
                await connection.execute("UPDATE library_mirror_jobs SET current_path=$2 WHERE id=$1", job_id, path)
            try:
                mapping, source_changed = await upsert_mapping(pool, row, parsed)
                rebuild = force or source_changed
                if parsed.kind == "episode":
                    outcome, _ = await build_episode(pool, client, config, mapping, parsed, rebuild, series_cache, season_cache)
                    counters["episodes"] += 1 if outcome == "episode" else 0
                else:
                    outcome, _ = await build_movie(pool, client, config, mapping, parsed, rebuild)
                    counters["movies"] += 1 if outcome == "movie" else 0
                counters["skipped"] += 1 if outcome in {"skipped", "unmatched"} else 0
            except Exception as exc:
                counters["failed"] += 1
                async with pool.acquire() as connection:
                    await connection.execute(
                        "UPDATE library_mirror_items SET metadata_status='error',last_error=$2,updated_at=NOW() WHERE inventory_path=$1",
                        path, str(exc)[-2000:],
                    )
            counters["processed"] += 1
            if counters["processed"] % 10 == 0 or counters["processed"] == len(rows):
                async with pool.acquire() as connection:
                    await connection.execute(
                        """UPDATE library_mirror_jobs SET processed_items=$2,movies_written=$3,
                        episodes_written=$4,skipped_items=$5,failed_items=$6 WHERE id=$1""",
                        job_id, counters["processed"], counters["movies"], counters["episodes"], counters["skipped"], counters["failed"],
                    )
        removed = 0
        if bool(config["remove_missing"]):
            async with pool.acquire() as connection:
                stale = await connection.fetch(
                    """SELECT id,mirror_relative_path FROM library_mirror_items m
                    WHERE active=TRUE AND (
                        NOT EXISTS (SELECT 1 FROM media_inventory i WHERE i.path=m.inventory_path AND i.active=TRUE)
                        OR NOT ($1='' OR m.inventory_path=$1 OR m.inventory_path LIKE $2)
                    )""",
                    source_relative, pattern,
                )
            for item in stale:
                if await remove_item_files(str(item["mirror_relative_path"] or "")):
                    removed += 1
                async with pool.acquire() as connection:
                    await connection.execute("UPDATE library_mirror_items SET active=FALSE,updated_at=NOW() WHERE id=$1", item["id"])
            prune_empty_dirs(output_root())
        async with pool.acquire() as connection:
            await connection.execute(
                """UPDATE library_mirror_jobs SET status='completed',finished_at=NOW(),current_path=NULL,
                processed_items=$2,movies_written=$3,episodes_written=$4,skipped_items=$5,
                failed_items=$6,removed_items=$7 WHERE id=$1""",
                job_id, counters["processed"], counters["movies"], counters["episodes"], counters["skipped"], counters["failed"], removed,
            )
    except MirrorCancelled:
        async with pool.acquire() as connection:
            await connection.execute("UPDATE library_mirror_jobs SET status='cancelled',finished_at=NOW(),current_path=NULL,error=NULL WHERE id=$1", job_id)
    except Exception as exc:
        async with pool.acquire() as connection:
            await connection.execute("UPDATE library_mirror_jobs SET status='failed',finished_at=NOW(),current_path=NULL,error=$2 WHERE id=$1", job_id, str(exc)[-4000:])
    finally:
        try:
            await app.state.redis.delete("mbypanel:mirror:lock")
        except Exception:
            pass


async def serialize_settings(row: asyncpg.Record) -> dict[str, Any]:
    return {
        "source_host_path": row["source_host_path"],
        "output_host_path": row["output_host_path"],
        "movies_folder": row["movies_folder"],
        "tv_folder": row["tv_folder"],
        "language": row["language"],
        "region": row["region"],
        "cache_days": row["cache_days"],
        "download_images": row["download_images"],
        "remove_missing": row["remove_missing"],
        "gateway_base_url": row["gateway_base_url"],
        "tmdb_configured": bool(str(row["tmdb_token"] or "").strip()),
    }


@router.get("/settings")
async def get_settings(request: Request, _: PanelSession = Depends(read_session)) -> dict[str, Any]:
    pool = get_pool(request)
    async with pool.acquire() as connection:
        row = await connection.fetchrow("SELECT * FROM library_mirror_settings WHERE id=1")
    return await serialize_settings(row)


@router.put("/settings")
async def save_settings(payload: MirrorSettingsRequest, request: Request, session: PanelSession = Depends(write_session)) -> dict[str, Any]:
    pool = get_pool(request)
    source, _ = normalize_source_path(payload.source_host_path)
    async with pool.acquire() as connection:
        current = await connection.fetchrow("SELECT tmdb_token FROM library_mirror_settings WHERE id=1")
        token = payload.tmdb_token.strip() or str(current["tmdb_token"] or "")
        row = await connection.fetchrow(
            """UPDATE library_mirror_settings SET source_host_path=$1,tmdb_token=$2,language=$3,
            region=$4,cache_days=$5,download_images=$6,remove_missing=$7,updated_at=NOW(),updated_by=$8
            WHERE id=1 RETURNING *""",
            source, token, payload.language, payload.region.upper(), payload.cache_days,
            payload.download_images, payload.remove_missing, session.username,
        )
        await connection.execute(
            """INSERT INTO audit_log (actor_type,actor_id,action,target_type,target_id,details)
            VALUES ('panel',$1,'mirror.settings.updated','library_mirror','1',$2::jsonb)""",
            session.username, json.dumps({"source_host_path": source, "language": payload.language, "region": payload.region.upper()}),
        )
    return await serialize_settings(row)


@router.get("/status")
async def mirror_status(request: Request, _: PanelSession = Depends(read_session)) -> dict[str, Any]:
    pool = get_pool(request)
    async with pool.acquire() as connection:
        settings_row = await connection.fetchrow("SELECT * FROM library_mirror_settings WHERE id=1")
        job = await connection.fetchrow("SELECT * FROM library_mirror_jobs ORDER BY created_at DESC LIMIT 1")
        counts = await connection.fetchrow(
            """SELECT COUNT(*) FILTER (WHERE active) AS active,
            COUNT(*) FILTER (WHERE active AND media_kind='movie') AS movies,
            COUNT(*) FILTER (WHERE active AND media_kind='episode') AS episodes,
            COUNT(*) FILTER (WHERE active AND metadata_status='matched') AS matched,
            COUNT(*) FILTER (WHERE active AND metadata_status IN ('unmatched','error')) AS problems
            FROM library_mirror_items"""
        )
        inventory = await connection.fetchrow("SELECT COUNT(*) AS total FROM media_inventory WHERE active=TRUE AND media_type='video'")
    return {
        "settings": await serialize_settings(settings_row),
        "last_job": dict(job) if job else None,
        "counts": dict(counts),
        "inventory_video_files": int(inventory["total"] or 0),
        "emby_movie_path": f"/strm-library/{settings_row['movies_folder']}",
        "emby_tv_path": f"/strm-library/{settings_row['tv_folder']}",
    }


@router.post("/build")
async def start_build(payload: StartMirrorRequest, request: Request, session: PanelSession = Depends(write_session)) -> dict[str, Any]:
    pool = get_pool(request)
    if not await request.app.state.redis.set("mbypanel:mirror:lock", session.username, ex=86400, nx=True):
        raise HTTPException(status_code=409, detail="A library mirror build is already running.")
    job_id = uuid.uuid4()
    try:
        async with pool.acquire() as connection:
            running = await connection.fetchval("SELECT EXISTS(SELECT 1 FROM library_mirror_jobs WHERE status IN ('queued','running'))")
            if running:
                raise HTTPException(status_code=409, detail="A library mirror build is already running.")
            await connection.execute(
                "INSERT INTO library_mirror_jobs (id,status,created_by) VALUES ($1,'queued',$2)",
                job_id, session.username,
            )
        task = asyncio.create_task(run_mirror_job(request.app, job_id, payload.force_metadata))
        request.app.state.background_tasks.add(task)
        task.add_done_callback(request.app.state.background_tasks.discard)
        return {"id": str(job_id), "status": "queued"}
    except Exception:
        await request.app.state.redis.delete("mbypanel:mirror:lock")
        raise


@router.post("/jobs/{job_id}/cancel")
async def cancel_build(job_id: uuid.UUID, request: Request, _: PanelSession = Depends(write_session)) -> dict[str, Any]:
    pool = get_pool(request)
    async with pool.acquire() as connection:
        status = await connection.fetchval("SELECT status FROM library_mirror_jobs WHERE id=$1", job_id)
        if status is None:
            raise HTTPException(status_code=404, detail="Mirror job was not found.")
        if status not in {"queued", "running"}:
            return {"id": str(job_id), "status": status}
        await connection.execute("UPDATE library_mirror_jobs SET cancel_requested=TRUE WHERE id=$1", job_id)
    return {"id": str(job_id), "status": "cancelling"}


@router.get("/jobs/{job_id}")
async def get_job(job_id: uuid.UUID, request: Request, _: PanelSession = Depends(read_session)) -> dict[str, Any]:
    pool = get_pool(request)
    async with pool.acquire() as connection:
        row = await connection.fetchrow("SELECT * FROM library_mirror_jobs WHERE id=$1", job_id)
    if row is None:
        raise HTTPException(status_code=404, detail="Mirror job was not found.")
    return dict(row)


@router.get("/problems")
async def get_problems(request: Request, limit: int = 100, _: PanelSession = Depends(read_session)) -> dict[str, Any]:
    pool = get_pool(request)
    limit = min(max(limit, 1), 500)
    async with pool.acquire() as connection:
        rows = await connection.fetch(
            """SELECT inventory_path,media_kind,title,series_title,season_number,episode_number,
            metadata_status,last_error,updated_at FROM library_mirror_items
            WHERE active=TRUE AND metadata_status IN ('unmatched','error')
            ORDER BY updated_at DESC LIMIT $1""",
            limit,
        )
    return {"items": [dict(row) for row in rows]}
