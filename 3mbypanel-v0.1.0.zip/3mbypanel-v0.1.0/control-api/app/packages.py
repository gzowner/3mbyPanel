from __future__ import annotations

import json
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

from fastapi import APIRouter, Depends, Header, HTTPException, Request, status
from pydantic import BaseModel, Field, field_validator

from .access import (
    assert_package_allowed,
    assert_user_in_scope,
    is_admin,
    require_admin_role,
)
from .emby import request_json
from .multiserver import propagate_policy
from .security import PanelSession, ensure_writes_enabled, require_session, validate_csrf

router = APIRouter(prefix="/packages", tags=["Packages"])


class PackagePayload(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    description: str = Field(default="", max_length=2000)
    duration_days: int = Field(default=30, ge=0, le=3650)
    credit_cost: int = Field(default=0, ge=0, le=1_000_000)
    max_sessions: int = Field(default=1, ge=0, le=100)
    hidden: bool = True
    live_tv: bool = False
    downloads: bool = False
    remote_access: bool = True
    video_transcoding: bool = True
    audio_transcoding: bool = True
    remuxing: bool = True
    enabled: bool = True

    @field_validator("name")
    @classmethod
    def clean_name(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Package name cannot be blank")
        return value


class ApplyPackageRequest(BaseModel):
    renew: bool = True


async def package_write_session(
    session: PanelSession = Depends(require_session),
    csrf_token: str | None = Header(default=None, alias="X-CSRF-Token"),
) -> PanelSession:
    ensure_writes_enabled()
    validate_csrf(session, csrf_token)
    return session


def package_dict(row: Any) -> dict[str, Any]:
    item = dict(row)
    item["id"] = str(item["id"])
    item["assigned_users"] = int(item.get("assigned_users") or 0)
    return item


async def insert_audit(
    connection: Any,
    *,
    actor: str,
    action: str,
    target_type: str,
    target_id: str,
    details: dict[str, Any],
) -> None:
    await connection.execute(
        """
        INSERT INTO audit_log (actor_type, actor_id, action, target_type, target_id, details)
        VALUES ('panel', $1, $2, $3, $4, $5::jsonb)
        """,
        actor,
        action,
        target_type,
        target_id,
        json.dumps(details),
    )


async def fetch_package(connection: Any, package_id: str, *, enabled_only: bool = False) -> Any:
    try:
        package_uuid = uuid.UUID(package_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="Invalid package ID.") from exc
    condition = "AND p.enabled = TRUE" if enabled_only else ""
    row = await connection.fetchrow(
        f"""
        SELECT p.*,
               (SELECT COUNT(*) FROM managed_emby_users m WHERE m.package_id = p.id) AS assigned_users
        FROM account_packages p
        WHERE p.id = $1 {condition}
        """,
        package_uuid,
    )
    if row is None:
        raise HTTPException(status_code=404, detail="Package not found.")
    return row


@router.get("")
async def list_packages(
    request: Request,
    session: PanelSession = Depends(require_session),
) -> dict[str, Any]:
    if request.app.state.db is None:
        raise HTTPException(status_code=503, detail="Database is unavailable.")
    async with request.app.state.db.acquire() as connection:
        if is_admin(session):
            rows = await connection.fetch(
                """
                SELECT p.*,
                       (SELECT COUNT(*) FROM managed_emby_users m WHERE m.package_id = p.id) AS assigned_users
                FROM account_packages p
                ORDER BY p.enabled DESC, LOWER(p.name), p.created_at
                """
            )
        else:
            rows = await connection.fetch(
                """
                SELECT p.*,
                       (SELECT COUNT(*) FROM managed_emby_users m
                        WHERE m.package_id=p.id AND m.reseller_id=$1) AS assigned_users
                FROM account_packages p
                JOIN reseller_package_access rpa ON rpa.package_id=p.id
                WHERE rpa.reseller_id=$1 AND p.enabled=TRUE
                ORDER BY LOWER(p.name), p.created_at
                """,
                uuid.UUID(session.account_id),
            )
    packages = [package_dict(row) for row in rows]
    return {"count": len(packages), "packages": packages}


@router.post("", status_code=status.HTTP_201_CREATED)
async def create_package(
    payload: PackagePayload,
    request: Request,
    session: PanelSession = Depends(package_write_session),
) -> dict[str, Any]:
    require_admin_role(session)
    if request.app.state.db is None:
        raise HTTPException(status_code=503, detail="Database is unavailable.")
    async with request.app.state.db.acquire() as connection:
        try:
            async with connection.transaction():
                row = await connection.fetchrow(
                    """
                    INSERT INTO account_packages
                        (name, description, duration_days, credit_cost, max_sessions,
                         hidden, live_tv, downloads, remote_access, video_transcoding,
                         audio_transcoding, remuxing, enabled)
                    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
                    RETURNING *, 0::bigint AS assigned_users
                    """,
                    payload.name,
                    payload.description,
                    payload.duration_days,
                    payload.credit_cost,
                    payload.max_sessions,
                    payload.hidden,
                    payload.live_tv,
                    payload.downloads,
                    payload.remote_access,
                    payload.video_transcoding,
                    payload.audio_transcoding,
                    payload.remuxing,
                    payload.enabled,
                )
                await insert_audit(
                    connection,
                    actor=session.username,
                    action="package.create",
                    target_type="package",
                    target_id=str(row["id"]),
                    details=payload.model_dump(mode="json"),
                )
        except Exception as exc:
            if "unique" in str(exc).lower():
                raise HTTPException(status_code=409, detail="A package with that name already exists.") from exc
            raise
    return package_dict(row)


@router.put("/{package_id}")
async def update_package(
    package_id: str,
    payload: PackagePayload,
    request: Request,
    session: PanelSession = Depends(package_write_session),
) -> dict[str, Any]:
    require_admin_role(session)
    if request.app.state.db is None:
        raise HTTPException(status_code=503, detail="Database is unavailable.")
    try:
        package_uuid = uuid.UUID(package_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="Invalid package ID.") from exc
    async with request.app.state.db.acquire() as connection:
        try:
            async with connection.transaction():
                row = await connection.fetchrow(
                    """
                    UPDATE account_packages SET
                        name=$2, description=$3, duration_days=$4, credit_cost=$5,
                        max_sessions=$6, hidden=$7, live_tv=$8, downloads=$9,
                        remote_access=$10, video_transcoding=$11, audio_transcoding=$12,
                        remuxing=$13, enabled=$14, updated_at=NOW()
                    WHERE id=$1
                    RETURNING *,
                        (SELECT COUNT(*) FROM managed_emby_users m WHERE m.package_id=$1) AS assigned_users
                    """,
                    package_uuid,
                    payload.name,
                    payload.description,
                    payload.duration_days,
                    payload.credit_cost,
                    payload.max_sessions,
                    payload.hidden,
                    payload.live_tv,
                    payload.downloads,
                    payload.remote_access,
                    payload.video_transcoding,
                    payload.audio_transcoding,
                    payload.remuxing,
                    payload.enabled,
                )
                if row is None:
                    raise HTTPException(status_code=404, detail="Package not found.")
                await insert_audit(
                    connection,
                    actor=session.username,
                    action="package.update",
                    target_type="package",
                    target_id=package_id,
                    details=payload.model_dump(mode="json"),
                )
        except HTTPException:
            raise
        except Exception as exc:
            if "unique" in str(exc).lower():
                raise HTTPException(status_code=409, detail="A package with that name already exists.") from exc
            raise
    return package_dict(row)


@router.delete("/{package_id}")
async def delete_package(
    package_id: str,
    request: Request,
    session: PanelSession = Depends(package_write_session),
) -> dict[str, bool]:
    require_admin_role(session)
    if request.app.state.db is None:
        raise HTTPException(status_code=503, detail="Database is unavailable.")
    async with request.app.state.db.acquire() as connection:
        row = await fetch_package(connection, package_id)
        if int(row["assigned_users"] or 0) > 0:
            raise HTTPException(status_code=409, detail="This package is assigned to users.")
        async with connection.transaction():
            await connection.execute("DELETE FROM account_packages WHERE id=$1", row["id"])
            await insert_audit(
                connection,
                actor=session.username,
                action="package.delete",
                target_type="package",
                target_id=package_id,
                details={"name": row["name"]},
            )
    return {"deleted": True}


@router.post("/{package_id}/apply/{user_id}")
async def apply_package(
    package_id: str,
    user_id: str,
    payload: ApplyPackageRequest,
    request: Request,
    session: PanelSession = Depends(package_write_session),
) -> dict[str, Any]:
    if request.app.state.db is None:
        raise HTTPException(status_code=503, detail="Database is unavailable.")
    try:
        user_uuid = uuid.UUID(user_id)
        package_uuid = uuid.UUID(package_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="Invalid user or package ID.") from exc

    user = await request_json(
        request.app.state.http,
        "GET",
        f"Users/{user_id}",
        require_key=True,
        expected_statuses=(200,),
    )
    old_policy = dict(user.get("Policy") or {})
    if old_policy.get("IsAdministrator", False):
        raise HTTPException(status_code=403, detail="Administrator accounts cannot receive packages.")

    async with request.app.state.db.acquire() as connection:
        package = await fetch_package(connection, package_id, enabled_only=True)
        if not is_admin(session):
            await assert_user_in_scope(connection, session, user_uuid)
            await assert_package_allowed(connection, session, package_uuid)
        existing = await connection.fetchrow(
            "SELECT expires_at, notes, disabled_by_expiration, reseller_id FROM managed_emby_users WHERE emby_user_id=$1",
            user_uuid,
        )
        if not is_admin(session):
            account = await connection.fetchrow(
                "SELECT credit_balance FROM panel_accounts WHERE id=$1",
                uuid.UUID(session.account_id),
            )
            if account is None or int(account["credit_balance"]) < int(package["credit_cost"]):
                raise HTTPException(status_code=409, detail="Insufficient reseller credits.")

    new_policy = dict(old_policy)
    new_policy.update(
        {
            "IsAdministrator": False,
            "IsHidden": package["hidden"],
            "EnableMediaPlayback": True,
            "EnableLiveTvAccess": package["live_tv"],
            "EnableLiveTvManagement": False,
            "EnableContentDownloading": package["downloads"],
            "EnableRemoteAccess": package["remote_access"],
            "EnableVideoPlaybackTranscoding": package["video_transcoding"],
            "EnableAudioPlaybackTranscoding": package["audio_transcoding"],
            "EnablePlaybackRemuxing": package["remuxing"],
            "SimultaneousStreamLimit": package["max_sessions"],
            "EnableContentDeletion": False,
            "EnableCollectionManagement": False,
            "EnableSubtitleManagement": False,
            "EnablePublicSharing": False,
        }
    )

    now = datetime.now(timezone.utc)
    duration_days = int(package["duration_days"])
    if duration_days == 0:
        expires_at = None
    elif payload.renew:
        previous = existing["expires_at"] if existing else None
        base = previous if previous and previous > now else now
        expires_at = base + timedelta(days=duration_days)
    else:
        expires_at = now + timedelta(days=duration_days)

    disabled_by_expiration = bool(existing and existing["disabled_by_expiration"])
    if expires_at is None or expires_at > now:
        if disabled_by_expiration:
            new_policy["IsDisabled"] = False
        disabled_by_expiration = False

    await request_json(
        request.app.state.http,
        "POST",
        f"Users/{user_id}/Policy",
        require_key=True,
        json_data=new_policy,
        expected_statuses=(204,),
    )

    try:
        async with request.app.state.db.acquire() as connection:
            async with connection.transaction():
                reseller_id = existing["reseller_id"] if existing else None
                credit_cost = 0
                credit_balance = None
                charge_account_id = None
                if not is_admin(session):
                    charge_account_id = uuid.UUID(session.account_id)
                    if reseller_id is None:
                        reseller_id = charge_account_id
                    credit_cost = int(package["credit_cost"])
                    locked = await connection.fetchrow(
                        "SELECT credit_balance FROM panel_accounts WHERE id=$1 FOR UPDATE",
                        charge_account_id,
                    )
                    if locked is None or int(locked["credit_balance"]) < credit_cost:
                        raise HTTPException(status_code=409, detail="Insufficient reseller credits.")
                    credit_balance = int(locked["credit_balance"]) - credit_cost
                    await connection.execute(
                        "UPDATE panel_accounts SET credit_balance=$2, updated_at=NOW() WHERE id=$1",
                        charge_account_id,
                        credit_balance,
                    )

                await connection.execute(
                    """
                    INSERT INTO managed_emby_users
                        (emby_user_id, reseller_id, package_id, expires_at, max_sessions, managed,
                         notes, created_by, disabled_by_expiration, last_policy_sync_at)
                    VALUES ($1,$2,$3,$4,$5,TRUE,$6,$7,$8,NOW())
                    ON CONFLICT (emby_user_id) DO UPDATE SET
                        reseller_id=COALESCE(EXCLUDED.reseller_id, managed_emby_users.reseller_id),
                        package_id=EXCLUDED.package_id,
                        expires_at=EXCLUDED.expires_at,
                        max_sessions=EXCLUDED.max_sessions,
                        managed=TRUE,
                        disabled_by_expiration=EXCLUDED.disabled_by_expiration,
                        last_policy_sync_at=NOW(), updated_at=NOW()
                    """,
                    user_uuid,
                    reseller_id,
                    package["id"],
                    expires_at,
                    package["max_sessions"],
                    existing["notes"] if existing else "",
                    session.username,
                    disabled_by_expiration,
                )
                if credit_cost:
                    await connection.execute(
                        """
                        INSERT INTO credit_ledger
                            (reseller_id, amount, balance_after, transaction_type,
                             reference_type, reference_id, notes, created_by)
                        VALUES ($1,$2,$3,'renewal','emby_user',$4,$5,$6)
                        """,
                        charge_account_id,
                        -credit_cost,
                        credit_balance,
                        user_id,
                        f"Package renewal: {user.get('Name')} / {package['name']}",
                        session.username,
                    )
                await insert_audit(
                    connection,
                    actor=session.username,
                    action="package.apply",
                    target_type="emby_user",
                    target_id=user_id,
                    details={
                        "user": user.get("Name"),
                        "package_id": package_id,
                        "package": package["name"],
                        "renew": payload.renew,
                        "expires_at": expires_at.isoformat() if expires_at else None,
                        "credit_cost": credit_cost,
                        "credit_balance": credit_balance,
                    },
                )
    except Exception:
        try:
            await request_json(
                request.app.state.http,
                "POST",
                f"Users/{user_id}/Policy",
                require_key=True,
                json_data=old_policy,
                expected_statuses=(204,),
            )
        except Exception:
            pass
        raise

    remote_sync = await propagate_policy(
        request.app.state.db, request.app.state.http, user_uuid, new_policy
    )
    return {
        "applied": True,
        "user_id": user_id,
        "user_name": user.get("Name"),
        "package_id": package_id,
        "package_name": package["name"],
        "expires_at": expires_at,
        "credit_cost": credit_cost,
        "credit_balance": credit_balance,
        "remote_sync": remote_sync,
    }


@router.delete("/users/{user_id}/assignment")
async def remove_assignment(
    user_id: str,
    request: Request,
    session: PanelSession = Depends(package_write_session),
) -> dict[str, bool]:
    require_admin_role(session)
    if request.app.state.db is None:
        raise HTTPException(status_code=503, detail="Database is unavailable.")
    try:
        user_uuid = uuid.UUID(user_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="Invalid Emby user ID.") from exc
    async with request.app.state.db.acquire() as connection:
        async with connection.transaction():
            result = await connection.execute(
                "UPDATE managed_emby_users SET package_id=NULL, updated_at=NOW() WHERE emby_user_id=$1",
                user_uuid,
            )
            await insert_audit(
                connection,
                actor=session.username,
                action="package.assignment_remove",
                target_type="emby_user",
                target_id=user_id,
                details={},
            )
    return {"removed": result.endswith("1")}
