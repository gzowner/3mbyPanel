from __future__ import annotations

import asyncio
import json
import uuid
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from typing import Any

import asyncpg
import httpx

from .emby import request_json
from .multiserver import all_server_sessions, assignment_identity_map, get_server, propagate_policy, server_request_json
from .settings import settings


async def write_audit(
    connection: asyncpg.Connection,
    action: str,
    user_id: uuid.UUID,
    details: dict[str, Any],
) -> None:
    await connection.execute(
        """
        INSERT INTO audit_log (actor_type, actor_id, action, target_type, target_id, details)
        VALUES ('system', 'expiration-worker', $1, 'emby_user', $2, $3::jsonb)
        """,
        action,
        str(user_id),
        json.dumps(details),
    )


async def process_expirations(
    pool: asyncpg.Pool,
    client: httpx.AsyncClient,
) -> dict[str, int]:
    """Apply expiration state to every 3mbyPanel-managed Emby user.

    The function is shared by the background worker and the panel's manual
    "Run expiration check" action. It intentionally skips Emby admins and
    does not auto-enable users that were disabled manually.
    """
    now = datetime.now(timezone.utc)
    stats = {
        "checked": 0,
        "disabled": 0,
        "reenabled": 0,
        "skipped_admin": 0,
        "failed": 0,
    }

    async with pool.acquire() as connection:
        rows = await connection.fetch(
            """
            SELECT emby_user_id, expires_at, disabled_by_expiration
            FROM managed_emby_users
            WHERE managed = TRUE AND expires_at IS NOT NULL
            ORDER BY expires_at
            """
        )

    for row in rows:
        stats["checked"] += 1
        user_id = row["emby_user_id"]
        expires_at = row["expires_at"]
        disabled_by_expiration = bool(row["disabled_by_expiration"])

        try:
            user = await request_json(
                client,
                "GET",
                f"Users/{user_id}",
                require_key=True,
                expected_statuses=(200,),
            )
            policy = dict(user.get("Policy") or {})
            if policy.get("IsAdministrator", False):
                stats["skipped_admin"] += 1
                continue

            should_be_expired = expires_at <= now
            was_disabled_by_expiration = disabled_by_expiration
            changed = False
            action: str | None = None

            if should_be_expired and not disabled_by_expiration:
                # Only claim the disable as an expiration disable when the
                # account was active. A manually disabled account remains a
                # manual disable and will not be auto-enabled on renewal.
                if not policy.get("IsDisabled", False):
                    policy["IsDisabled"] = True
                    disabled_by_expiration = True
                    changed = True
                    action = "emby.user.auto_disabled_expired"
                    stats["disabled"] += 1
            elif not should_be_expired and disabled_by_expiration:
                policy["IsDisabled"] = False
                disabled_by_expiration = False
                changed = True
                action = "emby.user.auto_reenabled_renewed"
                stats["reenabled"] += 1

            if changed:
                await request_json(
                    client,
                    "POST",
                    f"Users/{user_id}/Policy",
                    require_key=True,
                    json_data=policy,
                    expected_statuses=(204,),
                )
                await propagate_policy(pool, client, user_id, policy)

            if action or was_disabled_by_expiration != disabled_by_expiration:
                async with pool.acquire() as connection:
                    await connection.execute(
                        """
                        UPDATE managed_emby_users
                        SET disabled_by_expiration = $2,
                            last_policy_sync_at = NOW(),
                            updated_at = NOW()
                        WHERE emby_user_id = $1
                        """,
                        user_id,
                        disabled_by_expiration,
                    )
                    if action:
                        await write_audit(
                            connection,
                            action,
                            user_id,
                            {
                                "name": user.get("Name"),
                                "expires_at": expires_at.isoformat(),
                            },
                        )
        except Exception as exc:
            stats["failed"] += 1
            async with pool.acquire() as connection:
                await connection.execute(
                    """
                    INSERT INTO audit_log (actor_type, actor_id, action, target_type, target_id, details)
                    VALUES ('system', 'expiration-worker', 'emby.user.expiration_sync_failed',
                            'emby_user', $1, $2::jsonb)
                    """,
                    str(user_id),
                    json.dumps({"error": str(exc)[:500]}),
                )

    return stats


async def maybe_run_nightly_backup(
    pool: asyncpg.Pool,
    client: httpx.AsyncClient,
) -> dict[str, Any] | None:
    if not settings.ops_agent_token:
        return None
    async with pool.acquire() as connection:
        row = await connection.fetchrow(
            """
            SELECT nightly_enabled,
                   to_char(nightly_time, 'HH24:MI') AS nightly_time,
                   retention_daily,
                   retention_weekly,
                   include_mirror
            FROM operations_settings
            WHERE id = 1
            """
        )
        last_value = await connection.fetchval(
            "SELECT value FROM app_settings WHERE key = 'operations_last_nightly_backup'"
        )
    if not row or not row["nightly_enabled"]:
        return None

    try:
        local_now = datetime.now(ZoneInfo(settings.timezone_name))
    except Exception:
        local_now = datetime.now(timezone.utc)
    scheduled = str(row["nightly_time"])
    current_hm = local_now.strftime("%H:%M")
    today = local_now.date().isoformat()
    last_date = None
    if isinstance(last_value, dict):
        last_date = last_value.get("date")
    elif last_value:
        try:
            decoded = json.loads(last_value) if isinstance(last_value, str) else last_value
            if isinstance(decoded, dict):
                last_date = decoded.get("date")
        except Exception:
            pass
    if current_hm < scheduled or last_date == today:
        return None

    response = await client.post(
        f"{settings.ops_agent_url.rstrip('/')}/backups",
        headers={"X-Ops-Token": settings.ops_agent_token},
        json={
            "backup_type": "nightly",
            "requested_by": "backup-worker",
            "include_mirror": bool(row["include_mirror"]),
            "retention_daily": int(row["retention_daily"]),
            "retention_weekly": int(row["retention_weekly"]),
        },
        timeout=20,
    )
    if response.status_code == 409:
        return None
    response.raise_for_status()
    result = response.json()
    async with pool.acquire() as connection:
        await connection.execute(
            """
            INSERT INTO app_settings (key, value, updated_at)
            VALUES ('operations_last_nightly_backup', $1::jsonb, NOW())
            ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()
            """,
            json.dumps({"date": today, "job_id": result.get("job_id"), "started_at": local_now.isoformat()}),
        )
        await connection.execute(
            """
            INSERT INTO audit_log (actor_type, actor_id, action, target_type, target_id, details)
            VALUES ('system', 'backup-worker', 'operations.backup.nightly_started',
                    'backup_job', $1, $2::jsonb)
            """,
            result.get("job_id"),
            json.dumps({"scheduled_time": scheduled, "include_mirror": bool(row["include_mirror"])}),
        )
    return result


def _normalize_emby_user_id(value: Any) -> str:
    text = str(value or "").replace("-", "").lower()
    if len(text) != 32:
        return ""
    try:
        return str(uuid.UUID(text))
    except ValueError:
        return ""


def _remote_ip(value: str | None) -> str:
    import ipaddress

    text = (value or "").strip()
    if not text:
        return ""
    candidate = text
    if candidate.startswith("[") and "]" in candidate:
        candidate = candidate[1:candidate.index("]")]
    else:
        try:
            return str(ipaddress.ip_address(candidate))
        except ValueError:
            if candidate.count(":") == 1:
                host, port = candidate.rsplit(":", 1)
                if port.isdigit():
                    candidate = host
    try:
        return str(ipaddress.ip_address(candidate))
    except ValueError:
        return candidate[:255]


def _stream_item_title(item: dict[str, Any]) -> str:
    name = str(item.get("Name") or "")
    series = str(item.get("SeriesName") or "")
    season = item.get("ParentIndexNumber")
    episode = item.get("IndexNumber")
    if series and season is not None and episode is not None:
        return f"{series} · S{int(season):02d}E{int(episode):02d} · {name}"
    return name or series


async def _upsert_stream_alert(
    connection: asyncpg.Connection,
    *,
    alert_type: str,
    severity: str,
    dedupe_key: str,
    user_id: uuid.UUID | None,
    user_name: str,
    reseller_id: uuid.UUID | None,
    session_id: str | None,
    remote_endpoint: str | None,
    server_id: uuid.UUID | None = None,
    server_name: str | None = None,
    details: dict[str, Any],
) -> None:
    await connection.execute(
        """
        INSERT INTO stream_operation_alerts
            (alert_type, severity, dedupe_key, emby_user_id, user_name,
             reseller_id, session_id, remote_endpoint, server_id, server_name, details)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11::jsonb)
        ON CONFLICT (dedupe_key) WHERE resolved_at IS NULL
        DO UPDATE SET
            severity = EXCLUDED.severity,
            user_name = EXCLUDED.user_name,
            reseller_id = EXCLUDED.reseller_id,
            session_id = EXCLUDED.session_id,
            remote_endpoint = EXCLUDED.remote_endpoint,
            server_id = EXCLUDED.server_id,
            server_name = EXCLUDED.server_name,
            details = EXCLUDED.details,
            last_seen_at = NOW(),
            occurrence_count = stream_operation_alerts.occurrence_count + 1
        """,
        alert_type,
        severity,
        dedupe_key,
        user_id,
        user_name,
        reseller_id,
        session_id,
        remote_endpoint,
        server_id,
        server_name,
        json.dumps(details),
    )


async def sample_stream_sessions(
    pool: asyncpg.Pool,
    client: httpx.AsyncClient,
) -> dict[str, int] | None:
    async with pool.acquire() as connection:
        config = await connection.fetchrow(
            """
            SELECT monitoring_enabled, sample_interval_seconds, history_days,
                   alert_window_minutes, distinct_ip_warning, reconnect_warning,
                   auto_stop_over_limit
            FROM stream_operations_settings WHERE id=1
            """
        )
        last_value = await connection.fetchval(
            "SELECT value FROM app_settings WHERE key='stream_operations_last_sample'"
        )
    if not config or not config["monitoring_enabled"]:
        return None

    now = datetime.now(timezone.utc)
    last_at: datetime | None = None
    if last_value:
        try:
            decoded = json.loads(last_value) if isinstance(last_value, str) else last_value
            value = decoded.get("at") if isinstance(decoded, dict) else None
            if value:
                last_at = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        except Exception:
            last_at = None
    if last_at and (now - last_at).total_seconds() < int(config["sample_interval_seconds"]):
        return None

    sessions, server_failures = await all_server_sessions(pool, client)
    identities = await assignment_identity_map(pool)
    async with pool.acquire() as connection:
        managed_rows = await connection.fetch(
            """
            SELECT emby_user_id::text, max_sessions, reseller_id
            FROM managed_emby_users
            """
        )
    managed = {
        _normalize_emby_user_id(row["emby_user_id"]): {
            "max_sessions": int(row["max_sessions"] or 0),
            "reseller_id": row["reseller_id"],
        }
        for row in managed_rows
    }

    playing_by_user: dict[str, list[dict[str, Any]]] = {}
    sample_rows: list[tuple[Any, ...]] = []
    for current in sessions or []:
        now_playing = current.get("NowPlayingItem") or {}
        if not now_playing:
            continue
        server_id_text = str(current.get("_server_id") or "")
        remote_user_id = _normalize_emby_user_id(current.get("_remote_user_id") or current.get("UserId"))
        canonical_user_id = identities.get((server_id_text, remote_user_id), remote_user_id)
        if not canonical_user_id:
            continue
        user = current.get("_server_user") or {}
        policy = user.get("Policy") or {}
        if policy.get("IsAdministrator", False):
            continue
        play_state = current.get("PlayState") or {}
        transcode = current.get("TranscodingInfo") or {}
        managed_user = managed.get(canonical_user_id, {})
        current["_normalized_user_id"] = canonical_user_id
        current["_max_sessions"] = int(
            managed_user.get("max_sessions") or policy.get("SimultaneousStreamLimit") or 0
        )
        current["_reseller_id"] = managed_user.get("reseller_id")
        current["_composite_session_id"] = f"{server_id_text}~{current.get('Id') or ''}"
        playing_by_user.setdefault(canonical_user_id, []).append(current)
        sample_rows.append(
            (
                str(current.get("Id") or ""),
                uuid.UUID(canonical_user_id),
                str(current.get("UserName") or user.get("Name") or ""),
                managed_user.get("reseller_id"),
                str(current.get("RemoteEndPoint") or ""),
                _remote_ip(current.get("RemoteEndPoint")),
                str(current.get("Client") or ""),
                str(current.get("DeviceName") or ""),
                str(current.get("DeviceId") or ""),
                str(current.get("ApplicationVersion") or ""),
                str(now_playing.get("Id") or ""),
                _stream_item_title(now_playing),
                str(now_playing.get("MediaType") or now_playing.get("Type") or ""),
                str(play_state.get("PlayMethod") or ("Transcode" if transcode else "")),
                bool(play_state.get("IsPaused", False)),
                transcode.get("Bitrate"),
                transcode.get("VideoCodec"),
                transcode.get("AudioCodec"),
                transcode.get("Width"),
                transcode.get("Height"),
                play_state.get("PositionTicks"),
                now_playing.get("RunTimeTicks"),
                bool(current.get("SupportsMediaControl", False)),
                uuid.UUID(server_id_text),
                str(current.get("_server_name") or ""),
            )
        )

    stats = {
        "sampled": len(sample_rows),
        "alerts": 0,
        "stopped": 0,
        "failed_servers": len(server_failures),
    }
    window_minutes = int(config["alert_window_minutes"])
    history_days = int(config["history_days"])

    async with pool.acquire() as connection:
        async with connection.transaction():
            if sample_rows:
                await connection.executemany(
                    """
                    INSERT INTO stream_session_samples
                        (emby_session_id, emby_user_id, user_name, reseller_id,
                         remote_endpoint, remote_ip, client, device_name, device_id,
                         application_version, item_id, item_name, media_type, play_method,
                         is_paused, bitrate, video_codec, audio_codec, width, height,
                         position_ticks, runtime_ticks, supports_media_control, server_id, server_name)
                    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)
                    """,
                    sample_rows,
                )

            for user_id_text, active in playing_by_user.items():
                user_id = uuid.UUID(user_id_text)
                user_name = str(active[0].get("UserName") or (active[0].get("_server_user") or {}).get("Name") or "")
                reseller_id = active[0].get("_reseller_id")
                limit = int(active[0].get("_max_sessions") or 0)
                latest = active[-1]
                latest_server_id = uuid.UUID(str(latest.get("_server_id")))
                latest_server_name = str(latest.get("_server_name") or "")
                if limit > 0 and len(active) > limit:
                    await _upsert_stream_alert(
                        connection,
                        alert_type="over_limit",
                        severity="critical" if len(active) > limit + 1 else "warning",
                        dedupe_key=f"over_limit:{user_id_text}",
                        user_id=user_id,
                        user_name=user_name,
                        reseller_id=reseller_id,
                        session_id=str(latest.get("_composite_session_id") or ""),
                        remote_endpoint=str(latest.get("RemoteEndPoint") or ""),
                        server_id=latest_server_id,
                        server_name=latest_server_name,
                        details={
                            "active_playbacks": len(active),
                            "allowed": limit,
                            "servers": sorted({str(item.get("_server_name") or "") for item in active}),
                        },
                    )
                    stats["alerts"] += 1

                distinct_ips = await connection.fetchval(
                    """
                    SELECT COUNT(DISTINCT remote_ip)
                    FROM stream_session_samples
                    WHERE emby_user_id=$1
                      AND observed_at >= NOW() - ($2::text || ' minutes')::interval
                      AND remote_ip <> ''
                    """,
                    user_id,
                    str(window_minutes),
                )
                if int(distinct_ips or 0) >= int(config["distinct_ip_warning"]):
                    ips = await connection.fetch(
                        """
                        SELECT remote_ip, MAX(observed_at) AS last_seen
                        FROM stream_session_samples
                        WHERE emby_user_id=$1
                          AND observed_at >= NOW() - ($2::text || ' minutes')::interval
                          AND remote_ip <> ''
                        GROUP BY remote_ip
                        ORDER BY last_seen DESC
                        LIMIT 20
                        """,
                        user_id,
                        str(window_minutes),
                    )
                    await _upsert_stream_alert(
                        connection,
                        alert_type="multiple_ips",
                        severity="warning",
                        dedupe_key=f"multiple_ips:{user_id_text}",
                        user_id=user_id,
                        user_name=user_name,
                        reseller_id=reseller_id,
                        session_id=None,
                        remote_endpoint=None,
                        server_id=latest_server_id,
                        server_name=latest_server_name,
                        details={
                            "distinct_ips": int(distinct_ips or 0),
                            "window_minutes": window_minutes,
                            "ips": [row["remote_ip"] for row in ips],
                        },
                    )
                    stats["alerts"] += 1

                distinct_sessions = await connection.fetchval(
                    """
                    SELECT COUNT(DISTINCT (COALESCE(server_id::text, '') || ':' || emby_session_id))
                    FROM stream_session_samples
                    WHERE emby_user_id=$1
                      AND observed_at >= NOW() - ($2::text || ' minutes')::interval
                    """,
                    user_id,
                    str(window_minutes),
                )
                if int(distinct_sessions or 0) >= int(config["reconnect_warning"]):
                    await _upsert_stream_alert(
                        connection,
                        alert_type="reconnect_burst",
                        severity="warning",
                        dedupe_key=f"reconnect_burst:{user_id_text}",
                        user_id=user_id,
                        user_name=user_name,
                        reseller_id=reseller_id,
                        session_id=None,
                        remote_endpoint=None,
                        server_id=latest_server_id,
                        server_name=latest_server_name,
                        details={
                            "distinct_sessions": int(distinct_sessions or 0),
                            "window_minutes": window_minutes,
                        },
                    )
                    stats["alerts"] += 1

            await connection.execute(
                "DELETE FROM stream_session_samples WHERE observed_at < NOW() - ($1::text || ' days')::interval",
                str(history_days),
            )
            await connection.execute(
                """
                INSERT INTO app_settings (key, value, updated_at)
                VALUES ('stream_operations_last_sample', $1::jsonb, NOW())
                ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value, updated_at=NOW()
                """,
                json.dumps({
                    "at": now.isoformat(),
                    "sampled": len(sample_rows),
                    "failed_servers": server_failures,
                }),
            )

    if bool(config["auto_stop_over_limit"]):
        for _, active in playing_by_user.items():
            limit = int(active[0].get("_max_sessions") or 0)
            if limit <= 0 or len(active) <= limit:
                continue
            ordered = sorted(
                active,
                key=lambda item: str(
                    item.get("LastPlaybackCheckIn")
                    or item.get("LastActivityDate")
                    or ""
                ),
            )
            for current in ordered[limit:]:
                try:
                    server = await get_server(pool, uuid.UUID(str(current.get("_server_id"))), enabled_only=True)
                    await server_request_json(
                        client,
                        server,
                        "POST",
                        f"Sessions/{current.get('Id')}/Playing/Stop",
                        expected_statuses=(204,),
                    )
                    stats["stopped"] += 1
                except Exception:
                    pass

    return stats


async def main() -> None:
    pool = await asyncpg.create_pool(settings.database_url, min_size=1, max_size=3)
    timeout = httpx.Timeout(20.0)
    last_expiration_run = 0.0
    async with httpx.AsyncClient(timeout=timeout) as client:
        while True:
            try:
                loop_now = asyncio.get_running_loop().time()
                if loop_now - last_expiration_run >= max(60, settings.user_sync_interval_seconds):
                    stats = await process_expirations(pool, client)
                    last_expiration_run = loop_now
                    if stats["disabled"] or stats["reenabled"] or stats["failed"]:
                        print(f"expiration worker: {stats}", flush=True)
                stream_stats = await sample_stream_sessions(pool, client)
                if stream_stats and (stream_stats["alerts"] or stream_stats["stopped"]):
                    print(f"stream operations worker: {stream_stats}", flush=True)
                backup = await maybe_run_nightly_backup(pool, client)
                if backup:
                    print(f"nightly backup started: {backup}", flush=True)
            except Exception as exc:
                print(f"background worker error: {exc}", flush=True)
            await asyncio.sleep(60)


if __name__ == "__main__":
    asyncio.run(main())
