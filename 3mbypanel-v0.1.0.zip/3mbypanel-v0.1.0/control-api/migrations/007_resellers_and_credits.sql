CREATE TABLE IF NOT EXISTS panel_accounts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username TEXT NOT NULL,
    display_name TEXT NOT NULL DEFAULT '',
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('master_reseller', 'reseller')),
    parent_id UUID REFERENCES panel_accounts(id) ON DELETE RESTRICT,
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    credit_balance INTEGER NOT NULL DEFAULT 0 CHECK (credit_balance >= 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS panel_accounts_username_lower_uidx
    ON panel_accounts (LOWER(username));
CREATE INDEX IF NOT EXISTS panel_accounts_parent_idx
    ON panel_accounts (parent_id);

CREATE TABLE IF NOT EXISTS reseller_package_access (
    reseller_id UUID NOT NULL REFERENCES panel_accounts(id) ON DELETE CASCADE,
    package_id UUID NOT NULL REFERENCES account_packages(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (reseller_id, package_id)
);

CREATE TABLE IF NOT EXISTS credit_ledger (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    reseller_id UUID NOT NULL REFERENCES panel_accounts(id) ON DELETE RESTRICT,
    amount INTEGER NOT NULL CHECK (amount <> 0),
    balance_after INTEGER NOT NULL CHECK (balance_after >= 0),
    transaction_type TEXT NOT NULL CHECK (
        transaction_type IN ('issue', 'remove', 'transfer_in', 'transfer_out', 'subscription', 'renewal', 'refund', 'correction')
    ),
    reference_type TEXT,
    reference_id TEXT,
    notes TEXT NOT NULL DEFAULT '',
    created_by TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS credit_ledger_reseller_created_idx
    ON credit_ledger (reseller_id, created_at DESC);

UPDATE managed_emby_users m
SET reseller_id = NULL
WHERE reseller_id IS NOT NULL
  AND NOT EXISTS (SELECT 1 FROM panel_accounts a WHERE a.id=m.reseller_id);

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname='managed_emby_users_reseller_fk'
    ) THEN
        ALTER TABLE managed_emby_users
            ADD CONSTRAINT managed_emby_users_reseller_fk
            FOREIGN KEY (reseller_id) REFERENCES panel_accounts(id) ON DELETE SET NULL;
    END IF;
END $$;
