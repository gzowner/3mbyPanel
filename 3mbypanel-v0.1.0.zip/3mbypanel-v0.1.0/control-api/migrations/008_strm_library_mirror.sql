CREATE TABLE IF NOT EXISTS library_mirror_settings (
    id SMALLINT PRIMARY KEY CHECK (id = 1),
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    source_host_path TEXT NOT NULL DEFAULT '/mnt/unionfs/Media',
    output_host_path TEXT NOT NULL DEFAULT '/opt/3mbypanel/strm-library',
    movies_folder TEXT NOT NULL DEFAULT 'Movies',
    tv_folder TEXT NOT NULL DEFAULT 'TV Shows',
    tmdb_token TEXT NOT NULL DEFAULT '',
    language TEXT NOT NULL DEFAULT 'en-US',
    region TEXT NOT NULL DEFAULT 'US',
    cache_days INTEGER NOT NULL DEFAULT 30 CHECK (cache_days >= 1 AND cache_days <= 3650),
    download_images BOOLEAN NOT NULL DEFAULT TRUE,
    remove_missing BOOLEAN NOT NULL DEFAULT TRUE,
    gateway_base_url TEXT NOT NULL DEFAULT 'http://media-gateway:8190',
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_by TEXT
);

INSERT INTO library_mirror_settings (id)
VALUES (1)
ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS library_mirror_jobs (
    id UUID PRIMARY KEY,
    status TEXT NOT NULL CHECK (status IN ('queued','running','completed','failed','cancelled')),
    cancel_requested BOOLEAN NOT NULL DEFAULT FALSE,
    total_items BIGINT NOT NULL DEFAULT 0,
    processed_items BIGINT NOT NULL DEFAULT 0,
    movies_written BIGINT NOT NULL DEFAULT 0,
    episodes_written BIGINT NOT NULL DEFAULT 0,
    skipped_items BIGINT NOT NULL DEFAULT 0,
    failed_items BIGINT NOT NULL DEFAULT 0,
    removed_items BIGINT NOT NULL DEFAULT 0,
    current_path TEXT,
    error TEXT,
    created_by TEXT,
    started_at TIMESTAMPTZ,
    finished_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS library_mirror_jobs_created_idx
    ON library_mirror_jobs (created_at DESC);

CREATE TABLE IF NOT EXISTS library_mirror_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    stable_id UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(),
    inventory_path TEXT NOT NULL UNIQUE,
    media_kind TEXT NOT NULL CHECK (media_kind IN ('movie','episode')),
    tmdb_id INTEGER,
    series_tmdb_id INTEGER,
    season_number INTEGER,
    episode_number INTEGER,
    title TEXT NOT NULL DEFAULT '',
    series_title TEXT NOT NULL DEFAULT '',
    production_year INTEGER,
    mirror_relative_path TEXT NOT NULL DEFAULT '',
    source_size_bytes BIGINT NOT NULL DEFAULT 0,
    source_modified_at TIMESTAMPTZ,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    metadata_status TEXT NOT NULL DEFAULT 'pending' CHECK (metadata_status IN ('pending','matched','unmatched','error')),
    last_error TEXT,
    last_built_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS library_mirror_items_active_idx
    ON library_mirror_items (active, media_kind);
CREATE INDEX IF NOT EXISTS library_mirror_items_series_idx
    ON library_mirror_items (series_tmdb_id, season_number, episode_number);

CREATE TABLE IF NOT EXISTS tmdb_metadata_cache (
    cache_key TEXT PRIMARY KEY,
    payload JSONB NOT NULL,
    fetched_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
