CREATE TABLE IF NOT EXISTS media_scan_jobs (
    id UUID PRIMARY KEY,
    status TEXT NOT NULL CHECK (status IN ('queued','running','completed','failed','cancelled')),
    requested_mode TEXT NOT NULL DEFAULT 'auto',
    actual_mode TEXT,
    source_path TEXT,
    started_at TIMESTAMPTZ,
    finished_at TIMESTAMPTZ,
    files_seen BIGINT NOT NULL DEFAULT 0,
    media_files BIGINT NOT NULL DEFAULT 0,
    added_count BIGINT NOT NULL DEFAULT 0,
    changed_count BIGINT NOT NULL DEFAULT 0,
    missing_count BIGINT NOT NULL DEFAULT 0,
    emby_refresh_queued BOOLEAN NOT NULL DEFAULT FALSE,
    error TEXT,
    created_by TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS media_inventory (
    path TEXT PRIMARY KEY,
    remote_id TEXT,
    size_bytes BIGINT NOT NULL DEFAULT 0,
    modified_at TIMESTAMPTZ,
    extension TEXT NOT NULL DEFAULT '',
    media_type TEXT NOT NULL DEFAULT 'other',
    active BOOLEAN NOT NULL DEFAULT TRUE,
    first_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_changed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_seen_job UUID REFERENCES media_scan_jobs(id) ON DELETE SET NULL,
    last_change_job UUID REFERENCES media_scan_jobs(id) ON DELETE SET NULL,
    last_change_type TEXT
);

CREATE TABLE IF NOT EXISTS media_scan_staging (
    job_id UUID NOT NULL REFERENCES media_scan_jobs(id) ON DELETE CASCADE,
    path TEXT NOT NULL,
    remote_id TEXT,
    size_bytes BIGINT NOT NULL DEFAULT 0,
    modified_at TIMESTAMPTZ,
    extension TEXT NOT NULL DEFAULT '',
    media_type TEXT NOT NULL DEFAULT 'other',
    PRIMARY KEY (job_id, path)
);

CREATE INDEX IF NOT EXISTS idx_media_inventory_active ON media_inventory(active);
CREATE INDEX IF NOT EXISTS idx_media_inventory_last_change_job ON media_inventory(last_change_job);
CREATE INDEX IF NOT EXISTS idx_media_jobs_created_at ON media_scan_jobs(created_at DESC);
