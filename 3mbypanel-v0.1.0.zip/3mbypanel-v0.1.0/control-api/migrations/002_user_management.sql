ALTER TABLE managed_emby_users
    ADD COLUMN IF NOT EXISTS notes TEXT NOT NULL DEFAULT '',
    ADD COLUMN IF NOT EXISTS created_by TEXT,
    ADD COLUMN IF NOT EXISTS disabled_by_expiration BOOLEAN NOT NULL DEFAULT FALSE;

CREATE INDEX IF NOT EXISTS managed_emby_users_expiration_idx
    ON managed_emby_users (expires_at)
    WHERE managed = TRUE AND expires_at IS NOT NULL;
