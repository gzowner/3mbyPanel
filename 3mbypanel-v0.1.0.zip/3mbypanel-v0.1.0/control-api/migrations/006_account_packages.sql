CREATE TABLE IF NOT EXISTS account_packages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL UNIQUE,
    description TEXT NOT NULL DEFAULT '',
    duration_days INTEGER NOT NULL DEFAULT 30 CHECK (duration_days >= 0 AND duration_days <= 3650),
    credit_cost INTEGER NOT NULL DEFAULT 0 CHECK (credit_cost >= 0),
    max_sessions INTEGER NOT NULL DEFAULT 1 CHECK (max_sessions >= 0 AND max_sessions <= 100),
    hidden BOOLEAN NOT NULL DEFAULT TRUE,
    live_tv BOOLEAN NOT NULL DEFAULT FALSE,
    downloads BOOLEAN NOT NULL DEFAULT FALSE,
    remote_access BOOLEAN NOT NULL DEFAULT TRUE,
    video_transcoding BOOLEAN NOT NULL DEFAULT TRUE,
    audio_transcoding BOOLEAN NOT NULL DEFAULT TRUE,
    remuxing BOOLEAN NOT NULL DEFAULT TRUE,
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS account_packages_enabled_idx
    ON account_packages (enabled, name);

CREATE INDEX IF NOT EXISTS managed_emby_users_package_idx
    ON managed_emby_users (package_id)
    WHERE package_id IS NOT NULL;
