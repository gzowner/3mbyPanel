ALTER TABLE media_scan_jobs
    ADD COLUMN IF NOT EXISTS cancel_requested BOOLEAN NOT NULL DEFAULT FALSE;

CREATE TABLE IF NOT EXISTS media_scan_settings (
    id SMALLINT PRIMARY KEY CHECK (id = 1),
    host_path TEXT NOT NULL,
    mode TEXT NOT NULL DEFAULT 'auto' CHECK (mode IN ('auto','rclone','filesystem')),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_by TEXT
);

INSERT INTO media_scan_settings (id, host_path, mode)
VALUES (1, '/mnt/unionfs/Media', 'auto')
ON CONFLICT (id) DO NOTHING;
