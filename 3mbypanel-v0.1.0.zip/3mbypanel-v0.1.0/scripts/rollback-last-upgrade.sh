#!/usr/bin/env bash
set -Eeuo pipefail
BASE_DIR="${MBYPANEL_BASE_DIR:-/opt/3mbypanel}"
latest="$(find "$BASE_DIR/backups/upgrades" -mindepth 1 -maxdepth 1 -type d | sort | tail -n1)"
[[ -n "$latest" && -d "$latest/app" ]] || { echo "No application rollback snapshot found." >&2; exit 1; }
read -r -p "Restore application files from $latest? Type ROLLBACK: " answer
[[ "$answer" == ROLLBACK ]] || { echo "Cancelled."; exit 1; }
rsync -a --delete \
  --exclude '.env' --exclude 'emby/' --exclude 'postgres/data/' --exclude 'redis/' \
  --exclude 'backups/' --exclude 'logs/' --exclude 'strm-library/' \
  "$latest/app/" "$BASE_DIR/"
[[ -f "$latest/env.snapshot" ]] && cp -a "$latest/env.snapshot" "$BASE_DIR/.env"
chmod 600 "$BASE_DIR/.env"
"$BASE_DIR/scripts/compose.sh" up -d --build --remove-orphans
printf 'Application files restored from %s\n' "$latest"
printf 'Database migrations are additive and were intentionally retained.\n'
