#!/usr/bin/env python3
from __future__ import annotations

import getpass
import hashlib
import secrets
import sys

ITERATIONS = 260_000


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, ITERATIONS)
    return f"pbkdf2_sha256:{ITERATIONS}:{salt.hex()}:{digest.hex()}"


def main() -> int:
    password = sys.argv[1] if len(sys.argv) > 1 else getpass.getpass("Panel password: ")
    if not password:
        print("Password cannot be empty", file=sys.stderr)
        return 1
    print(hash_password(password))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
