#!/usr/bin/env bash
set -Eeuo pipefail
BASE_DIR="/opt/3mbypanel"
cd "$BASE_DIR"
get_env(){ grep -E "^$1=" .env | tail -n1 | cut -d= -f2- || true; }
DB_USER="$(get_env POSTGRES_USER)"; DB_NAME="$(get_env POSTGRES_DB)"

echo "=== Containers ==="
docker compose --env-file .env ps control-api media-gateway emby postgres

echo
echo "=== Media gateway health ==="
docker compose --env-file .env exec -T media-gateway python -c "import urllib.request; print(urllib.request.urlopen('http://127.0.0.1:8190/health', timeout=5).read().decode())" || true

echo
echo "=== Latest mirror job ==="
docker compose --env-file .env exec -T postgres psql -U "${DB_USER:-mbypanel}" -d "${DB_NAME:-mbypanel}" -x -c \
  "SELECT * FROM library_mirror_jobs ORDER BY created_at DESC LIMIT 1;"

echo
echo "=== Mirror counts ==="
docker compose --env-file .env exec -T postgres psql -U "${DB_USER:-mbypanel}" -d "${DB_NAME:-mbypanel}" -c \
  "SELECT media_kind,metadata_status,active,COUNT(*) FROM library_mirror_items GROUP BY media_kind,metadata_status,active ORDER BY 1,2,3;"

echo
echo "=== Recent problems ==="
docker compose --env-file .env exec -T postgres psql -U "${DB_USER:-mbypanel}" -d "${DB_NAME:-mbypanel}" -c \
  "SELECT LEFT(inventory_path,100) AS source,media_kind,metadata_status,LEFT(COALESCE(last_error,''),120) AS error FROM library_mirror_items WHERE active AND metadata_status IN ('unmatched','error') ORDER BY updated_at DESC LIMIT 20;"

echo
echo "=== Generated files ==="
find "$BASE_DIR/strm-library/Movies" -type f -name '*.strm' 2>/dev/null | wc -l | awk '{print "Movies: "$1}'
find "$BASE_DIR/strm-library/TV Shows" -type f -name '*.strm' 2>/dev/null | wc -l | awk '{print "TV episodes: "$1}'
