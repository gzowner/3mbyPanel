#!/usr/bin/env bash
set -Eeuo pipefail
BASE_DIR="${MBYPANEL_BASE_DIR:-/opt/3mbypanel}"
ENV_FILE="$BASE_DIR/.env"
COMPOSE="$BASE_DIR/scripts/compose.sh"
EXPECTED_SCHEMA_VERSION=15

[[ -f "$ENV_FILE" ]] || { echo "Missing $ENV_FILE" >&2; exit 1; }

get_env() {
  grep -E "^$1=" "$ENV_FILE" | tail -n1 | cut -d= -f2- | sed -e 's/^"//' -e 's/"$//' || true
}

failures=0
pass() { printf '\033[1;32m[PASS]\033[0m %s\n' "$*"; }
fail() { printf '\033[1;31m[FAIL]\033[0m %s\n' "$*"; failures=$((failures+1)); }
warn() { printf '\033[1;33m[WARN]\033[0m %s\n' "$*"; }

printf '3mbyPanel health check — installed version %s\n\n' "$(cat "$BASE_DIR/.mbypanel-version" 2>/dev/null || echo unknown)"

if docker info >/dev/null 2>&1; then pass "Docker daemon"; else fail "Docker daemon unavailable"; fi
if docker compose version >/dev/null 2>&1; then pass "Docker Compose v2"; else fail "Docker Compose v2 unavailable"; fi
if "$COMPOSE" config --quiet >/dev/null 2>&1; then pass "Compose configuration"; else fail "Compose configuration invalid"; fi

services=(
  3mbypanel-emby 3mbypanel-postgres 3mbypanel-redis 3mbypanel-control-api
  3mbypanel-control-worker 3mbypanel-m3u-gateway 3mbypanel-media-gateway
  3mbypanel-ops-agent 3mbypanel-control-web
)
for service in "${services[@]}"; do
  status="$(docker inspect -f '{{.State.Status}}' "$service" 2>/dev/null || true)"
  health="$(docker inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$service" 2>/dev/null || true)"
  if [[ "$status" == running && "$health" != unhealthy ]]; then
    pass "$service ($status/$health)"
  else
    fail "$service ($status/${health:-unknown})"
  fi
done

check_http() {
  local url="$1" name="$2"
  if curl -fsS --max-time 8 "$url" >/dev/null 2>&1; then pass "$name"; else fail "$name — $url"; fi
}
check_http "http://127.0.0.1:$(get_env CONTROL_API_PORT)/health" "Control API endpoint"
check_http "http://127.0.0.1:$(get_env M3U_GATEWAY_PORT)/health" "M3U Gateway endpoint"
check_http "http://127.0.0.1:$(get_env EMBY_HTTP_PORT)/emby/System/Info/Public" "Emby endpoint"
check_http "http://127.0.0.1:$(get_env PANEL_HTTP_PORT)/" "3mbyPanel panel endpoint"

if "$COMPOSE" exec -T ops-agent python -c "import urllib.request; urllib.request.urlopen('http://127.0.0.1:8191/health',timeout=5)" >/dev/null 2>&1; then
  pass "Operations Agent endpoint"
else
  fail "Operations Agent endpoint"
fi
if "$COMPOSE" exec -T media-gateway python -c "import urllib.request; urllib.request.urlopen('http://127.0.0.1:8190/health',timeout=5)" >/dev/null 2>&1; then
  pass "Media Gateway endpoint"
else
  fail "Media Gateway endpoint"
fi

db_user="$(get_env POSTGRES_USER)"; db_name="$(get_env POSTGRES_DB)"
schema="$("$COMPOSE" exec -T postgres psql -U "${db_user:-mbypanel}" -d "${db_name:-mbypanel}" -tAc 'SELECT COALESCE(MAX(version),0) FROM schema_version;' 2>/dev/null | tr -d '[:space:]' || true)"
if [[ "$schema" == "$EXPECTED_SCHEMA_VERSION" ]]; then
  pass "Database schema $schema"
else
  fail "Database schema expected $EXPECTED_SCHEMA_VERSION, found ${schema:-unavailable}"
fi

default_servers="$("$COMPOSE" exec -T postgres psql -U "${db_user:-mbypanel}" -d "${db_name:-mbypanel}" -tAc "SELECT COUNT(*) FROM emby_servers WHERE is_default=TRUE AND is_local=TRUE;" 2>/dev/null | tr -d '[:space:]' || true)"
if [[ "$default_servers" == "1" ]]; then
  pass "Protected local default Emby server registered"
else
  fail "Expected one protected local default Emby server, found ${default_servers:-unavailable}"
fi

media="$(get_env MEDIA_PATH)"
scan="$(get_env MEDIA_SCAN_HOST_ROOT)"
if [[ -d "$media" ]]; then pass "Media path exists: $media"; else fail "Media path missing: $media"; fi
if timeout 10 find "$media" -mindepth 1 -maxdepth 1 -print -quit >/dev/null 2>&1; then pass "Media path responds"; else fail "Media path is not responding"; fi
if [[ -d "$scan" ]]; then pass "Scan root exists: $scan"; else warn "Scan root does not exist yet: $scan"; fi

printf '\n'
if ((failures)); then
  printf '\033[1;31mHealth check failed with %d issue(s).\033[0m\n' "$failures"
  exit 1
fi
printf '\033[1;32mAll critical 3mbyPanel checks passed.\033[0m\n'
