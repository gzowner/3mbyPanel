#!/usr/bin/env bash
set -Eeuo pipefail
BASE_DIR="${MBYPANEL_BASE_DIR:-/opt/3mbypanel}"
ENV_FILE="$BASE_DIR/.env"
COMPOSE="$BASE_DIR/scripts/compose.sh"

[[ -f "$ENV_FILE" ]] || { echo "Missing $ENV_FILE" >&2; exit 1; }
[[ -x "$COMPOSE" ]] || { echo "Missing $COMPOSE" >&2; exit 1; }

get_env() {
  grep -E "^$1=" "$ENV_FILE" | tail -n1 | cut -d= -f2- | sed -e 's/^"//' -e 's/"$//' || true
}

db_user="$(get_env POSTGRES_USER)"
db_name="$(get_env POSTGRES_DB)"
db_user="${db_user:-mbypanel}"
db_name="${db_name:-mbypanel}"

printf '3mbyPanel existing-user import history\n\n'
"$COMPOSE" exec -T postgres psql -U "$db_user" -d "$db_name" -P pager=off -c "
SELECT server_name,
       status,
       requested_count AS requested,
       imported_count AS imported,
       linked_count AS linked,
       created_primary_count AS primary_created,
       skipped_count AS skipped,
       failed_count AS failed,
       created_by,
       to_char(created_at, 'YYYY-MM-DD HH24:MI:SS TZ') AS started,
       COALESCE(to_char(finished_at, 'YYYY-MM-DD HH24:MI:SS TZ'), '-') AS finished
FROM emby_user_import_runs
ORDER BY created_at DESC
LIMIT 50;"

printf '\nRecent import audit entries\n\n'
"$COMPOSE" exec -T postgres psql -U "$db_user" -d "$db_name" -P pager=off -c "
SELECT actor_id AS actor,
       target_id AS server_id,
       details,
       to_char(created_at, 'YYYY-MM-DD HH24:MI:SS TZ') AS created
FROM audit_log
WHERE action='emby.user_import'
ORDER BY created_at DESC
LIMIT 25;"
