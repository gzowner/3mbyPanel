#!/usr/bin/env bash
set -Eeuo pipefail
BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
[[ -f "$BASE_DIR/release-files.sha256" ]] || { echo "release-files.sha256 is missing." >&2; exit 1; }
cd "$BASE_DIR"
sha256sum -c release-files.sha256
