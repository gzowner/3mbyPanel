#!/usr/bin/env bash
set -Eeuo pipefail
BASE_DIR="/opt/3mbypanel"
ENV_FILE="$BASE_DIR/.env"
cd "$BASE_DIR"
[[ -f "$ENV_FILE" ]] || { echo "Installation not found at $BASE_DIR" >&2; exit 1; }
get_env(){ grep -E "^$1=" "$ENV_FILE" | tail -n1 | cut -d= -f2-; }
DB_USER="$(get_env POSTGRES_USER)"
DB_NAME="$(get_env POSTGRES_DB)"

echo "=== Reseller accounts ==="
docker compose --env-file .env exec -T postgres psql -U "${DB_USER:-mbypanel}" -d "${DB_NAME:-mbypanel}" -P pager=off -c \
  "SELECT username, role, enabled, credit_balance, parent_id, created_at FROM panel_accounts ORDER BY role, username;"

echo
echo "=== Recent credit transactions ==="
docker compose --env-file .env exec -T postgres psql -U "${DB_USER:-mbypanel}" -d "${DB_NAME:-mbypanel}" -P pager=off -c \
  "SELECT l.created_at, a.username, l.transaction_type, l.amount, l.balance_after, l.reference_id, l.notes, l.created_by FROM credit_ledger l JOIN panel_accounts a ON a.id=l.reseller_id ORDER BY l.created_at DESC LIMIT 50;"
