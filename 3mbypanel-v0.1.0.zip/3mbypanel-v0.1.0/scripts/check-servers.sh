#!/usr/bin/env bash
set -Eeuo pipefail
BASE_DIR="${MBYPANEL_BASE_DIR:-/opt/3mbypanel}"
ENV_FILE="$BASE_DIR/.env"
COMPOSE="$BASE_DIR/scripts/compose.sh"

[[ -f "$ENV_FILE" ]] || { echo "Missing $ENV_FILE" >&2; exit 1; }
[[ -x "$COMPOSE" ]] || { echo "Missing $COMPOSE" >&2; exit 1; }

get_env() {
  grep -E "^$1=" "$ENV_FILE" | tail -n1 | cut -d= -f2- | sed -e 's/^"//' -e 's/"$//' || true
}

db_user="$(get_env POSTGRES_USER)"
db_name="$(get_env POSTGRES_DB)"
db_user="${db_user:-mbypanel}"
db_name="${db_name:-mbypanel}"

printf '3mbyPanel Emby server registry\n\n'
"$COMPOSE" exec -T postgres psql -U "$db_user" -d "$db_name" -P pager=off -c "
SELECT s.name,
       CASE WHEN s.is_default THEN 'yes' ELSE 'no' END AS default_server,
       CASE WHEN s.enabled THEN 'yes' ELSE 'no' END AS enabled,
       s.last_status,
       COALESCE(s.last_server_name, '-') AS emby_name,
       COALESCE(s.last_version, '-') AS version,
       COUNT(a.id) AS assigned_users,
       COUNT(a.id) FILTER (WHERE a.last_sync_status='failed') AS failed_syncs,
       COALESCE(to_char(s.last_checked_at, 'YYYY-MM-DD HH24:MI:SS TZ'), '-') AS last_checked
FROM emby_servers s
LEFT JOIN server_user_assignments a ON a.server_id=s.id
GROUP BY s.id
ORDER BY s.is_default DESC, LOWER(s.name);"

printf '\nRecent assignment failures\n\n'
"$COMPOSE" exec -T postgres psql -U "$db_user" -d "$db_name" -P pager=off -c "
SELECT s.name AS server,
       COALESCE(a.remote_user_name, '') AS remote_user,
       a.last_sync_message,
       COALESCE(to_char(a.last_sync_at, 'YYYY-MM-DD HH24:MI:SS TZ'), '-') AS last_sync
FROM server_user_assignments a
JOIN emby_servers s ON s.id=a.server_id
WHERE a.last_sync_status='failed'
ORDER BY a.last_sync_at DESC NULLS LAST
LIMIT 50;"
