#!/usr/bin/env bash
set -Eeuo pipefail

BASE_DIR="/opt/3mbypanel"
ENV_FILE="$BASE_DIR/.env"
COMPOSE=(docker compose --env-file "$ENV_FILE")

[[ $EUID -eq 0 ]] || { echo "Run with sudo." >&2; exit 1; }
[[ -f "$ENV_FILE" ]] || { echo "3mbyPanel installation not found at $BASE_DIR" >&2; exit 1; }
cd "$BASE_DIR"

POSTGRES_USER="$(grep -E '^POSTGRES_USER=' "$ENV_FILE" | tail -n1 | cut -d= -f2- || true)"
POSTGRES_DB="$(grep -E '^POSTGRES_DB=' "$ENV_FILE" | tail -n1 | cut -d= -f2- || true)"
POSTGRES_USER="${POSTGRES_USER:-mbypanel}"
POSTGRES_DB="${POSTGRES_DB:-mbypanel}"

echo "=== Containers ==="
"${COMPOSE[@]}" ps control-api m3u-gateway emby postgres

echo
echo "=== Latest EPG mapper job ==="
"${COMPOSE[@]}" exec -T postgres psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -x -c "
SELECT id, source_id, status, cancel_requested, feeds_scanned, epg_channels,
       m3u_channels, exact_matches, suggested_matches, ambiguous_matches,
       unmatched_channels, duplicate_epg_ids, current_item, error,
       started_at, finished_at
FROM epg_mapper_runs
ORDER BY created_at DESC
LIMIT 1;"

echo
echo "=== Mapping totals ==="
"${COMPOSE[@]}" exec -T postgres psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -c "
SELECT mapping_status,
       COUNT(*) AS channels,
       COUNT(*) FILTER (WHERE BTRIM(mapped_tvg_id) <> '') AS applied
FROM m3u_channels
WHERE active = TRUE
GROUP BY mapping_status
ORDER BY mapping_status;"

echo
echo "=== Published channels still missing tvg-id ==="
"${COMPOSE[@]}" exec -T postgres psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -c "
SELECT s.name AS source, COUNT(*) AS missing_tvg_id
FROM m3u_channels ch
JOIN m3u_sources s ON s.id = ch.source_id
JOIN m3u_categories c ON c.id = ch.category_id
WHERE s.enabled = TRUE AND c.enabled = TRUE
  AND ch.enabled = TRUE AND ch.active = TRUE
  AND BTRIM(COALESCE(NULLIF(ch.mapped_tvg_id, ''), ch.tvg_id)) = ''
GROUP BY s.name
ORDER BY s.name;"

echo
echo "=== XMLTV catalog ==="
"${COMPOSE[@]}" exec -T postgres psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -c "
SELECT s.name AS source, e.feed_index + 1 AS priority,
       COUNT(*) FILTER (WHERE e.active = TRUE) AS channels,
       COUNT(*) FILTER (WHERE e.active = TRUE AND e.duplicate_count > 1) AS duplicate_rows
FROM epg_catalog_channels e
JOIN m3u_sources s ON s.id = e.source_id
GROUP BY s.name, e.feed_index
ORDER BY s.name, e.feed_index;"
