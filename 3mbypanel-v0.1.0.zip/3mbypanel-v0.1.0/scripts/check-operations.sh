#!/usr/bin/env bash
set -Eeuo pipefail
BASE_DIR="/opt/3mbypanel"
cd "$BASE_DIR"

echo "=== 3mbyPanel containers ==="
docker compose --env-file .env ps

echo
echo "=== Operations agent health ==="
docker compose --env-file .env exec -T ops-agent python - <<'PY'
import json, os, urllib.request
req=urllib.request.Request('http://127.0.0.1:8191/status',headers={'X-Ops-Token':os.environ['OPS_AGENT_TOKEN']})
with urllib.request.urlopen(req,timeout=15) as response:
    data=json.load(response)
print(json.dumps(data,indent=2))
PY

echo
echo "=== Managed backup files ==="
find "$BASE_DIR/backups/managed" -maxdepth 2 -type f -printf '%TY-%Tm-%Td %TH:%TM  %10s  %p\n' 2>/dev/null | sort -r | head -60 || true
