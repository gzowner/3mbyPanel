#!/usr/bin/env bash
set -Eeuo pipefail
BASE_DIR="/opt/3mbypanel"
ENV_FILE="$BASE_DIR/.env"
COMPOSE=(docker compose -f "$BASE_DIR/compose.yml" --env-file "$ENV_FILE")

[[ -f "$ENV_FILE" ]] || { echo "Missing $ENV_FILE" >&2; exit 1; }
cd "$BASE_DIR"

get_env() {
  grep -E "^$1=" "$ENV_FILE" | tail -n1 | cut -d= -f2- || true
}

POSTGRES_USER="$(get_env POSTGRES_USER)"
POSTGRES_DB="$(get_env POSTGRES_DB)"
EMBY_API_KEY="$(get_env EMBY_API_KEY)"

echo "=== Containers ==="
"${COMPOSE[@]}" ps control-api control-worker emby postgres

echo
echo "=== Emby current sessions ==="
if [[ -n "$EMBY_API_KEY" ]]; then
  "${COMPOSE[@]}" exec -T control-api python - <<'PY'
import json, os, urllib.request
url=os.environ.get('EMBY_URL','http://emby:8096/emby').rstrip('/')+'/Sessions'
req=urllib.request.Request(url,headers={'X-Emby-Token':os.environ.get('EMBY_API_KEY','')})
with urllib.request.urlopen(req,timeout=15) as response:
    rows=json.load(response)
playing=[x for x in rows if x.get('NowPlayingItem')]
transcoding=[x for x in playing if x.get('TranscodingInfo') or (x.get('PlayState') or {}).get('PlayMethod')=='Transcode']
print(f"Sessions: {len(rows)}")
print(f"Playing: {len(playing)}")
print(f"Transcoding: {len(transcoding)}")
for item in playing[:20]:
    now=item.get('NowPlayingItem') or {}
    print(f"- {item.get('UserName') or 'Unknown'} | {item.get('RemoteEndPoint') or '-'} | {now.get('Name') or '-'}")
PY
else
  echo "EMBY_API_KEY is not configured."
fi

echo
echo "=== Monitoring settings ==="
"${COMPOSE[@]}" exec -T postgres psql -U "${POSTGRES_USER:-mbypanel}" -d "${POSTGRES_DB:-mbypanel}" -x -c \
  "SELECT * FROM stream_operations_settings WHERE id=1;"

echo
echo "=== Open warnings ==="
"${COMPOSE[@]}" exec -T postgres psql -U "${POSTGRES_USER:-mbypanel}" -d "${POSTGRES_DB:-mbypanel}" -x -c \
  "SELECT alert_type, severity, user_name, occurrence_count, details, first_seen_at, last_seen_at FROM stream_operation_alerts WHERE resolved_at IS NULL ORDER BY last_seen_at DESC LIMIT 20;"

echo
echo "=== Recent samples ==="
"${COMPOSE[@]}" exec -T postgres psql -U "${POSTGRES_USER:-mbypanel}" -d "${POSTGRES_DB:-mbypanel}" -c \
  "SELECT observed_at, user_name, remote_ip, client, device_name, item_name, play_method, bitrate FROM stream_session_samples ORDER BY observed_at DESC LIMIT 20;"

echo
echo "=== Worker log ==="
"${COMPOSE[@]}" logs --tail=100 control-worker
