#!/usr/bin/env bash
set -Eeuo pipefail
BASE_DIR="/opt/3mbypanel"
ENV_FILE="$BASE_DIR/.env"
[[ $EUID -eq 0 ]] || { echo "Run with sudo." >&2; exit 1; }
[[ -f "$ENV_FILE" ]] || { echo "3mbyPanel installation not found at $BASE_DIR" >&2; exit 1; }

get_env() {
  grep -E "^$1=" "$ENV_FILE" | tail -n1 | cut -d= -f2-
}

POSTGRES_USER="$(get_env POSTGRES_USER)"
POSTGRES_DB="$(get_env POSTGRES_DB)"
POSTGRES_USER="${POSTGRES_USER:-mbypanel}"
POSTGRES_DB="${POSTGRES_DB:-mbypanel}"

cd "$BASE_DIR"

echo "=== Managed user expiration records ==="
docker compose --env-file .env exec -T postgres \
  psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -P pager=off -c \
  "SELECT emby_user_id, managed, expires_at, disabled_by_expiration, last_policy_sync_at, updated_at FROM managed_emby_users ORDER BY expires_at NULLS LAST;"

echo
echo "=== Expiration worker container ==="
docker compose --env-file .env ps control-worker

echo
echo "=== Recent expiration worker logs ==="
docker compose --env-file .env logs --tail=100 control-worker

echo
echo "=== Recent expiration audit events ==="
docker compose --env-file .env exec -T postgres \
  psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -P pager=off -c \
  "SELECT created_at, action, target_id, details FROM audit_log WHERE action LIKE '%expir%' ORDER BY created_at DESC LIMIT 25;"
