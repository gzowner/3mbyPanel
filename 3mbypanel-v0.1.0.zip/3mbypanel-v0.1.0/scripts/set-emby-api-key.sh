#!/usr/bin/env bash
set -Eeuo pipefail
BASE_DIR="${MBYPANEL_BASE_DIR:-/opt/3mbypanel}"
ENV_FILE="$BASE_DIR/.env"

[[ $EUID -eq 0 ]] || { echo "Run with sudo/root." >&2; exit 1; }
[[ -f "$ENV_FILE" ]] || { echo "$ENV_FILE was not found." >&2; exit 1; }

KEY="${1:-${MBYPANEL_EMBY_API_KEY:-}}"
if [[ -z "$KEY" ]]; then
  read -r -s -p "Emby API key: " KEY
  echo
fi
[[ -n "$KEY" ]] || { echo "The API key cannot be blank." >&2; exit 1; }
[[ "$KEY" != *$'\n'* && "$KEY" != *$'\r'* ]] || { echo "The API key contains invalid characters." >&2; exit 1; }

python3 - "$ENV_FILE" "$KEY" <<'PY'
from pathlib import Path
import sys
path = Path(sys.argv[1])
key = sys.argv[2]
lines = path.read_text(encoding="utf-8").splitlines()
output = []
replaced = False
for line in lines:
    if line.startswith("EMBY_API_KEY="):
        output.append(f"EMBY_API_KEY={key}")
        replaced = True
    else:
        output.append(line)
if not replaced:
    output.append(f"EMBY_API_KEY={key}")
path.write_text("\n".join(output) + "\n", encoding="utf-8")
PY
chmod 600 "$ENV_FILE"

"$BASE_DIR/scripts/compose.sh" up -d --force-recreate control-api control-worker ops-agent
printf 'Emby API key saved. Refresh the 3mbyPanel control panel.\n'
