# 3mbyPanel changelog

## 0.1.0 — Initial full Emby port

- Ported the complete JellyPanel management foundation to a separate Emby-native product.
- Added the official Emby Server Docker image with configurable UID, GID, supplemental groups, timezone, media paths, `/dev/dri`, and host port.
- Changed local REST integration to the Emby `/emby` API root using `X-Emby-Token`.
- Added Emby-specific handling for user queries, password updates, successful write responses, and user deletion.
- Added Emby `SimultaneousStreamLimit` package and policy synchronization.
- Ported user creation, updates, expiration, package assignment, resellers, credits, and audit history.
- Ported multi-server health, encrypted API keys, user assignments, combined sessions, and failure isolation.
- Ported existing-user scan, preview, protected-admin handling, import, adoption, linking, and generated-password workflow.
- Ported M3U filtering, XMLTV feeds, EPG mapper, Live TV tuner/listing-provider synchronization, and guide refresh.
- Ported media inventory and TMDB STRM/NFO library mirror.
- Ported Stream Operations, playback messages, stop controls, warnings, and optional limit enforcement.
- Replaced the Jellyfin-native backup call with a quiesced Emby configuration archive plus PostgreSQL and optional STRM backups.
- Added fresh install, upgrade, repair, restore, diagnostics, rollback, and data-preserving uninstall modes.
- Assigned non-conflicting host defaults: Emby 8098 and panel 8281.
