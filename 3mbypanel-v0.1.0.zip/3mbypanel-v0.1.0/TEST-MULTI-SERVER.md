# 3mbyPanel multi-server test checklist

Use test accounts and a non-production secondary Emby server first.

## 1. Upgrade validation

```bash
cd /root/3mbypanel-v0.1.0
sudo bash install.sh --mode upgrade
sudo /opt/3mbypanel/scripts/manage.sh health
sudo /opt/3mbypanel/scripts/manage.sh servers
```

Expected:

- Installed version `0.1.0`.
- Database schema `14`.
- One protected default server named `Local Emby`.
- Existing users, packages, resellers, M3U, EPG, mirror, and backups remain present.

## 2. Register a secondary server

1. Create a Emby API key on the secondary server.
2. Open 3mbyPanel → **Servers**.
3. Add the secondary internal/API URL and public/client URL.
4. Save and run **Test all**.

Expected:

- Server status becomes `online`.
- Emby server name and version appear.
- The API key is not displayed after saving.

## 3. Assign a test user

1. Open **Users**.
2. Select **Servers** beside a managed non-administrator test account.
3. Enter a test password.
4. Click **Assign** on the secondary server.

Expected:

- A same-name user is linked or created on the secondary server.
- The assignment becomes `synced`.
- Live TV, download, remote-access, transcoding, disabled, and session-limit policy match the primary account.

## 4. Policy and password propagation

Change the test user's package or permissions, then refresh the secondary Emby user. Reset the password from 3mbyPanel and sign in to both servers.

Expected:

- Assigned-server policy updates without changing administrator accounts.
- The new password works on both assigned servers.

## 5. Combined Stream Operations

Start playback for the same test user on the primary and secondary servers.

Expected:

- Both sessions appear with the correct server name.
- Combined connection usage reflects playback across both servers.
- Message and Stop commands reach the selected session's server.
- Suspend disables the user on all assigned servers and stops active playback.

Keep automatic over-limit stopping disabled during the first test.

## 6. Outage behavior

Stop or firewall the secondary Emby server, then refresh 3mbyPanel.

Expected:

- The primary server and panel continue working.
- The secondary server reports offline.
- Stream Operations identifies the server that failed to report.
- Restoring the server and running **Test** returns it to online.

## 7. Unassign and removal

Test both unassignment choices:

- Preserve the remote Emby user.
- Delete the remote Emby user.

Then remove the secondary server from 3mbyPanel.

Expected:

- The local default server cannot be removed.
- Removing a secondary server does not delete its Emby installation.

## 8. Rollback test

A pre-upgrade rollback snapshot should exist under:

```text
/opt/3mbypanel/backups/upgrades/
```

Application rollback command:

```bash
sudo /opt/3mbypanel/scripts/rollback-last-upgrade.sh
```

Migration 14 is additive and remains in PostgreSQL after application-file rollback. Reinstalling v0.1.0 reuses the existing tables safely.
