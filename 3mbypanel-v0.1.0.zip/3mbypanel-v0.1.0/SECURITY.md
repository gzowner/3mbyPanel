# Security guidance

3mbyPanel v0.1.0 defaults to local HTTP for testing. Do not expose it directly to the public internet in that state.

Before public deployment:

- Put Emby and 3mbyPanel behind a correctly configured HTTPS reverse proxy.
- Restrict panel access with firewall, VPN, or trusted networks.
- Use strong unique panel and Emby administrator passwords.
- Rotate Emby API keys when a server or backup is transferred.
- Keep `/opt/3mbypanel/.env`, backups, diagnostics, and credential files private.
- Do not publish provider playlist credentials or API keys in screenshots or logs.
- Review diagnostic archives before sharing them; automated redaction cannot recognize every provider-specific secret.
- Keep Ubuntu, Docker, Emby, and container images patched.
- Test upgrades and restores on a non-production server first.

Remote Emby API keys are encrypted in PostgreSQL using the 3mbyPanel application secret. Loss of that secret prevents decryption. Exposure of both the database and application secret exposes the stored keys.

The Operations Agent has Docker-socket access and therefore has host-level administrative capability. It is Docker-internal, token-protected, and must never be exposed as a public port.
